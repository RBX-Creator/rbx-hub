"""Dreck Fruit v3 — clear Blox Fruits silhouette: rounded cube, swirl texture, green stem+leaves."""
import bpy
import bmesh
import math
from mathutils import Vector
from pathlib import Path

OUT = Path("/workspace/soul-fruits-assets")
TEX = str(OUT / "DreckFruit_swirl.png")
BLEND = str(OUT / "DreckFruit.blend")
FBX = str(OUT / "DreckFruit.fbx")
PNG = str(OUT / "DreckFruit_preview.png")

bpy.ops.object.select_all(action="SELECT")
bpy.ops.object.delete(use_global=False)
for c in (bpy.data.meshes, bpy.data.materials, bpy.data.images, bpy.data.textures):
    for b in list(c):
        c.remove(b)

def principled(name, color=None, roughness=0.5, img_path=None):
    m = bpy.data.materials.new(name=name)
    m.use_nodes = True
    nt = m.node_tree
    nodes, links = nt.nodes, nt.links
    bsdf = nodes.get("Principled BSDF")
    out = nodes.get("Material Output")
    if img_path:
        tex = nodes.new("ShaderNodeTexImage")
        tex.image = bpy.data.images.load(img_path)
        tex.interpolation = "Closest"  # crisp BF look
        links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    elif color:
        bsdf.inputs["Base Color"].default_value = (*color, 1.0)
    bsdf.inputs["Roughness"].default_value = roughness
    return m

mat_body = principled("Dreck_Body", roughness=0.65, img_path=TEX)
mat_stem = principled("Dreck_Stem", color=(0.18, 0.62, 0.16), roughness=0.4)
mat_leaf = principled("Dreck_Leaf", color=(0.25, 0.78, 0.20), roughness=0.35)

# Rounded cube — BF icon shape
bpy.ops.mesh.primitive_cube_add(size=1.7, location=(0, 0, 0.9))
body = bpy.context.active_object
body.name = "Body"
mod = body.modifiers.new("Bevel", "BEVEL")
mod.width = 0.28
mod.segments = 4
mod.limit_method = "ANGLE"
bpy.ops.object.modifier_apply(modifier="Bevel")
# light subdivide for smoother round + UV
bpy.ops.object.mode_set(mode="EDIT")
bpy.ops.mesh.select_all(action="SELECT")
bpy.ops.mesh.subdivide(number_cuts=1)
bpy.ops.object.mode_set(mode="OBJECT")
bpy.ops.object.shade_smooth()

# UV unwrap smart
bpy.ops.object.mode_set(mode="EDIT")
bpy.ops.mesh.select_all(action="SELECT")
bpy.ops.uv.smart_project(angle_limit=math.radians(66), island_margin=0.02)
bpy.ops.object.mode_set(mode="OBJECT")
body.data.materials.append(mat_body)

# Stem — short cylinder with curl
bpy.ops.mesh.primitive_cylinder_add(vertices=8, radius=0.08, depth=0.5, location=(0, 0, 1.95))
stem = bpy.context.active_object
stem.name = "Stem"
bm = bmesh.new(); bm.from_mesh(stem.data)
for v in bm.verts:
    t = (v.co.z + 0.25) / 0.5
    if t > 0.4:
        f = (t - 0.4) / 0.6
        v.co.x += 0.22 * f * f
        v.co.z -= 0.12 * f * f
bm.to_mesh(stem.data); bm.free()
stem.data.materials.append(mat_stem)
bpy.ops.object.shade_smooth()

# 3 leaves like BF
def leaf(name, loc, rot_euler, sx=0.42):
    bpy.ops.mesh.primitive_circle_add(vertices=10, radius=sx, fill_type="NGON", location=loc)
    o = bpy.context.active_object
    o.name = name
    # extrude thin thickness
    bpy.ops.object.mode_set(mode="EDIT")
    bpy.ops.mesh.extrude_region_move(TRANSFORM_OT_translate={"value": (0, 0, 0.04)})
    bpy.ops.object.mode_set(mode="OBJECT")
    # scale to leaf oval + point
    o.scale = (1.0, 0.45, 1.0)
    bpy.ops.object.transform_apply(scale=True)
    o.rotation_euler = rot_euler
    bpy.ops.object.transform_apply(rotation=True)
    # taper tip
    bm = bmesh.new(); bm.from_mesh(o.data)
    for v in bm.verts:
        if v.co.x > 0.05:
            v.co.y *= max(0.15, 1.0 - (v.co.x / sx) * 0.85)
    bm.to_mesh(o.data); bm.free()
    o.data.materials.append(mat_leaf)
    bpy.ops.object.shade_smooth()
    return o

l1 = leaf("L1", (0.22, 0.0, 2.18), (math.radians(15), math.radians(55), 0))
l2 = leaf("L2", (-0.12, 0.18, 2.15), (math.radians(20), math.radians(-50), math.radians(30)), 0.36)
l3 = leaf("L3", (-0.08, -0.18, 2.12), (math.radians(25), math.radians(20), math.radians(-100)), 0.32)

# Join
bpy.ops.object.select_all(action="DESELECT")
for o in (body, stem, l1, l2, l3):
    o.select_set(True)
bpy.context.view_layer.objects.active = body
bpy.ops.object.join()
fruit = bpy.context.active_object
fruit.name = "DreckFruit"
bpy.ops.object.origin_set(type="ORIGIN_GEOMETRY", center="BOUNDS")
zs = [v.co.z for v in fruit.data.vertices]
fruit.location.z -= min(zs)
bpy.ops.object.transform_apply(location=True)

print(f"v3: {len(fruit.data.vertices)} verts, {len(fruit.data.polygons)} faces")

# Camera
bpy.ops.object.camera_add(location=(3.8, -3.5, 2.8))
cam = bpy.context.active_object
cam.rotation_euler = (Vector((0, 0, 1.0)) - cam.location).to_track_quat("-Z", "Y").to_euler()
bpy.context.scene.camera = cam
bpy.ops.object.light_add(type="SUN", location=(4, -2, 7))
bpy.context.active_object.data.energy = 3.0
bpy.ops.object.light_add(type="AREA", location=(-3, 2, 4))
bpy.context.active_object.data.energy = 60
bpy.context.active_object.data.size = 5
w = bpy.data.worlds.new("W"); bpy.context.scene.world = w; w.use_nodes = True
w.node_tree.nodes["Background"].inputs[0].default_value = (0.58, 0.6, 0.64, 1)

sc = bpy.context.scene
sc.render.engine = "BLENDER_EEVEE"
sc.render.resolution_x = sc.render.resolution_y = 640
sc.render.filepath = PNG
bpy.ops.render.render(write_still=True)
bpy.ops.wm.save_as_mainfile(filepath=BLEND)
bpy.ops.object.select_all(action="DESELECT"); fruit.select_set(True)
bpy.context.view_layer.objects.active = fruit
bpy.ops.export_scene.fbx(filepath=FBX, use_selection=True, apply_scale_options="FBX_SCALE_ALL",
    axis_forward="-Z", axis_up="Y", mesh_smooth_type="FACE", path_mode="COPY", embed_textures=True)
print("DONE_V3")
