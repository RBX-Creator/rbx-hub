"""Soul Fruits — Blutaugespiegel (Legendary): BF rounded cube, dark blood-red, eye/tomoe pattern."""
import bpy
import bmesh
import math
from mathutils import Vector
from pathlib import Path

OUT = Path("/workspace/soul-fruits-assets")
TEX = str(OUT / "Blutaugespiegel_tex.png")
BLEND = str(OUT / "Blutaugespiegel.blend")
FBX = str(OUT / "Blutaugespiegel.fbx")
PNG = str(OUT / "Blutaugespiegel_preview.png")

bpy.ops.object.select_all(action="SELECT")
bpy.ops.object.delete(use_global=False)
for coll in (bpy.data.meshes, bpy.data.materials, bpy.data.images):
    for b in list(coll):
        coll.remove(b)

def mat_tex(name, path, roughness=0.35, metallic=0.25):
    m = bpy.data.materials.new(name=name)
    m.use_nodes = True
    nt = m.node_tree
    nodes, links = nt.nodes, nt.links
    bsdf = nodes["Principled BSDF"]
    tex = nodes.new("ShaderNodeTexImage")
    tex.image = bpy.data.images.load(path)
    tex.interpolation = "Closest"
    links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    bsdf.inputs["Roughness"].default_value = roughness
    if "Metallic" in bsdf.inputs:
        bsdf.inputs["Metallic"].default_value = metallic
    # slight emission from red for "legendary glow"
    if "Emission Color" in bsdf.inputs:
        bsdf.inputs["Emission Color"].default_value = (0.4, 0.02, 0.05, 1)
        if "Emission Strength" in bsdf.inputs:
            bsdf.inputs["Emission Strength"].default_value = 0.15
    return m

def mat_col(name, color, roughness=0.4):
    m = bpy.data.materials.new(name=name)
    m.use_nodes = True
    bsdf = m.node_tree.nodes["Principled BSDF"]
    bsdf.inputs["Base Color"].default_value = (*color, 1)
    bsdf.inputs["Roughness"].default_value = roughness
    return m

mat_body = mat_tex("Blut_Body", TEX, roughness=0.32, metallic=0.28)
mat_stem = mat_col("Blut_Stem", (0.12, 0.45, 0.12), 0.4)
mat_leaf = mat_col("Blut_Leaf", (0.15, 0.55, 0.14), 0.35)

# Slightly larger / more prestigious rounded cube
bpy.ops.mesh.primitive_cube_add(size=1.85, location=(0, 0, 0.95))
body = bpy.context.active_object
body.name = "Body"
mod = body.modifiers.new("Bevel", "BEVEL")
mod.width = 0.32
mod.segments = 4
mod.limit_method = "ANGLE"
bpy.ops.object.modifier_apply(modifier="Bevel")
bpy.ops.object.mode_set(mode="EDIT")
bpy.ops.mesh.select_all(action="SELECT")
bpy.ops.mesh.subdivide(number_cuts=1)
bpy.ops.uv.smart_project(angle_limit=math.radians(66), island_margin=0.03)
bpy.ops.object.mode_set(mode="OBJECT")
bpy.ops.object.shade_smooth()
body.data.materials.append(mat_body)

# Subtle raised "iris ring" as inset torus on front face for silhouette
bpy.ops.mesh.primitive_torus_add(
    major_radius=0.38, minor_radius=0.045,
    major_segments=24, minor_segments=8,
    location=(0, -0.92, 0.95), rotation=(math.radians(90), 0, 0)
)
ring = bpy.context.active_object
ring.name = "EyeRing"
ring.data.materials.append(mat_body)
bpy.ops.object.shade_smooth()

# Stem with stronger curl (legendary)
bpy.ops.mesh.primitive_cylinder_add(vertices=8, radius=0.085, depth=0.55, location=(0, 0, 2.1))
stem = bpy.context.active_object
stem.name = "Stem"
bm = bmesh.new(); bm.from_mesh(stem.data)
for v in bm.verts:
    t = (v.co.z + 0.275) / 0.55
    if t > 0.35:
        f = (t - 0.35) / 0.65
        v.co.x += 0.28 * f * f
        v.co.z -= 0.14 * f * f
bm.to_mesh(stem.data); bm.free()
stem.data.materials.append(mat_stem)
bpy.ops.object.shade_smooth()

def leaf(name, loc, rot, sx=0.44):
    bpy.ops.mesh.primitive_circle_add(vertices=10, radius=sx, fill_type="NGON", location=loc)
    o = bpy.context.active_object
    o.name = name
    bpy.ops.object.mode_set(mode="EDIT")
    bpy.ops.mesh.extrude_region_move(TRANSFORM_OT_translate={"value": (0, 0, 0.04)})
    bpy.ops.object.mode_set(mode="OBJECT")
    o.scale = (1.0, 0.42, 1.0)
    bpy.ops.object.transform_apply(scale=True)
    o.rotation_euler = rot
    bpy.ops.object.transform_apply(rotation=True)
    bm = bmesh.new(); bm.from_mesh(o.data)
    for v in bm.verts:
        if v.co.x > 0.05:
            v.co.y *= max(0.12, 1.0 - (v.co.x / sx) * 0.9)
    bm.to_mesh(o.data); bm.free()
    o.data.materials.append(mat_leaf)
    bpy.ops.object.shade_smooth()
    return o

l1 = leaf("L1", (0.24, 0.02, 2.35), (math.radians(12), math.radians(58), 0))
l2 = leaf("L2", (-0.14, 0.2, 2.32), (math.radians(18), math.radians(-52), math.radians(28)), 0.38)
l3 = leaf("L3", (-0.1, -0.2, 2.28), (math.radians(22), math.radians(18), math.radians(-95)), 0.34)

bpy.ops.object.select_all(action="DESELECT")
for o in (body, ring, stem, l1, l2, l3):
    o.select_set(True)
bpy.context.view_layer.objects.active = body
bpy.ops.object.join()
fruit = bpy.context.active_object
fruit.name = "Blutaugespiegel"
bpy.ops.object.origin_set(type="ORIGIN_GEOMETRY", center="BOUNDS")
zs = [v.co.z for v in fruit.data.vertices]
fruit.location.z -= min(zs)
bpy.ops.object.transform_apply(location=True)

print(f"Blutaugespiegel: {len(fruit.data.vertices)} verts, {len(fruit.data.polygons)} faces")

# Preview — darker studio lighting to show red glow
bpy.ops.object.camera_add(location=(4.0, -3.8, 3.0))
cam = bpy.context.active_object
cam.rotation_euler = (Vector((0, 0, 1.1)) - cam.location).to_track_quat("-Z", "Y").to_euler()
bpy.context.scene.camera = cam
bpy.ops.object.light_add(type="SUN", location=(4, -2, 7))
bpy.context.active_object.data.energy = 2.4
bpy.ops.object.light_add(type="AREA", location=(-2.5, 2.5, 3.5))
a = bpy.context.active_object
a.data.energy = 40
a.data.size = 4
# red rim light
bpy.ops.object.light_add(type="AREA", location=(2, 3, 1.5))
r = bpy.context.active_object
r.data.energy = 25
r.data.size = 3
r.data.color = (1.0, 0.15, 0.2)

w = bpy.data.worlds.new("W"); bpy.context.scene.world = w; w.use_nodes = True
w.node_tree.nodes["Background"].inputs[0].default_value = (0.12, 0.1, 0.12, 1)
w.node_tree.nodes["Background"].inputs[1].default_value = 0.6

sc = bpy.context.scene
sc.render.engine = "BLENDER_EEVEE"
sc.render.resolution_x = sc.render.resolution_y = 640
sc.render.filepath = PNG
bpy.ops.render.render(write_still=True)
bpy.ops.wm.save_as_mainfile(filepath=BLEND)
bpy.ops.object.select_all(action="DESELECT"); fruit.select_set(True)
bpy.context.view_layer.objects.active = fruit
bpy.ops.export_scene.fbx(
    filepath=FBX, use_selection=True, apply_scale_options="FBX_SCALE_ALL",
    axis_forward="-Z", axis_up="Y", mesh_smooth_type="FACE",
    path_mode="COPY", embed_textures=True,
)
print("DONE", FBX)
