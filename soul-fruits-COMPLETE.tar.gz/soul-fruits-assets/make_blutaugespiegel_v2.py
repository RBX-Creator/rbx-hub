"""Blutaugespiegel v2 — Legendary standout: 3D eye, dark leaves, glossy blood, even symmetry."""
import bpy, bmesh, math
from mathutils import Vector
from pathlib import Path

OUT = Path("/workspace/soul-fruits-assets")
TEX = str(OUT / "Blutaugespiegel_tex.png")
BLEND = str(OUT / "Blutaugespiegel.blend")
FBX = str(OUT / "Blutaugespiegel.fbx")
PNG = str(OUT / "Blutaugespiegel_preview.png")

bpy.ops.object.select_all(action="SELECT")
bpy.ops.object.delete(use_global=False)
for coll in (bpy.data.meshes, bpy.data.materials, bpy.data.images):
    for b in list(coll):
        coll.remove(b)

def mat_tex(name, path):
    m = bpy.data.materials.new(name=name)
    m.use_nodes = True
    nt = m.node_tree
    bsdf = nt.nodes["Principled BSDF"]
    tex = nt.nodes.new("ShaderNodeTexImage")
    tex.image = bpy.data.images.load(path)
    tex.interpolation = "Closest"
    nt.links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    bsdf.inputs["Roughness"].default_value = 0.22
    if "Metallic" in bsdf.inputs:
        bsdf.inputs["Metallic"].default_value = 0.45
    if "Specular IOR Level" in bsdf.inputs:
        bsdf.inputs["Specular IOR Level"].default_value = 0.7
    if "Emission Color" in bsdf.inputs:
        bsdf.inputs["Emission Color"].default_value = (0.7, 0.05, 0.08, 1)
        if "Emission Strength" in bsdf.inputs:
            bsdf.inputs["Emission Strength"].default_value = 0.45
    return m

def mat_col(name, color, rough=0.4, metal=0.0, emit=None, emit_s=0.0):
    m = bpy.data.materials.new(name=name)
    m.use_nodes = True
    bsdf = m.node_tree.nodes["Principled BSDF"]
    bsdf.inputs["Base Color"].default_value = (*color, 1)
    bsdf.inputs["Roughness"].default_value = rough
    if "Metallic" in bsdf.inputs:
        bsdf.inputs["Metallic"].default_value = metal
    if emit and "Emission Color" in bsdf.inputs:
        bsdf.inputs["Emission Color"].default_value = (*emit, 1)
        if "Emission Strength" in bsdf.inputs:
            bsdf.inputs["Emission Strength"].default_value = emit_s
    return m

mat_body = mat_tex("Blut_Body", TEX)
mat_iris = mat_col("Blut_Iris", (0.75, 0.05, 0.1), 0.2, 0.5, (1.0, 0.08, 0.12), 1.2)
mat_pupil = mat_col("Blut_Pupil", (0.02, 0.0, 0.01), 0.15, 0.3)
mat_tomoe = mat_col("Blut_Tomoe", (0.9, 0.08, 0.12), 0.25, 0.4, (1.0, 0.1, 0.15), 0.8)
mat_stem = mat_col("Blut_Stem", (0.08, 0.06, 0.07), 0.5, 0.2)
mat_leaf = mat_col("Blut_Leaf", (0.35, 0.04, 0.08), 0.4, 0.15, (0.5, 0.02, 0.05), 0.15)
mat_gold = mat_col("Blut_Gold", (0.75, 0.55, 0.15), 0.3, 0.7)

# Larger prestigious body
SIZE = 2.05
bpy.ops.mesh.primitive_cube_add(size=SIZE, location=(0, 0, SIZE * 0.52))
body = bpy.context.active_object
body.name = "Body"
mod = body.modifiers.new("Bevel", "BEVEL")
mod.width = 0.38
mod.segments = 5
mod.limit_method = "ANGLE"
bpy.ops.object.modifier_apply(modifier="Bevel")
bpy.ops.object.mode_set(mode="EDIT")
bpy.ops.mesh.select_all(action="SELECT")
bpy.ops.mesh.subdivide(number_cuts=1)
bpy.ops.uv.smart_project(angle_limit=math.radians(66), island_margin=0.025)
bpy.ops.object.mode_set(mode="OBJECT")
bpy.ops.object.shade_smooth()
body.data.materials.append(mat_body)

# Front eye — raised iris ring + pupil + 3 tomoe (3D, even 120°)
fy = -SIZE * 0.52 + 0.02
fz = SIZE * 0.52
bpy.ops.mesh.primitive_torus_add(
    major_radius=0.48, minor_radius=0.055,
    major_segments=32, minor_segments=10,
    location=(0, fy, fz), rotation=(math.radians(90), 0, 0)
)
iris = bpy.context.active_object
iris.name = "IrisRing"
iris.data.materials.append(mat_iris)
bpy.ops.object.shade_smooth()

bpy.ops.mesh.primitive_uv_sphere_add(segments=16, ring_count=8, radius=0.2, location=(0, fy - 0.02, fz))
pupil = bpy.context.active_object
pupil.name = "Pupil"
pupil.scale = (1, 0.45, 1)
bpy.ops.object.transform_apply(scale=True)
pupil.data.materials.append(mat_pupil)
bpy.ops.object.shade_smooth()

# 3 even tomoe (comma shapes approximated as tapered bent capsules)
tomo_objs = []
for k in range(3):
    ang = -math.pi / 2 + k * (2 * math.pi / 3)
    # position on iris
    r = 0.32
    cx = r * math.cos(ang)
    cz = fz + r * math.sin(ang)
    bpy.ops.mesh.primitive_uv_sphere_add(segments=10, ring_count=6, radius=0.09, location=(cx, fy - 0.04, cz))
    t = bpy.context.active_object
    t.name = f"Tomoe{k}"
    # stretch into comma
    t.scale = (0.55, 0.35, 1.35)
    t.rotation_euler = (math.radians(90), 0, ang + math.pi / 2)
    bpy.ops.object.transform_apply(scale=True, rotation=True)
    # bend: pull tip
    bm = bmesh.new(); bm.from_mesh(t.data)
    for v in bm.verts:
        if v.co.z > 0.05:
            f = (v.co.z - 0.05) / 0.15
            v.co.x += 0.06 * f
    bm.to_mesh(t.data); bm.free()
    t.data.materials.append(mat_tomoe)
    bpy.ops.object.shade_smooth()
    tomo_objs.append(t)

# Dark stem with gold band + red curl tip
stem_z = SIZE * 0.52 + SIZE * 0.52 + 0.1
bpy.ops.mesh.primitive_cylinder_add(vertices=10, radius=0.095, depth=0.62, location=(0, 0, stem_z))
stem = bpy.context.active_object
bm = bmesh.new(); bm.from_mesh(stem.data)
for v in bm.verts:
    t = (v.co.z + 0.31) / 0.62
    if t > 0.4:
        f = (t - 0.4) / 0.6
        v.co.x += 0.32 * f * f
        v.co.z -= 0.16 * f * f
bm.to_mesh(stem.data); bm.free()
stem.data.materials.append(mat_stem)
bpy.ops.object.shade_smooth()

# Gold ring on stem
bpy.ops.mesh.primitive_torus_add(
    major_radius=0.11, minor_radius=0.025,
    major_segments=16, minor_segments=8,
    location=(0, 0, stem_z - 0.18)
)
band = bpy.context.active_object
band.data.materials.append(mat_gold)
bpy.ops.object.shade_smooth()

# 3 dark-red leaves (legendary, not green) — even spread
def leaf(name, loc, rot, sx=0.48):
    bpy.ops.mesh.primitive_circle_add(vertices=12, radius=sx, fill_type="NGON", location=loc)
    o = bpy.context.active_object
    o.name = name
    bpy.ops.object.mode_set(mode="EDIT")
    bpy.ops.mesh.extrude_region_move(TRANSFORM_OT_translate={"value": (0, 0, 0.045)})
    bpy.ops.object.mode_set(mode="OBJECT")
    o.scale = (1.0, 0.4, 1.0)
    bpy.ops.object.transform_apply(scale=True)
    o.rotation_euler = rot
    bpy.ops.object.transform_apply(rotation=True)
    bm = bmesh.new(); bm.from_mesh(o.data)
    for v in bm.verts:
        if v.co.x > 0.05:
            v.co.y *= max(0.1, 1.0 - (v.co.x / sx) * 0.92)
    bm.to_mesh(o.data); bm.free()
    o.data.materials.append(mat_leaf)
    bpy.ops.object.shade_smooth()
    return o

lz = stem_z + 0.32
# evenly 120° around stem
leaves = []
for i, (dx, dy, yaw) in enumerate([
    (0.26, 0.0, 55),
    (-0.15, 0.22, -50),
    (-0.15, -0.22, 200),
]):
    leaves.append(leaf(f"L{i}", (dx, dy, lz - i * 0.02),
                       (math.radians(15), math.radians(yaw), math.radians(i * 20)), 0.46 - i * 0.03))

# Join all
parts = [body, iris, pupil, stem, band] + tomo_objs + leaves
bpy.ops.object.select_all(action="DESELECT")
for o in parts:
    o.select_set(True)
bpy.context.view_layer.objects.active = body
bpy.ops.object.join()
fruit = bpy.context.active_object
fruit.name = "Blutaugespiegel"
bpy.ops.object.origin_set(type="ORIGIN_GEOMETRY", center="BOUNDS")
zs = [v.co.z for v in fruit.data.vertices]
fruit.location.z -= min(zs)
bpy.ops.object.transform_apply(location=True)

print(f"v2: {len(fruit.data.vertices)} verts, {len(fruit.data.polygons)} faces")

# Dramatic preview
bpy.ops.object.camera_add(location=(4.4, -4.0, 3.2))
cam = bpy.context.active_object
cam.rotation_euler = (Vector((0, 0, 1.2)) - cam.location).to_track_quat("-Z", "Y").to_euler()
bpy.context.scene.camera = cam
bpy.ops.object.light_add(type="SUN", location=(4, -2, 8))
bpy.context.active_object.data.energy = 2.0
bpy.ops.object.light_add(type="AREA", location=(-3, 2, 4))
a = bpy.context.active_object; a.data.energy = 35; a.data.size = 4
bpy.ops.object.light_add(type="AREA", location=(2.5, 3, 1.8))
r = bpy.context.active_object; r.data.energy = 40; r.data.size = 2.5; r.data.color = (1.0, 0.12, 0.18)

w = bpy.data.worlds.new("W"); bpy.context.scene.world = w; w.use_nodes = True
w.node_tree.nodes["Background"].inputs[0].default_value = (0.06, 0.04, 0.05, 1)
w.node_tree.nodes["Background"].inputs[1].default_value = 0.4

sc = bpy.context.scene
sc.render.engine = "BLENDER_EEVEE"
sc.render.resolution_x = sc.render.resolution_y = 720
sc.render.filepath = PNG
bpy.ops.render.render(write_still=True)
bpy.ops.wm.save_as_mainfile(filepath=BLEND)
bpy.ops.object.select_all(action="DESELECT"); fruit.select_set(True)
bpy.context.view_layer.objects.active = fruit
bpy.ops.export_scene.fbx(
    filepath=FBX, use_selection=True, apply_scale_options="FBX_SCALE_ALL",
    axis_forward="-Z", axis_up="Y", mesh_smooth_type="FACE",
    path_mode="COPY", embed_textures=True,
)
print("DONE_V2", FBX)
