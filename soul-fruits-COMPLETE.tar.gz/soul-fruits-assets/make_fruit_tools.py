"""Re-export Soul Fruits FBX scaled for Roblox Tool Handle (~1 stud, hand-held)."""
import bpy
from pathlib import Path

OUT = Path("/workspace/soul-fruits-assets")
TOOLS = OUT / "tools"
TOOLS.mkdir(exist_ok=True)

# Source FBX names (without extension)
FRUITS = [
    "DreckFruit",
    "WindFruit",
    "FlameFruit",
    "IceFruit",
    "LightFruit",
    "MagmaFruit",
    "Blutaugespiegel",
    "SharinganFruit",
]

# Target height in Blender units ≈ studs for hand fruit (~1.0–1.2)
TARGET_HEIGHT = 1.05

def wipe():
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)

readme = ["# Soul Fruits — Tool Handles (Physical Fruit)", "",
          "BF-style: Gacha/Stock gives a **Tool**; mesh is the Handle (held in hand).",
          "",
          "| File | Notes |",
          "|------|-------|"]

for name in FRUITS:
    src = OUT / f"{name}.fbx"
    if not src.exists():
        print("MISSING", src)
        continue
    wipe()
    bpy.ops.import_scene.fbx(filepath=str(src))
    objs = [o for o in bpy.context.scene.objects if o.type == "MESH"]
    if not objs:
        print("no mesh", name)
        continue
    bpy.ops.object.select_all(action="DESELECT")
    for o in objs:
        o.select_set(True)
    bpy.context.view_layer.objects.active = objs[0]
    if len(objs) > 1:
        bpy.ops.object.join()
    obj = bpy.context.active_object
    obj.name = "Handle"  # Roblox Tool expects Handle
    # origin bottom-center-ish then geometry center for grip
    bpy.ops.object.origin_set(type="ORIGIN_GEOMETRY", center="BOUNDS")
    # scale to target height
    zs = [v.co.z for v in obj.data.vertices]
    height = max(zs) - min(zs)
    if height < 1e-6:
        height = 1.0
    s = TARGET_HEIGHT / height
    obj.scale = (s, s, s)
    bpy.ops.object.transform_apply(scale=True)
    # sit so origin at geometric center (grip)
    bpy.ops.object.origin_set(type="ORIGIN_GEOMETRY", center="BOUNDS")
    # Move so lowest point slightly below origin (hand grip feel)
    zs = [v.co.z for v in obj.data.vertices]
    mid = (max(zs) + min(zs)) / 2
    for v in obj.data.vertices:
        v.co.z -= mid
    obj.data.update()

    out = TOOLS / f"{name}_Tool.fbx"
    bpy.ops.object.select_all(action="DESELECT")
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.export_scene.fbx(
        filepath=str(out),
        use_selection=True,
        apply_scale_options="FBX_SCALE_ALL",
        axis_forward="-Z",
        axis_up="Y",
        mesh_smooth_type="FACE",
        path_mode="COPY",
        embed_textures=True,
    )
    zs = [v.co.z for v in obj.data.vertices]
    h = max(zs) - min(zs)
    print(f"{name}_Tool height={h:.2f} -> {out}")
    readme.append(f"| `{name}_Tool.fbx` | Mesh named `Handle`, ~{h:.1f} studs tall |")

readme += ["", "## Studio",
           "1. Import FBX → MeshPart/Model",
           "2. Create Tool → rename mesh to **Handle**",
           "3. Weld/parent under Tool; set Grip if needed",
           "4. Attribute `FruitId` = Dreck/Wind/.../Sharingan",
           ""]
(TOOLS / "README.md").write_text("\n".join(readme))
print("DONE tools")
