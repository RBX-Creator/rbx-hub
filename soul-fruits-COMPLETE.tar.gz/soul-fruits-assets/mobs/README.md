# Soul Fruits — Mobs (DEPRECATED block FBXs)

**Nicht nutzen.** Leeam: Mobs sollen normale **R15 Roblox-Spieler-Charaktere** sein (Outfit/HumanoidDescription), keine Block-Meshes.

## Canonical approach
1. R15 character model (Dummy / Toolbox NPC)
2. HumanoidDescription + clothing/accessories per type
3. Wire into `EnemyTemplates` — keep EnemyService scripts

## Planned templates
| Template | Look |
|----------|------|
| Bandit | R15 pirate/bandit outfit |
| MobLeader | R15 darker/elite outfit + cape |
| Affe | R15 jungle-themed player outfit |
| Gorilla | R15 darker, scale ~1.15 |
| GorillaKing | R15 elite, scale ~1.3 + gold accessories |

Block FBX files in this folder are obsolete.
