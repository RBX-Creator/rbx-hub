"""Soul Fruits — Dreck Fruit v2: Blox Fruits style (rounded cube + green stem + swirls)."""
import bpy
import bmesh
import math
from mathutils import Vector, Matrix

OUT = "/workspace/soul-fruits-assets"
BLEND = f"{OUT}/DreckFruit.blend"
FBX = f"{OUT}/DreckFruit.fbx"
PNG = f"{OUT}/DreckFruit_preview.png"

# clean
bpy.ops.object.select_all(action="SELECT")
bpy.ops.object.delete(use_global=False)
for m in list(bpy.data.meshes):
    bpy.data.meshes.remove(m)
for m in list(bpy.data.materials):
    bpy.data.materials.remove(m)

def new_mat(name, color, roughness=0.55, metallic=0.0):
    m = bpy.data.materials.new(name=name)
    m.use_nodes = True
    bsdf = m.node_tree.nodes.get("Principled BSDF")
    if bsdf:
        bsdf.inputs["Base Color"].default_value = (*color, 1.0)
        bsdf.inputs["Roughness"].default_value = roughness
        if "Metallic" in bsdf.inputs:
            bsdf.inputs["Metallic"].default_value = metallic
    return m

mat_body = new_mat("Dreck_Body", (0.55, 0.36, 0.20), 0.7)       # warm dirt brown
mat_swirl = new_mat("Dreck_Swirl", (0.32, 0.20, 0.10), 0.85)     # darker grooves
mat_stem = new_mat("Dreck_Stem", (0.20, 0.55, 0.18), 0.45)       # BF green
mat_leaf = new_mat("Dreck_Leaf", (0.28, 0.72, 0.22), 0.4)

# --- Rounded cube body (classic BF silhouette) ---
bpy.ops.mesh.primitive_cube_add(size=1.6, location=(0, 0, 0.85))
body = bpy.context.active_object
body.name = "DreckFruit_Body"

# Bevel for rounded cube look
bpy.ops.object.modifier_add(type="BEVEL")
bev = body.modifiers["Bevel"]
bev.width = 0.22
bev.segments = 3
bev.limit_method = "ANGLE"
bpy.ops.object.modifier_apply(modifier="Bevel")

# Subdivide a bit for swirl carving
bpy.ops.object.mode_set(mode="EDIT")
bpy.ops.mesh.select_all(action="SELECT")
bpy.ops.mesh.subdivide(number_cuts=2)
bpy.ops.object.mode_set(mode="OBJECT")

# Carve classic devil-fruit style spiral grooves by pushing verts
me = body.data
bm = bmesh.new()
bm.from_mesh(me)
bm.verts.ensure_lookup_table()

# For each face-center-ish, push spiral pattern based on angle around face normal
# Simpler: radial swirl displacement on surface
for v in bm.verts:
    p = v.co.copy()
    # local around body center
    c = Vector((0, 0, 0.85))
    rel = p - c
    # cylindrical angle around Z for side swirls
    ang = math.atan2(rel.y, rel.x)
    # height factor
    h = (rel.z + 0.8) / 1.6
    # classic BF: multiple spiral "petals" / swirl ridges
    swirl = math.sin(ang * 3.0 + h * 6.0) * 0.045
    swirl2 = math.sin(ang * 6.0 - h * 4.0) * 0.02
    # also slight face indent for cube-face readability
    ax = abs(rel.x)
    ay = abs(rel.y)
    az = abs(rel.z)
    n = rel.normalized() if rel.length > 1e-6 else Vector((0, 0, 1))
    v.co = p + n * (swirl + swirl2)

bm.to_mesh(me)
bm.free()
me.update()

# Flat-ish shading with some smooth for rounded edges
for poly in me.polygons:
    poly.use_smooth = True
bpy.ops.object.shade_smooth()

body.data.materials.append(mat_body)
body.data.materials.append(mat_swirl)

# Assign darker material to "groove" faces (inward normals relative to neighbors — use face center offset)
# Approximate: faces whose center is closer to object center get swirl mat
origin = Vector((0, 0, 0.85))
for poly in me.polygons:
    center = sum((me.vertices[i].co for i in poly.vertices), Vector()) / len(poly.vertices)
    dist = (center - origin).length
    # outer faces brighter, slightly inset darker
    poly.material_index = 1 if dist < 0.95 else 0

# --- Green stem (BF signature) ---
bpy.ops.mesh.primitive_cylinder_add(
    vertices=8, radius=0.07, depth=0.45, location=(0, 0, 1.85)
)
stem = bpy.context.active_object
stem.name = "DreckFruit_Stem"
# curl tip: bend with lattice-ish by editing top verts
bpy.ops.object.mode_set(mode="EDIT")
bpy.ops.mesh.select_all(action="DESELECT")
bpy.ops.object.mode_set(mode="OBJECT")
bm = bmesh.new()
bm.from_mesh(stem.data)
bm.verts.ensure_lookup_table()
for v in bm.verts:
    # bend top toward +X like a hook/curl
    t = (v.co.z + 0.225) / 0.45  # 0 bottom .. 1 top
    if t > 0.45:
        f = (t - 0.45) / 0.55
        v.co.x += 0.18 * f * f
        v.co.z -= 0.08 * f
bm.to_mesh(stem.data)
bm.free()
stem.data.materials.append(mat_stem)
for p in stem.data.polygons:
    p.use_smooth = True

# --- Three small green leaves (BF clover/palm top) ---
def make_leaf(name, loc, rot, scale=(0.35, 0.18, 0.05)):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=10, ring_count=6, radius=1.0, location=loc)
    leaf = bpy.context.active_object
    leaf.name = name
    leaf.scale = scale
    leaf.rotation_euler = rot
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
    # flatten tip
    bm = bmesh.new()
    bm.from_mesh(leaf.data)
    for v in bm.verts:
        # elongate along local X already applied — pinch one end
        if v.co.x > 0.05:
            v.co.y *= 0.7
            v.co.z *= 0.7
    bm.to_mesh(leaf.data)
    bm.free()
    leaf.data.materials.append(mat_leaf)
    for p in leaf.data.polygons:
        p.use_smooth = True
    return leaf

leaf1 = make_leaf("Leaf1", (0.18, 0.05, 2.05), (math.radians(25), math.radians(50), math.radians(10)))
leaf2 = make_leaf("Leaf2", (-0.12, 0.14, 2.02), (math.radians(20), math.radians(-55), math.radians(40)), (0.32, 0.16, 0.045))
leaf3 = make_leaf("Leaf3", (-0.05, -0.16, 2.00), (math.radians(30), math.radians(15), math.radians(-70)), (0.28, 0.14, 0.04))

# --- optional tiny dirt pebbles on corners for "Dreck" theme (subtle) ---
pebbles = []
for i, (lx, ly, lz) in enumerate([
    (0.7, 0.7, 0.35), (-0.65, 0.55, 0.3), (0.5, -0.7, 0.28), (-0.55, -0.6, 1.35)
]):
    bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=1, radius=0.08 + 0.02 * (i % 2), location=(lx, ly, lz))
    peb = bpy.context.active_object
    peb.name = f"Pebble{i}"
    peb.scale = (1.0, 0.85, 0.7)
    bpy.ops.object.transform_apply(scale=True)
    peb.data.materials.append(mat_swirl)
    for p in peb.data.polygons:
        p.use_smooth = False
    pebbles.append(peb)

# --- Join all into one mesh ---
bpy.ops.object.select_all(action="DESELECT")
parts = [body, stem, leaf1, leaf2, leaf3] + pebbles
for o in parts:
    o.select_set(True)
bpy.context.view_layer.objects.active = body
bpy.ops.object.join()
fruit = bpy.context.active_object
fruit.name = "DreckFruit"

bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
bpy.ops.object.origin_set(type="ORIGIN_GEOMETRY", center="BOUNDS")
# sit on ground
zs = [v.co.z for v in fruit.data.vertices]
fruit.location.z -= min(zs)
bpy.ops.object.transform_apply(location=True)

# Scale to ~Roblox-friendly size (~2 studs tall-ish in blender units)
# keep as-is; Leeam can scale in Studio

verts = len(fruit.data.vertices)
faces = len(fruit.data.polygons)
print(f"DreckFruit v2: {verts} verts, {faces} faces")

# --- Preview render ---
bpy.ops.object.camera_add(location=(3.6, -3.4, 2.6))
cam = bpy.context.active_object
direction = Vector((0, 0, 1.0)) - cam.location
cam.rotation_euler = direction.to_track_quat("-Z", "Y").to_euler()
bpy.context.scene.camera = cam

bpy.ops.object.light_add(type="SUN", location=(3, -2, 6))
bpy.context.active_object.data.energy = 2.8
bpy.ops.object.light_add(type="AREA", location=(-2.5, 2, 3.5))
fill = bpy.context.active_object
fill.data.energy = 50
fill.data.size = 4

world = bpy.data.worlds.new("W")
bpy.context.scene.world = world
world.use_nodes = True
world.node_tree.nodes["Background"].inputs[0].default_value = (0.62, 0.64, 0.68, 1)
world.node_tree.nodes["Background"].inputs[1].default_value = 1.0

scene = bpy.context.scene
scene.render.engine = "BLENDER_EEVEE"
scene.render.resolution_x = 640
scene.render.resolution_y = 640
scene.render.filepath = PNG
bpy.ops.render.render(write_still=True)
print("Preview saved", PNG)

bpy.ops.wm.save_as_mainfile(filepath=BLEND)

bpy.ops.object.select_all(action="DESELECT")
fruit.select_set(True)
bpy.context.view_layer.objects.active = fruit
bpy.ops.export_scene.fbx(
    filepath=FBX,
    use_selection=True,
    apply_scale_options="FBX_SCALE_ALL",
    axis_forward="-Z",
    axis_up="Y",
    mesh_smooth_type="FACE",
    use_mesh_modifiers=True,
)
print("FBX saved", FBX)
print("DONE_V2")
