"""Soul Fruits — simple low-poly mobs for EnemyTemplates (Bandit, Affe, Gorilla, MobLeader, GorillaKing)."""
import bpy, bmesh, math
from mathutils import Vector
from pathlib import Path

OUT = Path("/workspace/soul-fruits-assets/mobs")
OUT.mkdir(parents=True, exist_ok=True)

def wipe():
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)
    for coll in (bpy.data.meshes, bpy.data.materials):
        for b in list(coll):
            coll.remove(b)

def mat(name, color, rough=0.7):
    m = bpy.data.materials.new(name=name)
    m.use_nodes = True
    bsdf = m.node_tree.nodes["Principled BSDF"]
    bsdf.inputs["Base Color"].default_value = (*color, 1)
    bsdf.inputs["Roughness"].default_value = rough
    return m

def ground(obj):
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.origin_set(type="ORIGIN_GEOMETRY", center="BOUNDS")
    zs = [v.co.z for v in obj.data.vertices]
    obj.location.z -= min(zs)
    bpy.ops.object.transform_apply(location=True)

def join_named(name, parts):
    bpy.ops.object.select_all(action="DESELECT")
    for o in parts:
        o.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()
    obj = bpy.context.active_object
    obj.name = name
    ground(obj)
    return obj

def export_all(obj, stem, cam=(3.5, -3.5, 2.8), look=(0, 0, 1.0)):
    # clear old lights/cams
    for o in list(bpy.data.objects):
        if o.type in {"LIGHT", "CAMERA"} and o != obj:
            bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.object.camera_add(location=cam)
    camo = bpy.context.active_object
    camo.rotation_euler = (Vector(look) - camo.location).to_track_quat("-Z", "Y").to_euler()
    bpy.context.scene.camera = camo
    bpy.ops.object.light_add(type="SUN", location=(4, -2, 7))
    bpy.context.active_object.data.energy = 2.8
    bpy.ops.object.light_add(type="AREA", location=(-2, 2, 3))
    a = bpy.context.active_object; a.data.energy = 45; a.data.size = 4
    if "W" not in bpy.data.worlds:
        w = bpy.data.worlds.new("W"); w.use_nodes = True
        w.node_tree.nodes["Background"].inputs[0].default_value = (0.55, 0.58, 0.6, 1)
        bpy.context.scene.world = w
    else:
        bpy.context.scene.world = bpy.data.worlds["W"]
    sc = bpy.context.scene
    sc.render.engine = "BLENDER_EEVEE"
    sc.render.resolution_x = sc.render.resolution_y = 512
    png = str(OUT / f"{stem}_preview.png")
    sc.render.filepath = png
    bpy.ops.render.render(write_still=True)
    bpy.ops.wm.save_as_mainfile(filepath=str(OUT / f"{stem}.blend"))
    bpy.ops.object.select_all(action="DESELECT")
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    fbx = str(OUT / f"{stem}.fbx")
    bpy.ops.export_scene.fbx(
        filepath=fbx, use_selection=True, apply_scale_options="FBX_SCALE_ALL",
        axis_forward="-Z", axis_up="Y", mesh_smooth_type="FACE",
    )
    print(stem, len(obj.data.vertices), "verts")
    return fbx

def add_box(loc, scale, material, name="Part"):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=loc)
    o = bpy.context.active_object
    o.name = name
    o.scale = scale
    bpy.ops.object.transform_apply(scale=True)
    o.data.materials.append(material)
    return o

def add_sphere(loc, radius, material, name="Part", segments=12):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=segments, ring_count=max(6, segments // 2), radius=radius, location=loc)
    o = bpy.context.active_object
    o.name = name
    o.data.materials.append(material)
    bpy.ops.object.shade_smooth()
    return o

def add_cyl(loc, radius, depth, material, name="Part", verts=8):
    bpy.ops.mesh.primitive_cylinder_add(vertices=verts, radius=radius, depth=depth, location=loc)
    o = bpy.context.active_object
    o.name = name
    o.data.materials.append(material)
    return o

# ---------- BANDIT (humanoid blocky) ----------
wipe()
skin = mat("BanditSkin", (0.72, 0.55, 0.42))
cloth = mat("BanditCloth", (0.25, 0.28, 0.35))
dark = mat("BanditDark", (0.15, 0.12, 0.1))
accent = mat("BanditRed", (0.55, 0.12, 0.12))  # Gut/Böse-neutral bandit scarf
parts = []
parts.append(add_box((0, 0, 1.15), (0.55, 0.3, 0.7), cloth, "Torso"))
parts.append(add_sphere((0, 0, 1.75), 0.28, skin, "Head", 10))
parts.append(add_box((-0.4, 0, 1.15), (0.18, 0.18, 0.55), skin, "ArmL"))
parts.append(add_box((0.4, 0, 1.15), (0.18, 0.18, 0.55), skin, "ArmR"))
parts.append(add_box((-0.18, 0, 0.45), (0.2, 0.22, 0.55), dark, "LegL"))
parts.append(add_box((0.18, 0, 0.45), (0.2, 0.22, 0.55), dark, "LegR"))
# bandana
parts.append(add_box((0, -0.05, 1.88), (0.32, 0.32, 0.08), accent, "Bandana"))
# simple sword on back
parts.append(add_box((0.15, 0.22, 1.3), (0.06, 0.06, 0.7), dark, "Sword"))
bandit = join_named("Bandit", parts)
export_all(bandit, "Bandit", cam=(3.2, -3.2, 2.6), look=(0, 0, 1.1))

# ---------- AFFE (monkey) ----------
wipe()
fur = mat("AffeFur", (0.45, 0.28, 0.15))
face = mat("AffeFace", (0.75, 0.55, 0.4))
parts = []
parts.append(add_sphere((0, 0, 0.85), 0.45, fur, "Body", 12))
parts.append(add_sphere((0, 0.15, 1.35), 0.32, face, "Head", 10))
# ears
parts.append(add_sphere((-0.28, 0.05, 1.45), 0.12, fur, "EarL", 8))
parts.append(add_sphere((0.28, 0.05, 1.45), 0.12, fur, "EarR", 8))
# limbs
parts.append(add_cyl((-0.35, 0.1, 0.55), 0.08, 0.55, fur, "ArmL"))
parts.append(add_cyl((0.35, 0.1, 0.55), 0.08, 0.55, fur, "ArmR"))
parts.append(add_cyl((-0.18, -0.05, 0.28), 0.09, 0.4, fur, "LegL"))
parts.append(add_cyl((0.18, -0.05, 0.28), 0.09, 0.4, fur, "LegR"))
# tail
bpy.ops.mesh.primitive_cylinder_add(vertices=6, radius=0.05, depth=0.6, location=(0, -0.45, 0.7), rotation=(math.radians(70), 0, 0))
tail = bpy.context.active_object
tail.data.materials.append(fur)
parts.append(tail)
affe = join_named("Affe", parts)
export_all(affe, "Affe", cam=(3.0, -3.0, 2.2), look=(0, 0, 0.9))

# ---------- GORILLA ----------
wipe()
fur = mat("GorFur", (0.22, 0.2, 0.22))
skin = mat("GorSkin", (0.55, 0.4, 0.32))
parts = []
parts.append(add_sphere((0, 0, 1.0), 0.7, fur, "Body", 12))
parts.append(add_sphere((0, 0.25, 1.55), 0.4, skin, "Head", 10))
parts.append(add_cyl((-0.55, 0.15, 0.7), 0.16, 0.85, fur, "ArmL", 8))
parts.append(add_cyl((0.55, 0.15, 0.7), 0.16, 0.85, fur, "ArmR", 8))
parts.append(add_cyl((-0.25, -0.1, 0.35), 0.16, 0.5, fur, "LegL", 8))
parts.append(add_cyl((0.25, -0.1, 0.35), 0.16, 0.5, fur, "LegR", 8))
# brow ridge
parts.append(add_box((0, 0.45, 1.7), (0.45, 0.12, 0.1), fur, "Brow"))
gorilla = join_named("Gorilla", parts)
export_all(gorilla, "Gorilla", cam=(4.0, -4.0, 3.0), look=(0, 0, 1.1))

# ---------- MOB LEADER (bandit boss - taller + cape) ----------
wipe()
skin = mat("LeadSkin", (0.7, 0.52, 0.4))
cloth = mat("LeadCloth", (0.15, 0.18, 0.28))
gold = mat("LeadGold", (0.75, 0.6, 0.2), 0.4)
dark = mat("LeadDark", (0.1, 0.1, 0.12))
parts = []
parts.append(add_box((0, 0, 1.35), (0.65, 0.35, 0.85), cloth, "Torso"))
parts.append(add_sphere((0, 0, 2.05), 0.32, skin, "Head", 10))
parts.append(add_box((-0.48, 0, 1.35), (0.2, 0.2, 0.65), skin, "ArmL"))
parts.append(add_box((0.48, 0, 1.35), (0.2, 0.2, 0.65), skin, "ArmR"))
parts.append(add_box((-0.2, 0, 0.5), (0.22, 0.24, 0.65), dark, "LegL"))
parts.append(add_box((0.2, 0, 0.5), (0.22, 0.24, 0.65), dark, "LegR"))
# cape
parts.append(add_box((0, 0.28, 1.2), (0.7, 0.08, 1.0), dark, "Cape"))
# crown/spike
parts.append(add_box((0, 0, 2.35), (0.25, 0.25, 0.15), gold, "Crown"))
leader = join_named("MobLeader", parts)
export_all(leader, "MobLeader", cam=(3.5, -3.5, 3.0), look=(0, 0, 1.3))

# ---------- GORILLA KING ----------
wipe()
fur = mat("KingFur", (0.18, 0.15, 0.14))
skin = mat("KingSkin", (0.5, 0.35, 0.28))
gold = mat("KingGold", (0.8, 0.65, 0.15), 0.35)
parts = []
parts.append(add_sphere((0, 0, 1.25), 0.95, fur, "Body", 12))
parts.append(add_sphere((0, 0.3, 2.0), 0.5, skin, "Head", 10))
parts.append(add_cyl((-0.75, 0.2, 0.85), 0.22, 1.1, fur, "ArmL", 8))
parts.append(add_cyl((0.75, 0.2, 0.85), 0.22, 1.1, fur, "ArmR", 8))
parts.append(add_cyl((-0.32, -0.1, 0.4), 0.22, 0.6, fur, "LegL", 8))
parts.append(add_cyl((0.32, -0.1, 0.4), 0.22, 0.6, fur, "LegR", 8))
parts.append(add_box((0, 0.55, 2.15), (0.55, 0.15, 0.12), fur, "Brow"))
# gold belt
parts.append(add_cyl((0, 0, 1.0), 0.85, 0.12, gold, "Belt", 12))
king = join_named("GorillaKing", parts)
export_all(king, "GorillaKing", cam=(5.0, -5.0, 3.5), look=(0, 0, 1.3))

print("ALL_MOBS_DONE")
