# Soul Fruits — Roblox Toolbox Plan (Free assets)

Leeam: Team may use **free** Toolbox / Creator Store models as templates (look + scripts), if they understand what’s inside.

## Rules
1. Free / clearly usable only
2. Inspect scripts — strip unknown/obfuscated; prefer our `EnemyService` / `QuestService` / AntiCheat
3. Mobs & NPCs = **R15 player-like** characters
4. Keep WorldBootstrap pad names / quest tags

## Toolbox search terms
### Enemies
- `R15 NPC`, `R15 Dummy`, `Pirate NPC`, `Bandit NPC`, `Enemy AI R15`
- Chase/pathfinding packs = reference only → wire to EnemyService

### Quest / Shop NPCs
- `Quest NPC`, `Dialogue NPC`, `ProximityPrompt NPC`, `R15 Merchant`

### Spots / props
- `Boat`, `Ship`, `Spawn Location`, `Shop Counter`, `Banner`, `Crate`, `Rock`

### Anim
- `R15 Animate` (stock animate script in NPC)

## Template mapping
| Our template | Search / approach |
|--------------|-------------------|
| Bandit | Pirate/Bandit R15 outfit |
| MobLeader | Darker R15 + cape/crown accessory |
| Affe | R15 jungle-themed player outfit |
| Gorilla | R15 darker, scale ~1.15 |
| GorillaKing | R15 elite, scale ~1.3 + gold accessories |
| Quest NPCs | Dialogue/Quest NPC R15 |
| Boot-Händler | Merchant / pirate captain R15 |

## Studio workflow
1. Toolbox → Get free model
2. Delete foreign Scripts/LocalScripts (or quarantine)
3. Ensure R15 Humanoid + Animate
4. Parent into `EnemyTemplates` / Quest NPC folder
5. Set attributes for EnemyService / QuestService

## Outlaw Village (v1.9.2)
| Template | Toolbox search |
|----------|----------------|
| Outlaw | `Pirate NPC` `Bandit R15` `R15 Pirate` |
| Brute | `R15 Brute` `Strong NPC` `R15 Thug` (scale ~1.2) |
| ClownCaptain | `Clown NPC` `Pirate Captain R15` + hat accessory |

## Desert Island (v1.9.3)
| Template | Toolbox search |
|----------|----------------|
| DesertBandit | `Desert Bandit` `Sand Pirate R15` `R15 Bandit` |
| DesertOfficer | `Soldier NPC` `Guard R15` `Marine NPC` |
| SandKing | `King NPC` `Desert Boss R15` + gold accessories (scale ~1.3) |

## When Leeam is at PC
1. Rojo / mirror `/workspace/soul-fruits-foundation`
2. Toolbox → free R15 models per table → strip foreign scripts
3. Drop into `EnemyTemplates` matching names
4. Play Solo: Faction → Quests → Pads
5. Fruits FBX: `/workspace/soul-fruits-assets/*.fbx`
6. Props: `/workspace/soul-fruits-assets/props/`
