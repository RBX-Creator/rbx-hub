"""Build a Blox-Fruits-style Soul Fruit: rounded cube + stem + 3 leaves + texture."""
import bpy, bmesh, math, sys
from mathutils import Vector
from pathlib import Path

name = sys.argv[sys.argv.index("--")+1] if "--" in sys.argv else "WindFruit"
# optional color overrides for stem via argv
OUT = Path("/workspace/soul-fruits-assets")
TEX = str(OUT / f"{name}_tex.png")
BLEND = str(OUT / f"{name}.blend")
FBX = str(OUT / f"{name}.fbx")
PNG = str(OUT / f"{name}_preview.png")

# theme presets
themes = {
    "WindFruit": dict(stem=(0.15,0.55,0.2), leaf=(0.25,0.75,0.3), world=(0.55,0.7,0.72), emit=(0.4,0.9,0.8), emit_s=0.08, metal=0.05, rough=0.45, size=1.7),
    "FlameFruit": dict(stem=(0.15,0.5,0.15), leaf=(0.2,0.65,0.18), world=(0.35,0.22,0.18), emit=(1.0,0.35,0.05), emit_s=0.25, metal=0.1, rough=0.4, size=1.75),
    "IceFruit": dict(stem=(0.12,0.4,0.35), leaf=(0.35,0.7,0.75), world=(0.45,0.55,0.65), emit=(0.5,0.8,1.0), emit_s=0.2, metal=0.35, rough=0.25, size=1.72),
    "LightFruit": dict(stem=(0.2,0.55,0.15), leaf=(0.35,0.8,0.25), world=(0.7,0.7,0.55), emit=(1.0,0.95,0.5), emit_s=0.35, metal=0.15, rough=0.3, size=1.72),
    "MagmaFruit": dict(stem=(0.12,0.35,0.1), leaf=(0.18,0.45,0.12), world=(0.25,0.15,0.12), emit=(1.0,0.3,0.05), emit_s=0.3, metal=0.2, rough=0.5, size=1.78),
    "Blutaugespiegel": dict(stem=(0.08,0.06,0.07), leaf=(0.4,0.05,0.08), world=(0.08,0.05,0.06), emit=(0.9,0.08,0.12), emit_s=0.55, metal=0.4, rough=0.22, size=1.95),
}
th = themes.get(name, themes["WindFruit"])

bpy.ops.object.select_all(action="SELECT")
bpy.ops.object.delete(use_global=False)
for coll in (bpy.data.meshes, bpy.data.materials, bpy.data.images):
    for b in list(coll):
        coll.remove(b)

def mat_tex(mname, path, rough, metal, emit, emit_s):
    m = bpy.data.materials.new(name=mname)
    m.use_nodes = True
    bsdf = m.node_tree.nodes["Principled BSDF"]
    tex = m.node_tree.nodes.new("ShaderNodeTexImage")
    tex.image = bpy.data.images.load(path)
    tex.interpolation = "Closest"
    m.node_tree.links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    bsdf.inputs["Roughness"].default_value = rough
    if "Metallic" in bsdf.inputs:
        bsdf.inputs["Metallic"].default_value = metal
    if "Emission Color" in bsdf.inputs:
        bsdf.inputs["Emission Color"].default_value = (*emit, 1)
        if "Emission Strength" in bsdf.inputs:
            bsdf.inputs["Emission Strength"].default_value = emit_s
    return m

def mat_col(mname, color, rough=0.4):
    m = bpy.data.materials.new(name=mname)
    m.use_nodes = True
    bsdf = m.node_tree.nodes["Principled BSDF"]
    bsdf.inputs["Base Color"].default_value = (*color, 1)
    bsdf.inputs["Roughness"].default_value = rough
    return m

mat_body = mat_tex(f"{name}_Body", TEX, th["rough"], th["metal"], th["emit"], th["emit_s"])
mat_stem = mat_col(f"{name}_Stem", th["stem"])
mat_leaf = mat_col(f"{name}_Leaf", th["leaf"], 0.35)

sz = th["size"]
bpy.ops.mesh.primitive_cube_add(size=sz, location=(0, 0, sz*0.55))
body = bpy.context.active_object
body.name = "Body"
mod = body.modifiers.new("Bevel", "BEVEL")
mod.width = 0.28; mod.segments = 4; mod.limit_method = "ANGLE"
bpy.ops.object.modifier_apply(modifier="Bevel")
bpy.ops.object.mode_set(mode="EDIT")
bpy.ops.mesh.select_all(action="SELECT")
bpy.ops.mesh.subdivide(number_cuts=1)
bpy.ops.uv.smart_project(angle_limit=math.radians(66), island_margin=0.03)
bpy.ops.object.mode_set(mode="OBJECT")
bpy.ops.object.shade_smooth()
body.data.materials.append(mat_body)

stem_z = sz*0.55 + sz*0.55 + 0.15
bpy.ops.mesh.primitive_cylinder_add(vertices=8, radius=0.08, depth=0.48, location=(0,0,stem_z))
stem = bpy.context.active_object
bm = bmesh.new(); bm.from_mesh(stem.data)
for v in bm.verts:
    t = (v.co.z + 0.24)/0.48
    if t > 0.4:
        f = (t-0.4)/0.6
        v.co.x += 0.22*f*f; v.co.z -= 0.1*f*f
bm.to_mesh(stem.data); bm.free()
stem.data.materials.append(mat_stem)
bpy.ops.object.shade_smooth()

def leaf(nm, loc, rot, sx=0.4):
    bpy.ops.mesh.primitive_circle_add(vertices=10, radius=sx, fill_type="NGON", location=loc)
    o = bpy.context.active_object; o.name = nm
    bpy.ops.object.mode_set(mode="EDIT")
    bpy.ops.mesh.extrude_region_move(TRANSFORM_OT_translate={"value":(0,0,0.04)})
    bpy.ops.object.mode_set(mode="OBJECT")
    o.scale=(1,0.42,1); bpy.ops.object.transform_apply(scale=True)
    o.rotation_euler=rot; bpy.ops.object.transform_apply(rotation=True)
    bm=bmesh.new(); bm.from_mesh(o.data)
    for v in bm.verts:
        if v.co.x>0.05: v.co.y *= max(0.12, 1-(v.co.x/sx)*0.9)
    bm.to_mesh(o.data); bm.free()
    o.data.materials.append(mat_leaf); bpy.ops.object.shade_smooth()
    return o

lz = stem_z + 0.28
l1=leaf("L1",(0.22,0,lz),(math.radians(12),math.radians(55),0))
l2=leaf("L2",(-0.12,0.18,lz-0.02),(math.radians(18),math.radians(-50),math.radians(30)),0.36)
l3=leaf("L3",(-0.08,-0.18,lz-0.04),(math.radians(22),math.radians(15),math.radians(-95)),0.32)

bpy.ops.object.select_all(action="DESELECT")
for o in (body,stem,l1,l2,l3): o.select_set(True)
bpy.context.view_layer.objects.active=body
bpy.ops.object.join()
fruit=bpy.context.active_object; fruit.name=name
bpy.ops.object.origin_set(type="ORIGIN_GEOMETRY", center="BOUNDS")
zs=[v.co.z for v in fruit.data.vertices]
fruit.location.z -= min(zs); bpy.ops.object.transform_apply(location=True)
print(f"{name}: {len(fruit.data.vertices)}v {len(fruit.data.polygons)}f")

bpy.ops.object.camera_add(location=(3.8,-3.5,2.8))
cam=bpy.context.active_object
cam.rotation_euler=(Vector((0,0,1.0))-cam.location).to_track_quat("-Z","Y").to_euler()
bpy.context.scene.camera=cam
bpy.ops.object.light_add(type="SUN", location=(4,-2,7)); bpy.context.active_object.data.energy=2.8
bpy.ops.object.light_add(type="AREA", location=(-2.5,2,3.5)); bpy.context.active_object.data.energy=50; bpy.context.active_object.data.size=4
w=bpy.data.worlds.new("W"); bpy.context.scene.world=w; w.use_nodes=True
w.node_tree.nodes["Background"].inputs[0].default_value=(*th["world"],1)
sc=bpy.context.scene; sc.render.engine="BLENDER_EEVEE"; sc.render.resolution_x=sc.render.resolution_y=640
sc.render.filepath=PNG; bpy.ops.render.render(write_still=True)
bpy.ops.wm.save_as_mainfile(filepath=BLEND)
bpy.ops.object.select_all(action="DESELECT"); fruit.select_set(True)
bpy.context.view_layer.objects.active=fruit
bpy.ops.export_scene.fbx(filepath=FBX, use_selection=True, apply_scale_options="FBX_SCALE_ALL",
    axis_forward="-Z", axis_up="Y", mesh_smooth_type="FACE", path_mode="COPY", embed_textures=True)
print("DONE", name)
