# Soul Fruits — Tool Handles (Physical Fruit)

BF-style: Gacha/Stock gives a **Tool**; mesh is the Handle (held in hand).

| File | Notes |
|------|-------|
| `DreckFruit_Tool.fbx` | Mesh named `Handle`, ~1.0 studs tall |
| `WindFruit_Tool.fbx` | Mesh named `Handle`, ~1.1 studs tall |
| `FlameFruit_Tool.fbx` | Mesh named `Handle`, ~1.1 studs tall |
| `IceFruit_Tool.fbx` | Mesh named `Handle`, ~1.1 studs tall |
| `LightFruit_Tool.fbx` | Mesh named `Handle`, ~1.1 studs tall |
| `MagmaFruit_Tool.fbx` | Mesh named `Handle`, ~1.1 studs tall |
| `Blutaugespiegel_Tool.fbx` | Mesh named `Handle`, ~1.0 studs tall |
| `SharinganFruit_Tool.fbx` | Mesh named `Handle`, ~1.0 studs tall |

## Studio
1. Import FBX → MeshPart/Model
2. Create Tool → rename mesh to **Handle**
3. Weld/parent under Tool; set Grip if needed
4. Attribute `FruitId` = Dreck/Wind/.../Sharingan
