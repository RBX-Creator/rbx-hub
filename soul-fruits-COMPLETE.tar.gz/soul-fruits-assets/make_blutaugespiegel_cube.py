"""Blutaugespiegel — BF cube ONLY (~1.2x), soft bevel, glass/blood, clear Sharingan tex, dark leaves."""
import bpy, bmesh, math
from mathutils import Vector
from pathlib import Path

OUT = Path("/workspace/soul-fruits-assets")
TEX = str(OUT / "Blutaugespiegel_tex.png")
BLEND = str(OUT / "Blutaugespiegel.blend")
FBX = str(OUT / "Blutaugespiegel.fbx")
PNG = str(OUT / "Blutaugespiegel_preview.png")

bpy.ops.object.select_all(action="SELECT")
bpy.ops.object.delete(use_global=False)
for coll in (bpy.data.meshes, bpy.data.materials, bpy.data.images):
    for b in list(coll):
        coll.remove(b)

def mat_col(name, color, rough=0.4, metal=0.0, emit=None, emit_s=0.0, spec=0.5):
    m = bpy.data.materials.new(name=name)
    m.use_nodes = True
    bsdf = m.node_tree.nodes["Principled BSDF"]
    bsdf.inputs["Base Color"].default_value = (*color, 1)
    bsdf.inputs["Roughness"].default_value = rough
    if "Metallic" in bsdf.inputs:
        bsdf.inputs["Metallic"].default_value = metal
    if "Specular IOR Level" in bsdf.inputs:
        bsdf.inputs["Specular IOR Level"].default_value = spec
    if emit and "Emission Color" in bsdf.inputs:
        bsdf.inputs["Emission Color"].default_value = (*emit, 1)
        if "Emission Strength" in bsdf.inputs:
            bsdf.inputs["Emission Strength"].default_value = emit_s
    return m

# Glass/blood body
m = bpy.data.materials.new(name="Blut_Body")
m.use_nodes = True
nt = m.node_tree
nodes, links = nt.nodes, nt.links
bsdf = nodes["Principled BSDF"]
tex = nodes.new("ShaderNodeTexImage")
tex.image = bpy.data.images.load(TEX)
tex.interpolation = "Linear"
links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
bsdf.inputs["Roughness"].default_value = 0.12  # stronger glass bevel highlights
if "Metallic" in bsdf.inputs:
    bsdf.inputs["Metallic"].default_value = 0.42
if "Specular IOR Level" in bsdf.inputs:
    bsdf.inputs["Specular IOR Level"].default_value = 1.0
# subtle emission — pattern reads, not whole fruit neon
if "Emission Color" in bsdf.inputs:
    bsdf.inputs["Emission Color"].default_value = (0.5, 0.04, 0.07, 1)
    if "Emission Strength" in bsdf.inputs:
        bsdf.inputs["Emission Strength"].default_value = 0.18
# slight transmission for glassy edge if available
if "Transmission Weight" in bsdf.inputs:
    bsdf.inputs["Transmission Weight"].default_value = 0.08

mat_stem = mat_col("Blut_Stem", (0.06, 0.08, 0.05), 0.55, 0.15, spec=0.4)
# dark green with wine feel (base leaf color)
mat_leaf = mat_col("Blut_Leaf", (0.12, 0.22, 0.1), 0.45, 0.05, (0.25, 0.02, 0.05), 0.08, 0.45)
mat_leaf_edge = mat_col("Blut_LeafEdge", (0.45, 0.08, 0.12), 0.4, 0.1)  # wine rim approx via 2nd mat unused if single mesh

# ~1.2× vs typical 1.7 element fruits → ~2.04
SIZE = 2.05
bpy.ops.mesh.primitive_cube_add(size=SIZE, location=(0, 0, SIZE * 0.52))
body = bpy.context.active_object
body.name = "Body"

# Softer/rounder bevel
mod = body.modifiers.new("Bevel", "BEVEL")
mod.width = 0.36
mod.segments = 5
mod.limit_method = "ANGLE"
bpy.ops.object.modifier_apply(modifier="Bevel")

bpy.ops.object.mode_set(mode="EDIT")
bpy.ops.mesh.select_all(action="SELECT")
bpy.ops.mesh.subdivide(number_cuts=1)
bpy.ops.uv.cube_project(cube_size=SIZE * 1.05, correct_aspect=True, scale_to_bounds=True)
bpy.ops.object.mode_set(mode="OBJECT")
bpy.ops.object.shade_smooth()
body.data.materials.append(m)

stem_z = SIZE * 0.52 + SIZE * 0.52 + 0.14
bpy.ops.mesh.primitive_cylinder_add(vertices=8, radius=0.09, depth=0.55, location=(0, 0, stem_z))
stem = bpy.context.active_object
bm = bmesh.new(); bm.from_mesh(stem.data)
for v in bm.verts:
    t = (v.co.z + 0.275) / 0.55
    if t > 0.4:
        f = (t - 0.4) / 0.6
        v.co.x += 0.24 * f * f
        v.co.z -= 0.11 * f * f
bm.to_mesh(stem.data); bm.free()
stem.data.materials.append(mat_stem)
bpy.ops.object.shade_smooth()

def leaf(name, loc, rot, sx=0.48):
    bpy.ops.mesh.primitive_circle_add(vertices=10, radius=sx, fill_type="NGON", location=loc)
    o = bpy.context.active_object
    o.name = name
    bpy.ops.object.mode_set(mode="EDIT")
    bpy.ops.mesh.extrude_region_move(TRANSFORM_OT_translate={"value": (0, 0, 0.04)})
    bpy.ops.object.mode_set(mode="OBJECT")
    o.scale = (1.0, 0.42, 1.0)
    bpy.ops.object.transform_apply(scale=True)
    o.rotation_euler = rot
    bpy.ops.object.transform_apply(rotation=True)
    bm = bmesh.new(); bm.from_mesh(o.data)
    # wine-tint outer verts slightly by assigning... keep single mat, dark green body
    for v in bm.verts:
        if v.co.x > 0.05:
            v.co.y *= max(0.12, 1.0 - (v.co.x / sx) * 0.9)
    bm.to_mesh(o.data); bm.free()
    o.data.materials.append(mat_leaf)
    bpy.ops.object.shade_smooth()
    return o

lz = stem_z + 0.3
l1 = leaf("L1", (0.26, 0, lz), (math.radians(12), math.radians(55), 0), 0.5)
l2 = leaf("L2", (-0.14, 0.2, lz - 0.02), (math.radians(18), math.radians(-50), math.radians(30)), 0.42)
l3 = leaf("L3", (-0.1, -0.2, lz - 0.04), (math.radians(22), math.radians(15), math.radians(-95)), 0.38)

bpy.ops.object.select_all(action="DESELECT")
for o in (body, stem, l1, l2, l3):
    o.select_set(True)
bpy.context.view_layer.objects.active = body
bpy.ops.object.join()
fruit = bpy.context.active_object
fruit.name = "Blutaugespiegel"
bpy.ops.object.origin_set(type="ORIGIN_GEOMETRY", center="BOUNDS")
zs = [v.co.z for v in fruit.data.vertices]
fruit.location.z -= min(zs)
bpy.ops.object.transform_apply(location=True)
print(f"v2: {len(fruit.data.vertices)}v {len(fruit.data.polygons)}f size~{SIZE}")

bpy.ops.object.camera_add(location=(4.2, -4.0, 3.0))
cam = bpy.context.active_object
cam.rotation_euler = (Vector((0, 0, 1.15)) - cam.location).to_track_quat("-Z", "Y").to_euler()
bpy.context.scene.camera = cam
bpy.ops.object.light_add(type="SUN", location=(4, -2, 8))
bpy.context.active_object.data.energy = 2.8
bpy.ops.object.light_add(type="AREA", location=(-2.5, 2, 3.5))
a = bpy.context.active_object; a.data.energy = 50; a.data.size = 4
# red rim for legendary feel
bpy.ops.object.light_add(type="AREA", location=(3, 2.5, 1.5))
r = bpy.context.active_object; r.data.energy = 22; r.data.size = 2.5; r.data.color = (1.0, 0.15, 0.2)

w = bpy.data.worlds.new("W"); bpy.context.scene.world = w; w.use_nodes = True
w.node_tree.nodes["Background"].inputs[0].default_value = (0.35, 0.32, 0.34, 1)

sc = bpy.context.scene
sc.render.engine = "BLENDER_EEVEE"
sc.render.resolution_x = sc.render.resolution_y = 720
sc.render.filepath = PNG
bpy.ops.render.render(write_still=True)
bpy.ops.wm.save_as_mainfile(filepath=BLEND)
bpy.ops.object.select_all(action="DESELECT"); fruit.select_set(True)
bpy.context.view_layer.objects.active = fruit
bpy.ops.export_scene.fbx(
    filepath=FBX, use_selection=True, apply_scale_options="FBX_SCALE_ALL",
    axis_forward="-Z", axis_up="Y", mesh_smooth_type="FACE",
    path_mode="COPY", embed_textures=True,
)
print("DONE", FBX)
