"""Soul Fruits island props: Rock, Crate, BannerGut, BannerBoese — low-poly Roblox."""
import bpy, bmesh, math
from mathutils import Vector, noise
from pathlib import Path

OUT = Path("/workspace/soul-fruits-assets/props")
OUT.mkdir(parents=True, exist_ok=True)

def wipe():
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)
    for coll in (bpy.data.meshes, bpy.data.materials):
        for b in list(coll):
            coll.remove(b)

def mat(name, color, rough=0.8):
    m = bpy.data.materials.new(name=name)
    m.use_nodes = True
    bsdf = m.node_tree.nodes["Principled BSDF"]
    bsdf.inputs["Base Color"].default_value = (*color, 1)
    bsdf.inputs["Roughness"].default_value = rough
    return m

def ground_origin(obj):
    bpy.ops.object.origin_set(type="ORIGIN_GEOMETRY", center="BOUNDS")
    zs = [v.co.z for v in obj.data.vertices]
    obj.location.z -= min(zs)
    bpy.ops.object.transform_apply(location=True)

def export_preview(obj, stem, cam_loc=(3.2,-3.0,2.4), look=(0,0,0.8), world=(0.55,0.58,0.6)):
    bpy.ops.object.camera_add(location=cam_loc)
    cam = bpy.context.active_object
    cam.rotation_euler = (Vector(look) - cam.location).to_track_quat("-Z", "Y").to_euler()
    bpy.context.scene.camera = cam
    bpy.ops.object.light_add(type="SUN", location=(3,-2,6)); bpy.context.active_object.data.energy = 2.6
    bpy.ops.object.light_add(type="AREA", location=(-2,2,3)); a=bpy.context.active_object; a.data.energy=45; a.data.size=4
    w = bpy.data.worlds.new("W"+stem); bpy.context.scene.world=w; w.use_nodes=True
    w.node_tree.nodes["Background"].inputs[0].default_value=(*world,1)
    sc=bpy.context.scene; sc.render.engine="BLENDER_EEVEE"; sc.render.resolution_x=sc.render.resolution_y=512
    png=str(OUT/f"{stem}_preview.png"); sc.render.filepath=png
    bpy.ops.render.render(write_still=True)
    blend=str(OUT/f"{stem}.blend"); bpy.ops.wm.save_as_mainfile(filepath=blend)
    bpy.ops.object.select_all(action="DESELECT"); obj.select_set(True)
    bpy.context.view_layer.objects.active=obj
    fbx=str(OUT/f"{stem}.fbx")
    bpy.ops.export_scene.fbx(filepath=fbx, use_selection=True, apply_scale_options="FBX_SCALE_ALL",
        axis_forward="-Z", axis_up="Y", mesh_smooth_type="FACE")
    print(stem, len(obj.data.vertices), "verts ->", fbx)
    # delete lights/cam for next
    for o in list(bpy.data.objects):
        if o.type in {"LIGHT","CAMERA"}:
            bpy.data.objects.remove(o, do_unlink=True)

# ---- ROCK ----
wipe()
bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=1, radius=1.0, location=(0,0,0.7))
rock = bpy.context.active_object; rock.name="Rock"
bm=bmesh.new(); bm.from_mesh(rock.data)
for v in bm.verts:
    n = noise.noise(v.co*1.8)
    v.co *= 0.85 + 0.2*n
    v.co.z *= 0.75
    v.co.x *= 1.15
bm.to_mesh(rock.data); bm.free()
bpy.ops.object.mode_set(mode="EDIT"); bpy.ops.mesh.select_all(action="SELECT")
bpy.ops.mesh.subdivide(number_cuts=1); bpy.ops.object.mode_set(mode="OBJECT")
bm=bmesh.new(); bm.from_mesh(rock.data)
for v in bm.verts:
    v.co += v.co.normalized() * (0.06*noise.noise(v.co*3.2))
bm.to_mesh(rock.data); bm.free()
for p in rock.data.polygons: p.use_smooth=False
rock.data.materials.append(mat("RockMat",(0.45,0.42,0.38),0.95))
ground_origin(rock)
export_preview(rock,"Rock", cam_loc=(3.5,-3.2,2.2), look=(0,0,0.6))

# ---- CRATE ----
wipe()
bpy.ops.mesh.primitive_cube_add(size=1.2, location=(0,0,0.6))
crate=bpy.context.active_object; crate.name="Crate"
# rim boards via inset-ish: add thinner boxes as planks
mats_wood=mat("Wood",(0.42,0.28,0.14),0.75)
mats_dark=mat("WoodDark",(0.28,0.18,0.08),0.8)
crate.data.materials.append(mats_wood)
# edge bevel slight
mod=crate.modifiers.new("B","BEVEL"); mod.width=0.02; mod.segments=1
bpy.ops.object.modifier_apply(modifier="B")
# cross planks
planks=[]
for z in (0.15, 0.6, 1.05):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=(0,0.61,z))
    p=bpy.context.active_object; p.scale=(1.15,0.06,0.12); bpy.ops.object.transform_apply(scale=True)
    p.data.materials.append(mats_dark); planks.append(p)
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=(0,-0.61,z))
    p=bpy.context.active_object; p.scale=(1.15,0.06,0.12); bpy.ops.object.transform_apply(scale=True)
    p.data.materials.append(mats_dark); planks.append(p)
bpy.ops.object.select_all(action="DESELECT")
crate.select_set(True)
for p in planks: p.select_set(True)
bpy.context.view_layer.objects.active=crate
bpy.ops.object.join(); crate=bpy.context.active_object; crate.name="Crate"
ground_origin(crate)
export_preview(crate,"Crate", cam_loc=(3.2,-3.0,2.3), look=(0,0,0.7))

# ---- BANNER helper ----
def make_banner(stem, cloth_color, emblem_color, pole_color=(0.25,0.22,0.18)):
    wipe()
    # pole
    bpy.ops.mesh.primitive_cylinder_add(vertices=8, radius=0.06, depth=2.4, location=(0,0,1.2))
    pole=bpy.context.active_object; pole.name="Pole"
    pole.data.materials.append(mat(stem+"Pole", pole_color, 0.7))
    # cloth flag
    bpy.ops.mesh.primitive_plane_add(size=1.0, location=(0.55,0,1.7))
    cloth=bpy.context.active_object; cloth.name="Cloth"
    cloth.scale=(0.7,0.02,0.55); bpy.ops.object.transform_apply(scale=True)
    # rotate to hang vertical-ish from pole
    cloth.rotation_euler=(0, math.radians(90), 0); bpy.ops.object.transform_apply(rotation=True)
    cloth.location=(0.7,0,1.65)
    # wave displace
    bm=bmesh.new(); bm.from_mesh(cloth.data)
    bmesh.ops.subdivide_edges(bm, edges=bm.edges[:], cuts=3)
    for v in bm.verts:
        v.co.y += 0.04*math.sin(v.co.z*6 + v.co.x*3)
    bm.to_mesh(cloth.data); bm.free()
    cloth.data.materials.append(mat(stem+"Cloth", cloth_color, 0.65))
    # emblem disc
    bpy.ops.mesh.primitive_cylinder_add(vertices=12, radius=0.22, depth=0.04, location=(0.72,0.03,1.65),
                                        rotation=(math.radians(90),0,0))
    emb=bpy.context.active_object; emb.name="Emblem"
    emb.data.materials.append(mat(stem+"Emb", emblem_color, 0.4))
    # finial
    bpy.ops.mesh.primitive_uv_sphere_add(segments=8, ring_count=4, radius=0.1, location=(0,0,2.45))
    tip=bpy.context.active_object; tip.data.materials.append(mat(stem+"Tip",(0.75,0.65,0.25),0.35))
    bpy.ops.object.select_all(action="DESELECT")
    for o in (pole,cloth,emb,tip): o.select_set(True)
    bpy.context.view_layer.objects.active=pole
    bpy.ops.object.join(); ban=bpy.context.active_object; ban.name=stem
    ground_origin(ban)
    export_preview(ban, stem, cam_loc=(3.5,-3.5,2.6), look=(0.3,0,1.2),
                   world=(0.5,0.55,0.58) if "Gut" in stem else (0.35,0.28,0.3))

make_banner("BannerGut", cloth_color=(0.2,0.45,0.85), emblem_color=(0.95,0.9,0.3))
make_banner("BannerBoese", cloth_color=(0.55,0.08,0.1), emblem_color=(0.15,0.12,0.12))

print("ALL_PROPS_DONE")
