"""Soul Fruits — Dreck Fruit (Common): low-poly earth/stone fruit for Roblox."""
import bpy
import bmesh
import math
from mathutils import Vector, noise

OUT_DIR = "/workspace/soul-fruits-assets"
BLEND = f"{OUT_DIR}/DreckFruit.blend"
FBX = f"{OUT_DIR}/DreckFruit.fbx"
PNG = f"{OUT_DIR}/DreckFruit_preview.png"

# --- clean scene ---
bpy.ops.object.select_all(action="SELECT")
bpy.ops.object.delete(use_global=False)
for block in bpy.data.meshes:
    bpy.data.meshes.remove(block)
for block in bpy.data.materials:
    bpy.data.materials.remove(block)

# --- base icosphere, then displace for rocky dirt fruit ---
bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=2, radius=1.0, location=(0, 0, 0))
obj = bpy.context.active_object
obj.name = "DreckFruit"

bm = bmesh.new()
bm.from_mesh(obj.data)
bmesh.ops.triangulate(bm, faces=bm.faces[:])

# Organic dirt bumps + slightly flattened "fruit" silhouette
for v in bm.verts:
    p = v.co.copy()
    # noise-based rocky displacement
    n = noise.noise(p * 2.4)
    n2 = noise.noise(p * 5.1 + Vector((3.1, 1.7, 0.2)))
    factor = 0.12 + 0.08 * n + 0.05 * n2
    # stretch vertically a bit like a fruit, squash X/Y unevenly
    p.x *= 0.92 + 0.06 * n
    p.y *= 0.88 + 0.08 * n2
    p.z *= 1.05
    v.co = p + p.normalized() * factor

# Stem nub (small cone-ish top)
bm.verts.ensure_lookup_table()
# Find top-ish verts and pull a small stem
top = max(bm.verts, key=lambda v: v.co.z)
stem_dir = Vector((0, 0, 1))
# Add a simple stem as separate mesh later

bm.to_mesh(obj.data)
bm.free()
obj.data.update()

# Shade flat for clear Roblox silhouette / low-poly look
for poly in obj.data.polygons:
    poly.use_smooth = False

# --- stem ---
bpy.ops.mesh.primitive_cylinder_add(
    vertices=6, radius=0.08, depth=0.28, location=(0, 0, 1.15)
)
stem = bpy.context.active_object
stem.name = "DreckFruit_Stem"
# taper: scale top via edit mode
bpy.ops.object.mode_set(mode="EDIT")
bpy.ops.mesh.select_all(action="DESELECT")
bpy.ops.object.mode_set(mode="OBJECT")
# simple scale for stubby stem
stem.scale = (1.0, 1.0, 1.0)
stem.location.z = 1.08

# --- leaf (simple flat diamond) ---
bpy.ops.mesh.primitive_cone_add(
    vertices=4, radius1=0.22, radius2=0.0, depth=0.35, location=(0.12, 0, 1.28)
)
leaf = bpy.context.active_object
leaf.name = "DreckFruit_Leaf"
leaf.rotation_euler = (math.radians(70), math.radians(15), math.radians(25))
leaf.scale = (0.55, 0.2, 1.0)

# --- materials (simple Principled, earth tones) ---
def mat(name, color, roughness=0.85):
    m = bpy.data.materials.new(name=name)
    m.use_nodes = True
    nodes = m.node_tree.nodes
    bsdf = nodes.get("Principled BSDF")
    if bsdf:
        bsdf.inputs["Base Color"].default_value = (*color, 1.0)
        if "Roughness" in bsdf.inputs:
            bsdf.inputs["Roughness"].default_value = roughness
    return m

mat_dirt = mat("Dreck_Dirt", (0.35, 0.24, 0.14), 0.92)
mat_stone = mat("Dreck_Stone", (0.42, 0.38, 0.32), 0.78)
mat_stem = mat("Dreck_Stem", (0.18, 0.28, 0.12), 0.7)
mat_leaf = mat("Dreck_Leaf", (0.22, 0.45, 0.15), 0.65)

obj.data.materials.append(mat_dirt)
# assign stone-ish to some faces by Z noise for variation
me = obj.data
me.materials.append(mat_stone)
for i, poly in enumerate(me.polygons):
    c = me.vertices[poly.vertices[0]].co
    if (c.x + c.y * 1.3 + c.z * 0.7) % 1.0 > 0.55:
        poly.material_index = 1
    else:
        poly.material_index = 0

stem.data.materials.append(mat_stem)
leaf.data.materials.append(mat_leaf)

# --- join into one mesh for Roblox ---
bpy.ops.object.select_all(action="DESELECT")
obj.select_set(True)
stem.select_set(True)
leaf.select_set(True)
bpy.context.view_layer.objects.active = obj
bpy.ops.object.join()
obj = bpy.context.active_object
obj.name = "DreckFruit"

# Apply scale/rotation
bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)

# Origin to geometry center, then sit on ground (bottom at z=0)
bpy.ops.object.origin_set(type="ORIGIN_GEOMETRY", center="BOUNDS")
# Move so lowest vertex is at z=0
zs = [v.co.z for v in obj.data.vertices]
obj.location.z -= min(zs)
bpy.ops.object.transform_apply(location=True, rotation=False, scale=False)
bpy.ops.object.origin_set(type="ORIGIN_GEOMETRY", center="BOUNDS")

poly_count = len(obj.data.polygons)
vert_count = len(obj.data.vertices)
print(f"DreckFruit: {vert_count} verts, {poly_count} tris/faces")

# --- camera + light for preview ---
bpy.ops.object.camera_add(location=(3.2, -3.0, 2.2))
cam = bpy.context.active_object
cam.name = "PreviewCam"
# point at fruit
direction = Vector((0, 0, 0.7)) - cam.location
cam.rotation_euler = direction.to_track_quat("-Z", "Y").to_euler()
bpy.context.scene.camera = cam

bpy.ops.object.light_add(type="SUN", location=(2, -2, 5))
sun = bpy.context.active_object
sun.data.energy = 3.0

bpy.ops.object.light_add(type="AREA", location=(-2, 2, 3))
fill = bpy.context.active_object
fill.data.energy = 40.0
fill.data.size = 3.0

# world soft gray
world = bpy.data.worlds.new("PreviewWorld")
bpy.context.scene.world = world
world.use_nodes = True
bg = world.node_tree.nodes["Background"]
bg.inputs[0].default_value = (0.55, 0.58, 0.62, 1.0)
bg.inputs[1].default_value = 1.0

# render settings
scene = bpy.context.scene
scene.render.engine = "BLENDER_EEVEE"
scene.render.resolution_x = 512
scene.render.resolution_y = 512
scene.render.filepath = PNG
scene.render.film_transparent = False

bpy.ops.render.render(write_still=True)
print(f"Preview: {PNG}")

# save blend
bpy.ops.wm.save_as_mainfile(filepath=BLEND)
print(f"Blend: {BLEND}")

# export FBX (Roblox-friendly)
bpy.ops.object.select_all(action="DESELECT")
obj.select_set(True)
bpy.context.view_layer.objects.active = obj
bpy.ops.export_scene.fbx(
    filepath=FBX,
    use_selection=True,
    apply_scale_options="FBX_SCALE_ALL",
    axis_forward="-Z",
    axis_up="Y",
    mesh_smooth_type="FACE",
    use_mesh_modifiers=True,
    embed_textures=False,
    path_mode="AUTO",
)
print(f"FBX: {FBX}")
print("DONE")
