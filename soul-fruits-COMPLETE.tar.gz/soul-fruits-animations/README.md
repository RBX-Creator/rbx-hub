# Soul Fruits – Animations (Animator Overnight)

R15-Animationen für Studio + Client-Controller, der an die Scripter-Hooks andockt.

## Inhalt

| Pfad | Was |
|------|-----|
| `fbx/SF_Idle.fbx` | Idle-Loop (~2s) |
| `fbx/SF_Walk.fbx` | Walk-Cycle |
| `fbx/SF_Run.fbx` | Run-Cycle |
| `fbx/SF_Dash.fbx` | Vorwärts-Dash (~0.33s, für Q / 1.2s CD) |
| `fbx/SF_FlyStart.fbx` / `SF_FlyLoop.fbx` / `SF_FlyLand.fbx` | Flug F halten |
| `fbx/SF_M1_1..4.fbx` | Faust-Combo 1–4 |
| `fbx/SF_HitReact.fbx` | Treffer-Reaktion (optional) |
| `fbx/SF_FruitZ.fbx` … `SF_FruitV.fbx` | Dreck Cast-Posen (kurz) |
| `fbx/SF_BloodZ.fbx` … `SF_BloodV.fbx` | Eye-line Casts (Blutaugespiegel + Sharingan) |
| `fbx/SF_SusanooStart.fbx` / `SF_SusanooLoop.fbx` | Sharingan **R** Partial Susanoo |
| `blend/SoulFruits_R15_Anims.blend` | Blender-Quelle |
| `src/Shared/AnimConfig.lua` | AnimationIds (nach Upload eintragen) |
| `src/Client/AnimationController.lua` | dockt an `SF_M1_Combo`, `VFX_Dash`, `VFX_Fly` / `IsFlying` |

In `soul-fruits-foundation` sind Controller + Config bereits gespiegelt und in `ClientBootstrap` gestartet.

## Import in Roblox Studio (FBX → AnimationId)

1. Place auf **R15**.
2. Avatar → **Animation Editor** → Import aus `fbx/SF_*.fbx` (oder Rig mit R15 Dummy + FBX).
3. Jede Anim **Publish to Roblox** → Asset-ID notieren.
4. IDs in `AnimConfig.Ids` eintragen (z.B. `Idle = 123456789`).
5. Play Solo: Idle/Walk/Run automatisch; **Q** → Dash-Anim; **F** → Fly; **LMB** → M1_1..4 über `SF_M1_Combo`.

> Bis IDs `> 0` sind, läuft der Controller still (Default-Roblox-Anims bleiben) — kein Error-Spam.

## Hooks (Absprache Scripter/VFX)

| Signal | Anim |
|--------|------|
| Humanoid.Running | Idle / Walk / Run |
| `SF_M1_Combo` = 1..4 | `SF_M1_n` |
| `VFX_Dash` pulse | `SF_Dash` |
| `VFX_Fly` / `IsFlying` true→false | FlyStart→Loop→Land |
| `VFX_Hit` | für VFX; HitReact optional später via `SF_TookHit` |
| `VFX_FruitZ` / `X` / `C` / `V` | Cast-Posen; Blutaugespiegel/Sharingan → Blood* |
| `VFX_Susanoo` + `SF_SusanooUntil` | SusanooStart → Loop bis Armor ende |

## Stil / Notizen für Review

- Kurze Loops, kein 3s-Intro am Dash.
- Dash: Vorwärts-Blitz, seitlich lesbar.
- Flug: Goku-lean, Arme leicht aus, Loop ruhig (Speed bleibt Script ~48).
- M1: L-R-L-R, Hit 4 etwas heftiger.
- Placeholder-Qualität: lesbar & andockbar; Polish-Pass nach Leeams Feedback.

## Package

```
/workspace/soul-fruits-animations/
/workspace/soul-fruits-animations.tar.gz
```


## Physical Fruits (v1.10 BF-flow)

| FBX | Hook |
|-----|------|
| `SF_FruitEat.fbx` | `SF_FruitEat` (E essen) |
| `SF_FruitSpin.fbx` | `VFX_FruitSpin` (Gacha/Stock geben) |

Kurz: Hold Fruit → Mund → Biss. IDs in `AnimConfig.Ids.FruitEat` / `FruitSpin`.

## Attack Polish Pass
M1_1–4 snappier (kürzerer Windup, klarer Hit-Frame, M1_4 heavier). Fruit Z–V + Blood Z–V lesbarer. Susanoo Start/Loop stärker. HitReact härter. Re-Publish IDs nach Import.
