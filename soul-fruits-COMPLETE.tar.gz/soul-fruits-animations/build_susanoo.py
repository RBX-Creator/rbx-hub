#!/usr/bin/env python3
"""Partial Susanoo cast + hold for Sharingan R."""
import os
import bpy
from mathutils import Euler, Vector

OUT = "/workspace/soul-fruits-animations"
FBX_DIR = os.path.join(OUT, "fbx")
BLEND = os.path.join(OUT, "blend", "SoulFruits_R15_Anims.blend")
bpy.ops.wm.open_mainfile(filepath=BLEND)
arm_obj = bpy.data.objects.get("R15")
assert arm_obj
bpy.ops.object.select_all(action="DESELECT")
arm_obj.select_set(True)
bpy.context.view_layer.objects.active = arm_obj
bpy.ops.object.mode_set(mode="POSE")
pose = arm_obj.pose
bpy.context.scene.render.fps = 30

def clear_anim():
    if arm_obj.animation_data:
        arm_obj.animation_data_clear()
    for pb in pose.bones:
        pb.rotation_mode = "XYZ"
        pb.rotation_euler = (0, 0, 0)
        pb.location = (0, 0, 0)

def kf(bone, frame, rot=None, loc=None):
    pb = pose.bones[bone]
    pb.rotation_mode = "XYZ"
    bpy.context.scene.frame_set(frame)
    if rot is not None:
        pb.rotation_euler = Euler(rot, "XYZ")
        pb.keyframe_insert(data_path="rotation_euler", frame=frame)
    if loc is not None:
        pb.location = Vector(loc)
        pb.keyframe_insert(data_path="location", frame=frame)

def export_action(name, frames, builder):
    clear_anim()
    builder()
    if not arm_obj.animation_data:
        arm_obj.animation_data_create()
    action = arm_obj.animation_data.action
    if action is None:
        kf("UpperTorso", 1, rot=(0, 0, 0))
        action = arm_obj.animation_data.action
    action.name = name
    bpy.context.scene.frame_start = 1
    bpy.context.scene.frame_end = frames
    track = arm_obj.animation_data.nla_tracks.new()
    track.name = name
    track.strips.new(name, 1, action)
    path = os.path.join(FBX_DIR, f"{name}.fbx")
    bpy.ops.export_scene.fbx(
        filepath=path, use_selection=True, object_types={"ARMATURE"},
        add_leaf_bones=False, bake_anim=True, bake_anim_use_all_bones=True,
        bake_anim_use_nla_strips=False, bake_anim_use_all_actions=False,
        bake_anim_force_startend_keying=True, bake_anim_step=1.0,
        bake_anim_simplify_factor=0.0, armature_nodetype="NULL",
        use_armature_deform_only=False, primary_bone_axis="Y",
        secondary_bone_axis="X", axis_forward="-Z", axis_up="Y",
    )
    print("Exported", path)
    while arm_obj.animation_data.nla_tracks:
        arm_obj.animation_data.nla_tracks.remove(arm_obj.animation_data.nla_tracks[0])
    arm_obj.animation_data_clear()

def build_start():
    # summon: crouch then arms wide + slam
    for f, a in [(1, 0.0), (4, 0.5), (8, 1.0), (12, 0.9), (16, 0.85)]:
        kf("LowerTorso", f, rot=(0.2 * a if f < 8 else 0.05 * a, 0, 0), loc=(0, 0, -0.05 * a if f < 8 else -0.02 * a))
        kf("UpperTorso", f, rot=(-0.25 * a, 0, 0))
        kf("Head", f, rot=(-0.15 * a, 0, 0))
        kf("LeftUpperArm", f, rot=(-1.5 * a, 0.3 * a, 1.1 * a))
        kf("RightUpperArm", f, rot=(-1.5 * a, -0.3 * a, -1.1 * a))
        kf("LeftLowerArm", f, rot=(0.4 * a, 0, 0))
        kf("RightLowerArm", f, rot=(0.4 * a, 0, 0))
        kf("LeftUpperLeg", f, rot=(0.25 * a, 0.2 * a, 0))
        kf("RightUpperLeg", f, rot=(0.25 * a, -0.2 * a, 0))

def build_loop():
    # armored idle sway ~40 frames
    for f, t in [(1, 0.0), (11, 0.5), (21, 1.0), (31, 0.5), (41, 0.0)]:
        w = __import__("math").sin(t * 6.283) * 0.04
        a = 0.9
        kf("LowerTorso", f, rot=(0.05, 0, w), loc=(0, 0, -0.02))
        kf("UpperTorso", f, rot=(-0.2 + w * 0.5, 0, 0))
        kf("Head", f, rot=(-0.1, 0, 0))
        kf("LeftUpperArm", f, rot=(-1.35 + w, 0.25, 1.0))
        kf("RightUpperArm", f, rot=(-1.35 - w, -0.25, -1.0))
        kf("LeftLowerArm", f, rot=(0.35, 0, 0))
        kf("RightLowerArm", f, rot=(0.35, 0, 0))
        kf("LeftUpperLeg", f, rot=(0.2, 0.18, 0))
        kf("RightUpperLeg", f, rot=(0.2, -0.18, 0))

bpy.ops.object.mode_set(mode="OBJECT")
arm_obj.select_set(True)
export_action("SF_SusanooStart", 16, build_start)
export_action("SF_SusanooLoop", 40, build_loop)
bpy.ops.wm.save_as_mainfile(filepath=BLEND)
print("DONE susanoo")
