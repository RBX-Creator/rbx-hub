#!/usr/bin/env python3
"""Build Soul Fruits R15 placeholder animations and export FBX for Roblox Studio."""
import math
import os
import bpy
from mathutils import Euler, Vector

OUT = "/workspace/soul-fruits-animations"
FBX_DIR = os.path.join(OUT, "fbx")
BLEND_DIR = os.path.join(OUT, "blend")
os.makedirs(FBX_DIR, exist_ok=True)
os.makedirs(BLEND_DIR, exist_ok=True)

# Clear scene
bpy.ops.wm.read_factory_settings(use_empty=True)

# --- R15 bone layout (Roblox-compatible names) ---
# (name, parent, head, tail) in meters-ish; Roblox uses studs but relative pose matters
BONES = [
    ("HumanoidRootPart", None, (0, 0, 1.0), (0, 0, 1.05)),
    ("LowerTorso", "HumanoidRootPart", (0, 0, 1.05), (0, 0, 1.25)),
    ("UpperTorso", "LowerTorso", (0, 0, 1.25), (0, 0, 1.55)),
    ("Head", "UpperTorso", (0, 0, 1.55), (0, 0, 1.85)),
    ("LeftUpperArm", "UpperTorso", (-0.15, 0, 1.50), (-0.40, 0, 1.30)),
    ("LeftLowerArm", "LeftUpperArm", (-0.40, 0, 1.30), (-0.55, 0, 1.05)),
    ("LeftHand", "LeftLowerArm", (-0.55, 0, 1.05), (-0.60, 0, 0.95)),
    ("RightUpperArm", "UpperTorso", (0.15, 0, 1.50), (0.40, 0, 1.30)),
    ("RightLowerArm", "RightUpperArm", (0.40, 0, 1.30), (0.55, 0, 1.05)),
    ("RightHand", "RightLowerArm", (0.55, 0, 1.05), (0.60, 0, 0.95)),
    ("LeftUpperLeg", "LowerTorso", (-0.10, 0, 1.05), (-0.12, 0, 0.65)),
    ("LeftLowerLeg", "LeftUpperLeg", (-0.12, 0, 0.65), (-0.12, 0, 0.25)),
    ("LeftFoot", "LeftLowerLeg", (-0.12, 0, 0.25), (-0.12, 0.12, 0.10)),
    ("RightUpperLeg", "LowerTorso", (0.10, 0, 1.05), (0.12, 0, 0.65)),
    ("RightLowerLeg", "RightUpperLeg", (0.12, 0, 0.65), (0.12, 0, 0.25)),
    ("RightFoot", "RightLowerLeg", (0.12, 0, 0.25), (0.12, 0.12, 0.10)),
]

arm_data = bpy.data.armatures.new("R15")
arm_obj = bpy.data.objects.new("R15", arm_data)
bpy.context.collection.objects.link(arm_obj)
bpy.context.view_layer.objects.active = arm_obj
arm_obj.select_set(True)

bpy.ops.object.mode_set(mode="EDIT")
edit_bones = arm_data.edit_bones
created = {}
for name, parent, head, tail in BONES:
    b = edit_bones.new(name)
    b.head = Vector(head)
    b.tail = Vector(tail)
    if parent:
        b.parent = created[parent]
    created[name] = b

bpy.ops.object.mode_set(mode="POSE")
pose = arm_obj.pose

FPS = 30
bpy.context.scene.render.fps = FPS


def clear_anim():
    if arm_obj.animation_data:
        arm_obj.animation_data_clear()
    for pb in pose.bones:
        pb.rotation_mode = "XYZ"
        pb.rotation_euler = (0, 0, 0)
        pb.location = (0, 0, 0)


def kf(bone, frame, rot=None, loc=None):
    pb = pose.bones[bone]
    pb.rotation_mode = "XYZ"
    bpy.context.scene.frame_set(frame)
    if rot is not None:
        pb.rotation_euler = Euler(rot, "XYZ")
        pb.keyframe_insert(data_path="rotation_euler", frame=frame)
    if loc is not None:
        pb.location = Vector(loc)
        pb.keyframe_insert(data_path="location", frame=frame)


def make_action(name, frames, builder):
    clear_anim()
    builder()
    action = arm_obj.animation_data.action if arm_obj.animation_data else None
    if action is None:
        # ensure animation_data
        arm_obj.animation_data_create()
        # force one key if empty
        kf("UpperTorso", 1, rot=(0, 0, 0))
        action = arm_obj.animation_data.action
    action.name = name
    bpy.context.scene.frame_start = 1
    bpy.context.scene.frame_end = frames
    # push to NLA for export reliability
    track = arm_obj.animation_data.nla_tracks.new()
    track.name = name
    track.strips.new(name, 1, action)
    path = os.path.join(FBX_DIR, f"{name}.fbx")
    bpy.ops.export_scene.fbx(
        filepath=path,
        use_selection=True,
        object_types={"ARMATURE"},
        add_leaf_bones=False,
        bake_anim=True,
        bake_anim_use_all_bones=True,
        bake_anim_use_nla_strips=False,
        bake_anim_use_all_actions=False,
        bake_anim_force_startend_keying=True,
        bake_anim_step=1.0,
        bake_anim_simplify_factor=0.0,
        armature_nodetype="NULL",
        use_armature_deform_only=False,
        primary_bone_axis="Y",
        secondary_bone_axis="X",
        axis_forward="-Z",
        axis_up="Y",
    )
    print("Exported", path)
    # clear NLA for next
    while arm_obj.animation_data.nla_tracks:
        arm_obj.animation_data.nla_tracks.remove(arm_obj.animation_data.nla_tracks[0])
    arm_obj.animation_data_clear()
    return path


def build_idle():
    # subtle breathe + slight arm sway, 60 frames loop
    for f, t in [(1, 0.0), (16, 0.5), (31, 1.0), (46, 0.5), (61, 0.0)]:
        breath = math.sin(t * math.pi * 2) * 0.03
        arm = math.sin(t * math.pi * 2) * 0.04
        kf("UpperTorso", f, rot=(breath, 0, 0))
        kf("Head", f, rot=(-breath * 0.5, 0, 0))
        kf("LeftUpperArm", f, rot=(0.15 + arm, 0, 0.25))
        kf("RightUpperArm", f, rot=(0.15 - arm, 0, -0.25))
        kf("LeftLowerArm", f, rot=(0.2, 0, 0))
        kf("RightLowerArm", f, rot=(0.2, 0, 0))
        kf("LowerTorso", f, rot=(0, 0, 0))


def build_walk():
    # 24 frame walk cycle
    for f in range(1, 25):
        t = (f - 1) / 24.0
        phase = t * math.pi * 2
        leg = math.sin(phase) * 0.55
        leg2 = math.sin(phase + math.pi) * 0.55
        arm = math.sin(phase + math.pi) * 0.45
        arm2 = math.sin(phase) * 0.45
        knee = max(0.0, -math.sin(phase)) * 0.7
        knee2 = max(0.0, -math.sin(phase + math.pi)) * 0.7
        kf("LowerTorso", f, rot=(0.05, 0, math.sin(phase) * 0.04), loc=(0, 0, abs(math.sin(phase)) * 0.02))
        kf("UpperTorso", f, rot=(0.02, 0, -math.sin(phase) * 0.03))
        kf("LeftUpperLeg", f, rot=(leg, 0, 0))
        kf("RightUpperLeg", f, rot=(leg2, 0, 0))
        kf("LeftLowerLeg", f, rot=(knee, 0, 0))
        kf("RightLowerLeg", f, rot=(knee2, 0, 0))
        kf("LeftFoot", f, rot=(-leg * 0.3, 0, 0))
        kf("RightFoot", f, rot=(-leg2 * 0.3, 0, 0))
        kf("LeftUpperArm", f, rot=(arm, 0, 0.2))
        kf("RightUpperArm", f, rot=(arm2, 0, -0.2))
        kf("LeftLowerArm", f, rot=(0.35 + abs(arm) * 0.2, 0, 0))
        kf("RightLowerArm", f, rot=(0.35 + abs(arm2) * 0.2, 0, 0))
        kf("Head", f, rot=(0, 0, math.sin(phase) * 0.02))


def build_run():
    # 16 frame run — faster, more lean
    for f in range(1, 17):
        t = (f - 1) / 16.0
        phase = t * math.pi * 2
        leg = math.sin(phase) * 0.85
        leg2 = math.sin(phase + math.pi) * 0.85
        arm = math.sin(phase + math.pi) * 0.75
        arm2 = math.sin(phase) * 0.75
        knee = max(0.0, -math.sin(phase)) * 1.0
        knee2 = max(0.0, -math.sin(phase + math.pi)) * 1.0
        bounce = abs(math.sin(phase)) * 0.04
        kf("LowerTorso", f, rot=(0.18, 0, math.sin(phase) * 0.06), loc=(0, 0, bounce))
        kf("UpperTorso", f, rot=(0.12, 0, -math.sin(phase) * 0.05))
        kf("Head", f, rot=(-0.05, 0, 0))
        kf("LeftUpperLeg", f, rot=(leg, 0, 0))
        kf("RightUpperLeg", f, rot=(leg2, 0, 0))
        kf("LeftLowerLeg", f, rot=(knee, 0, 0))
        kf("RightLowerLeg", f, rot=(knee2, 0, 0))
        kf("LeftFoot", f, rot=(-leg * 0.35, 0, 0))
        kf("RightFoot", f, rot=(-leg2 * 0.35, 0, 0))
        kf("LeftUpperArm", f, rot=(arm, 0, 0.15))
        kf("RightUpperArm", f, rot=(arm2, 0, -0.15))
        kf("LeftLowerArm", f, rot=(0.5 + abs(arm) * 0.25, 0, 0))
        kf("RightLowerArm", f, rot=(0.5 + abs(arm2) * 0.25, 0, 0))


def build_dash():
    # ~10 frames (~0.33s) forward blitz, readable side
    poses = [
        (1, {"LowerTorso": (0.1, 0, 0), "UpperTorso": (0.2, 0, 0), "RightUpperArm": (-0.8, 0, -0.3), "LeftUpperArm": (0.6, 0, 0.4),
             "LeftUpperLeg": (0.4, 0, 0), "RightUpperLeg": (-0.5, 0, 0)}),
        (4, {"LowerTorso": (0.35, 0, 0), "UpperTorso": (0.45, 0, 0), "Head": (-0.1, 0, 0),
             "RightUpperArm": (-1.2, 0, -0.5), "LeftUpperArm": (0.9, 0, 0.5),
             "LeftUpperLeg": (0.7, 0, 0), "RightUpperLeg": (-0.9, 0, 0),
             "LeftLowerLeg": (0.4, 0, 0), "RightLowerLeg": (0.2, 0, 0)}),
        (7, {"LowerTorso": (0.25, 0, 0), "UpperTorso": (0.3, 0, 0),
             "RightUpperArm": (-0.6, 0, -0.2), "LeftUpperArm": (0.5, 0, 0.3),
             "LeftUpperLeg": (0.3, 0, 0), "RightUpperLeg": (-0.4, 0, 0)}),
        (10, {"LowerTorso": (0.05, 0, 0), "UpperTorso": (0.08, 0, 0),
              "RightUpperArm": (0.1, 0, -0.2), "LeftUpperArm": (0.1, 0, 0.2),
              "LeftUpperLeg": (0.05, 0, 0), "RightUpperLeg": (-0.05, 0, 0)}),
    ]
    for f, bones in poses:
        for b, r in bones.items():
            kf(b, f, rot=r)


def build_fly_start():
    for f, lean in [(1, 0.0), (4, 0.25), (8, 0.45)]:
        kf("LowerTorso", f, rot=(lean * 0.3, 0, 0), loc=(0, 0, lean * 0.05))
        kf("UpperTorso", f, rot=(lean, 0, 0))
        kf("Head", f, rot=(-lean * 0.3, 0, 0))
        kf("LeftUpperArm", f, rot=(-0.3 - lean, 0, 0.8 + lean * 0.3))
        kf("RightUpperArm", f, rot=(-0.3 - lean, 0, -0.8 - lean * 0.3))
        kf("LeftLowerArm", f, rot=(0.2, 0, 0))
        kf("RightLowerArm", f, rot=(0.2, 0, 0))
        kf("LeftUpperLeg", f, rot=(-0.2 - lean * 0.2, 0.1, 0))
        kf("RightUpperLeg", f, rot=(-0.15 - lean * 0.2, -0.1, 0))
        kf("LeftLowerLeg", f, rot=(0.3, 0, 0))
        kf("RightLowerLeg", f, rot=(0.25, 0, 0))


def build_fly_loop():
    for f, t in [(1, 0.0), (11, 0.5), (21, 1.0), (31, 0.5), (41, 0.0)]:
        w = math.sin(t * math.pi * 2) * 0.06
        kf("LowerTorso", f, rot=(0.15, 0, w * 0.5), loc=(0, 0, 0.04 + abs(w) * 0.02))
        kf("UpperTorso", f, rot=(0.4 + w, 0, 0))
        kf("Head", f, rot=(-0.15, 0, 0))
        kf("LeftUpperArm", f, rot=(-0.7 + w, 0, 1.0))
        kf("RightUpperArm", f, rot=(-0.7 - w, 0, -1.0))
        kf("LeftLowerArm", f, rot=(0.15, 0, 0))
        kf("RightLowerArm", f, rot=(0.15, 0, 0))
        kf("LeftUpperLeg", f, rot=(-0.35, 0.12, 0))
        kf("RightUpperLeg", f, rot=(-0.3, -0.12, 0))
        kf("LeftLowerLeg", f, rot=(0.4, 0, 0))
        kf("RightLowerLeg", f, rot=(0.35, 0, 0))


def build_fly_land():
    for f, lean in [(1, 0.45), (5, 0.2), (10, 0.0)]:
        kf("LowerTorso", f, rot=(lean * 0.3, 0, 0), loc=(0, 0, lean * 0.04))
        kf("UpperTorso", f, rot=(lean, 0, 0))
        kf("Head", f, rot=(-lean * 0.2, 0, 0))
        kf("LeftUpperArm", f, rot=(-0.3 - lean * 0.5, 0, 0.5 + lean * 0.4))
        kf("RightUpperArm", f, rot=(-0.3 - lean * 0.5, 0, -0.5 - lean * 0.4))
        kf("LeftUpperLeg", f, rot=(-0.1 - lean * 0.2, 0, 0))
        kf("RightUpperLeg", f, rot=(-0.1 - lean * 0.2, 0, 0))


def punch(f_hit, left=True):
    side = "Left" if left else "Right"
    other = "Right" if left else "Left"
    wind = max(1, f_hit - 3)
    rec = f_hit + 3
    # windup
    kf(f"{side}UpperArm", wind, rot=(0.8, 0, 0.6 if left else -0.6))
    kf(f"{side}LowerArm", wind, rot=(1.2, 0, 0))
    kf(f"{other}UpperArm", wind, rot=(-0.2, 0, -0.3 if left else 0.3))
    kf("UpperTorso", wind, rot=(0.05, 0, 0.15 if left else -0.15))
    kf("LowerTorso", wind, rot=(0, 0, 0.08 if left else -0.08))
    # hit
    kf(f"{side}UpperArm", f_hit, rot=(-1.1, 0.2 if left else -0.2, 0.1 if left else -0.1))
    kf(f"{side}LowerArm", f_hit, rot=(0.15, 0, 0))
    kf(f"{other}UpperArm", f_hit, rot=(0.4, 0, -0.4 if left else 0.4))
    kf("UpperTorso", f_hit, rot=(0.15, 0, -0.25 if left else 0.25))
    kf("LowerTorso", f_hit, rot=(0.05, 0, -0.12 if left else 0.12))
    kf("Head", f_hit, rot=(0, 0, -0.1 if left else 0.1))
    # recover
    kf(f"{side}UpperArm", rec, rot=(0.2, 0, 0.25 if left else -0.25))
    kf(f"{side}LowerArm", rec, rot=(0.3, 0, 0))
    kf("UpperTorso", rec, rot=(0, 0, 0))
    kf("LowerTorso", rec, rot=(0, 0, 0))
    kf("Head", rec, rot=(0, 0, 0))


def build_m1(n):
    # each swing ~12 frames; alternate L/R/L/R, 4 is slightly heavier
    left = n in (1, 3)
    punch(5, left=left)
    if n == 4:
        # finishing knock
        kf("UpperTorso", 8, rot=(0.25, 0, -0.35 if left else 0.35))
        kf("RightUpperArm" if not left else "LeftUpperArm", 8, rot=(-1.3, 0, 0))
        kf("UpperTorso", 12, rot=(0, 0, 0))


def build_hit_react():
    for f, a in [(1, 0.0), (3, 1.0), (8, 0.4), (14, 0.0)]:
        kf("UpperTorso", f, rot=(-0.25 * a, 0, 0.1 * a), loc=(0, -0.03 * a, 0))
        kf("Head", f, rot=(-0.2 * a, 0, 0))
        kf("LeftUpperArm", f, rot=(0.3 * a, 0, 0.5 * a))
        kf("RightUpperArm", f, rot=(0.3 * a, 0, -0.5 * a))
        kf("LowerTorso", f, rot=(-0.1 * a, 0, 0))


exports = [
    ("SF_Idle", 60, build_idle),
    ("SF_Walk", 24, build_walk),
    ("SF_Run", 16, build_run),
    ("SF_Dash", 10, build_dash),
    ("SF_FlyStart", 8, build_fly_start),
    ("SF_FlyLoop", 40, build_fly_loop),
    ("SF_FlyLand", 10, build_fly_land),
    ("SF_M1_1", 12, lambda: build_m1(1)),
    ("SF_M1_2", 12, lambda: build_m1(2)),
    ("SF_M1_3", 12, lambda: build_m1(3)),
    ("SF_M1_4", 12, lambda: build_m1(4)),
    ("SF_HitReact", 14, build_hit_react),
]

# Select armature
bpy.ops.object.mode_set(mode="OBJECT")
bpy.ops.object.select_all(action="DESELECT")
arm_obj.select_set(True)
bpy.context.view_layer.objects.active = arm_obj

for name, frames, builder in exports:
    make_action(name, frames, builder)

# Save blend with last state rebuilt as Idle for reference
clear_anim()
build_idle()
blend_path = os.path.join(BLEND_DIR, "SoulFruits_R15_Anims.blend")
bpy.ops.wm.save_as_mainfile(filepath=blend_path)
print("Saved", blend_path)
print("DONE", len(exports), "fbx")
