#!/usr/bin/env python3
"""Render M1 polish preview frames + simple GIF-like strip."""
import math, os
import bpy
from mathutils import Euler, Vector, Matrix

OUT = "/workspace/soul-fruits-animations/preview"
BLEND = "/workspace/soul-fruits-animations/blend/SoulFruits_R15_Anims.blend"
os.makedirs(OUT, exist_ok=True)

bpy.ops.wm.open_mainfile(filepath=BLEND)
arm = bpy.data.objects.get("R15")
assert arm

# Make armature visible with sticks + add mesh bones visualization via skinning simple capsules? 
# Better: use armature display as OCTAHEDRAL and enable bone envelopes / stick in viewport render
# For EEVEE stills: create simple bone meshes parented OR use grease - easiest is Viewport OpenGL render of pose mode with bone shapes.

scene = bpy.context.scene
scene.render.engine = "BLENDER_EEVEE"
# Blender 5 might use EEVEE_NEXT
if hasattr(bpy.types, 'RenderEngine'):
    try:
        scene.render.engine = "BLENDER_EEVEE_NEXT"
    except Exception:
        pass

scene.render.resolution_x = 720
scene.render.resolution_y = 720
scene.render.fps = 30
scene.render.image_settings.file_format = "PNG"
scene.render.film_transparent = False

# World bg
world = bpy.data.worlds.new("PreviewWorld")
scene.world = world
world.use_nodes = True
bg = world.node_tree.nodes["Background"]
bg.inputs[0].default_value = (0.12, 0.13, 0.16, 1)
bg.inputs[1].default_value = 1.0

# Light
bpy.ops.object.light_add(type='SUN', location=(3, -2, 8))
sun = bpy.context.object
sun.data.energy = 3.0

# Camera
bpy.ops.object.camera_add(location=(2.8, -3.2, 1.6))
cam = bpy.context.object
cam.rotation_euler = Euler((math.radians(75), 0, math.radians(40)), 'XYZ')
scene.camera = cam

# Show armature nicely: add mesh stick figure parented to bones
def add_limb(name, head, tail, radius=0.05):
    # create cone/cylinder between head and tail as mesh
    dx = Vector(tail) - Vector(head)
    length = dx.length
    if length < 1e-6:
        return None
    mid = (Vector(head) + Vector(tail)) * 0.5
    bpy.ops.mesh.primitive_cylinder_add(radius=radius, depth=length, location=mid)
    obj = bpy.context.object
    obj.name = name
    # orient
    direction = dx.normalized()
    # default cylinder along Z
    quat = direction.to_track_quat('Z', 'Y')
    obj.rotation_euler = quat.to_euler()
    # material
    mat = bpy.data.materials.new(name + "Mat")
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    if bsdf:
        bsdf.inputs["Base Color"].default_value = (0.85, 0.55, 0.35, 1)
        if "Roughness" in bsdf.inputs:
            bsdf.inputs["Roughness"].default_value = 0.45
    obj.data.materials.append(mat)
    return obj

# Build simple R15 stick mesh matching rest pose bone positions from armature edit
bpy.context.view_layer.objects.active = arm
bpy.ops.object.mode_set(mode='EDIT')
ebones = {b.name: (b.head.copy(), b.tail.copy()) for b in arm.data.edit_bones}
bpy.ops.object.mode_set(mode='OBJECT')

# Create meshes and parent to bones with bone relative
limbs = []
for bname, (h, t) in ebones.items():
    if bname == "HumanoidRootPart":
        continue
    obj = add_limb(f"Mesh_{bname}", h, t, radius=0.04 if "Hand" in bname or "Foot" in bname else 0.055)
    if not obj:
        continue
    # clear transform parenting to bone
    obj.parent = arm
    obj.parent_type = 'BONE'
    obj.parent_bone = bname
    # After bone parent, reset to sit on bone: local identity at bone tip is tricky.
    # Simpler approach: use armature modifier with generated mesh - skip, use COPY_TRANSFORMS
    obj.parent = None
    # Constraint copy transforms from pose bone
    c = obj.constraints.new('COPY_TRANSFORMS')
    c.target = arm
    c.subtarget = bname
    # Adjust: bone transform is at tail; scale length already baked - offset along bone
    # Instead rebuild each frame from pose matrices — do procedural update in frame loop
    limbs.append((obj, bname, (h-t).length if False else (Vector(t)-Vector(h)).length))

# Better: delete constraint approach and update mesh locations each frame from pose bones
for obj, bname, length in limbs:
    for c in list(obj.constraints):
        obj.constraints.remove(c)

# Head sphere
bpy.ops.mesh.primitive_uv_sphere_add(radius=0.12, location=(0,0,1.7))
head_mesh = bpy.context.object
head_mesh.name = "Mesh_HeadBall"
mat = bpy.data.materials.new("SkinMat")
mat.use_nodes = True
bsdf = mat.node_tree.nodes.get("Principled BSDF")
if bsdf:
    bsdf.inputs["Base Color"].default_value = (0.9, 0.7, 0.55, 1)
head_mesh.data.materials.append(mat)

# Apply polished M1_4 action (heavy punch looks best for preview) or cycle M1_1
# Rebuild M1_1 keys on armature for preview animation
bpy.ops.object.select_all(action='DESELECT')
arm.select_set(True)
bpy.context.view_layer.objects.active = arm
bpy.ops.object.mode_set(mode='POSE')
pose = arm.pose

def clear_anim():
    if arm.animation_data:
        arm.animation_data_clear()
    for pb in pose.bones:
        pb.rotation_mode = 'XYZ'
        pb.rotation_euler = (0,0,0)
        pb.location = (0,0,0)

def kf(bone, frame, rot=None, loc=None):
    pb = pose.bones[bone]
    pb.rotation_mode = 'XYZ'
    bpy.context.scene.frame_set(frame)
    if rot is not None:
        pb.rotation_euler = Euler(rot, 'XYZ')
        pb.keyframe_insert(data_path='rotation_euler', frame=frame)
    if loc is not None:
        pb.location = Vector(loc)
        pb.keyframe_insert(data_path='location', frame=frame)

clear_anim()
# M1 combo sequence: punch1 L, punch2 R, punch3 L, punch4 R heavy — combined timeline
def punch_at(base, hit_off, left=True, heavy=False):
    side = "Left" if left else "Right"
    other = "Right" if left else "Left"
    wind = base + max(0, hit_off - 2)
    hit = base + hit_off
    rec = hit + (4 if heavy else 3)
    end = hit + (6 if heavy else 5)
    kf(f"{side}UpperArm", wind, rot=(1.0, 0.15 if left else -0.15, 0.9 if left else -0.9))
    kf(f"{side}LowerArm", wind, rot=(1.4, 0, 0))
    kf(f"{other}UpperArm", wind, rot=(-0.3, 0, -0.4 if left else 0.4))
    kf("UpperTorso", wind, rot=(0.08, 0, 0.22 if left else -0.22))
    kf("LowerTorso", wind, rot=(0, 0, 0.12 if left else -0.12), loc=(0, -0.02, 0))
    reach = -1.45 if heavy else -1.25
    kf(f"{side}UpperArm", hit, rot=(reach, 0.25 if left else -0.25, 0.05 if left else -0.05))
    kf(f"{side}LowerArm", hit, rot=(0.05, 0, 0))
    kf(f"{other}UpperArm", hit, rot=(0.55, 0, -0.55 if left else 0.55))
    kf("UpperTorso", hit, rot=(0.22 if heavy else 0.16, 0, -0.35 if left else 0.35))
    kf("LowerTorso", hit, rot=(0.1, 0, -0.18 if left else 0.18), loc=(0, 0.04 if heavy else 0.02, 0))
    kf("Head", hit, rot=(0.05, 0, -0.12 if left else 0.12))
    kf(f"{side}UpperArm", rec, rot=(0.25, 0, 0.3 if left else -0.3))
    kf(f"{side}LowerArm", rec, rot=(0.35, 0, 0))
    kf("UpperTorso", rec, rot=(0.04, 0, 0))
    kf("LowerTorso", rec, rot=(0,0,0), loc=(0,0,0))
    kf("Head", end, rot=(0,0,0))
    kf(f"{side}UpperArm", end, rot=(0.15, 0, 0.2 if left else -0.2))
    kf("UpperTorso", end, rot=(0,0,0))
    return end

e1 = punch_at(1, 4, left=True)
e2 = punch_at(e1+1, 4, left=False)
e3 = punch_at(e2+1, 4, left=True)
e4 = punch_at(e3+1, 4, left=False, heavy=True)
total = e4 + 2
scene.frame_start = 1
scene.frame_end = total

bpy.ops.object.mode_set(mode='OBJECT')

# Floor
bpy.ops.mesh.primitive_plane_add(size=6, location=(0,0,0))
floor = bpy.context.object
fmat = bpy.data.materials.new("Floor")
fmat.use_nodes = True
bsdf = fmat.node_tree.nodes.get("Principled BSDF")
if bsdf:
    bsdf.inputs["Base Color"].default_value = (0.18, 0.19, 0.22, 1)
floor.data.materials.append(fmat)

def sync_limbs(frame):
    scene.frame_set(frame)
    bpy.context.view_layer.update()
    for obj, bname, length in limbs:
        pb = arm.pose.bones[bname]
        # world matrix of bone
        mw = arm.matrix_world @ pb.matrix
        # bone Y axis is typically along bone in Roblox export — our armature uses head->tail
        # place cylinder at mid of bone
        head = mw.translation
        # direction from bone matrix Y
        direction = (mw.to_3x3() @ Vector((0, 1, 0))).normalized()
        # actual bone length from data
        blen = arm.data.bones[bname].length
        mid = head + direction * (blen * 0.5)
        obj.location = mid
        quat = direction.to_track_quat('Z', 'Y')
        obj.rotation_euler = quat.to_euler()
        # scale Z to length
        obj.scale = (1, 1, max(blen / max(obj.dimensions.z if obj.dimensions.z else 1, 1e-4), 0.01))
        # simpler: set dimensions via scale from rest depth
    # head ball
    if "Head" in arm.pose.bones:
        pb = arm.pose.bones["Head"]
        mw = arm.matrix_world @ pb.matrix
        head_mesh.location = mw.translation + (mw.to_3x3() @ Vector((0, 0.12, 0)))

# Render key frames
frames = [1, 5, 12, 20, 28, 36, 44, total]
paths = []
for i, f in enumerate(frames):
    sync_limbs(f)
    # also fix scale - recompute cylinder depth each time by remaking scale from bone length
    for obj, bname, _ in limbs:
        pb = arm.pose.bones[bname]
        mw = arm.matrix_world @ pb.matrix
        blen = arm.data.bones[bname].length
        direction = (mw.to_3x3() @ Vector((0, 1, 0))).normalized()
        # In Blender armature, bone local Y is along bone
        direction = (mw.to_3x3() @ Vector((0, 1, 0)))
        if direction.length < 1e-6:
            direction = Vector((0,0,1))
        else:
            direction.normalize()
        head = mw.translation
        mid = head + direction * (blen * 0.5)
        obj.location = mid
        obj.rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
        # original cylinder depth was rest length stored? use scale.z = blen / 1.0 if depth was 1 — we created with depth=length at rest
        # reset scale and set depth via scale: default depth = rest length at creation
        rest_len = (Vector(ebones[bname][1]) - Vector(ebones[bname][0])).length
        obj.scale = (1, 1, blen / max(rest_len, 1e-4))
    path = os.path.join(OUT, f"m1_frame_{i:02d}.png")
    scene.render.filepath = path
    bpy.ops.render.render(write_still=True)
    paths.append(path)
    print("rendered", path)

# Contact sheet with PIL if available
try:
    from PIL import Image
    imgs = [Image.open(p).convert("RGB") for p in paths]
    w, h = imgs[0].size
    cols = 4
    rows = (len(imgs) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * w, rows * h), (30, 32, 38))
    for i, im in enumerate(imgs):
        sheet.paste(im, ((i % cols) * w, (i // cols) * h))
    sheet_path = os.path.join(OUT, "m1_combo_preview.png")
    sheet.save(sheet_path, optimize=True)
    print("SHEET", sheet_path)
    # also save middle hit frame large
    imgs[3].save(os.path.join(OUT, "m1_hit_preview.png"))
except Exception as e:
    print("PIL fail", e)
    sheet_path = paths[3]

print("DONE", total)
