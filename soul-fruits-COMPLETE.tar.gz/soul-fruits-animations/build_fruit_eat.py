#!/usr/bin/env python3
"""BF-style physical fruit eat + short spin celebrate."""
import math, os
import bpy
from mathutils import Euler, Vector

OUT = "/workspace/soul-fruits-animations"
FBX_DIR = os.path.join(OUT, "fbx")
BLEND = os.path.join(OUT, "blend", "SoulFruits_R15_Anims.blend")
bpy.ops.wm.open_mainfile(filepath=BLEND)
arm = bpy.data.objects.get("R15")
assert arm
bpy.ops.object.select_all(action="DESELECT")
arm.select_set(True)
bpy.context.view_layer.objects.active = arm
bpy.ops.object.mode_set(mode="POSE")
pose = arm.pose
bpy.context.scene.render.fps = 30

def clear():
    if arm.animation_data:
        arm.animation_data_clear()
    for pb in pose.bones:
        pb.rotation_mode = "XYZ"
        pb.rotation_euler = (0,0,0)
        pb.location = (0,0,0)

def kf(bone, frame, rot=None, loc=None):
    pb = pose.bones[bone]
    pb.rotation_mode = "XYZ"
    bpy.context.scene.frame_set(frame)
    if rot is not None:
        pb.rotation_euler = Euler(rot, "XYZ")
        pb.keyframe_insert(data_path="rotation_euler", frame=frame)
    if loc is not None:
        pb.location = Vector(loc)
        pb.keyframe_insert(data_path="location", frame=frame)

def export(name, frames, builder):
    clear(); builder()
    if not arm.animation_data:
        arm.animation_data_create()
    action = arm.animation_data.action
    if action is None:
        kf("UpperTorso", 1, rot=(0,0,0))
        action = arm.animation_data.action
    action.name = name
    bpy.context.scene.frame_start = 1
    bpy.context.scene.frame_end = frames
    track = arm.animation_data.nla_tracks.new()
    track.name = name
    track.strips.new(name, 1, action)
    path = os.path.join(FBX_DIR, f"{name}.fbx")
    bpy.ops.export_scene.fbx(
        filepath=path, use_selection=True, object_types={"ARMATURE"},
        add_leaf_bones=False, bake_anim=True, bake_anim_use_all_bones=True,
        bake_anim_use_nla_strips=False, bake_anim_use_all_actions=False,
        bake_anim_force_startend_keying=True, bake_anim_step=1.0,
        bake_anim_simplify_factor=0.0, armature_nodetype="NULL",
        use_armature_deform_only=False, primary_bone_axis="Y",
        secondary_bone_axis="X", axis_forward="-Z", axis_up="Y",
    )
    print("Exported", path)
    while arm.animation_data.nla_tracks:
        arm.animation_data.nla_tracks.remove(arm.animation_data.nla_tracks[0])
    arm.animation_data_clear()

def build_eat():
    # Hold fruit up (R hand) → to mouth → bite → swallow settle (~1.2s @30fps = 36)
    # 1-8 raise, 9-16 to mouth, 17-24 bite, 25-36 settle
    for f, a in [(1,0),(6,0.7),(10,1.0),(16,1.0),(20,0.9),(24,0.6),(30,0.2),(36,0)]:
        to_mouth = 1.0 if 10 <= f <= 24 else (a if f < 10 else a)
        bite = 1.0 if 17 <= f <= 22 else 0.0
        kf("UpperTorso", f, rot=(0.05*a, 0, -0.08*a))
        kf("Head", f, rot=(0.15*to_mouth + 0.1*bite, 0, 0.05*a))
        # right arm brings fruit to face
        kf("RightUpperArm", f, rot=(-0.9*to_mouth, -0.35*to_mouth, -1.0*to_mouth))
        kf("RightLowerArm", f, rot=(1.5*to_mouth, 0, 0.15*to_mouth))
        kf("RightHand", f, rot=(0.2*to_mouth, 0, 0))
        kf("LeftUpperArm", f, rot=(0.15*a, 0, 0.25*a))
        kf("LowerTorso", f, rot=(0.03*a, 0, 0))

def build_spin():
    # short celebrate/inspect spin pose while fruit appears (~20 frames)
    for f in range(1, 21):
        t = (f-1)/20.0
        a = math.sin(t * math.pi)  # ease in-out
        yaw = math.sin(t * math.pi * 2) * 0.25
        kf("LowerTorso", f, rot=(0.05*a, 0, yaw*0.3))
        kf("UpperTorso", f, rot=(0.08*a, 0, yaw))
        kf("Head", f, rot=(-0.05*a, 0, yaw*0.5))
        kf("RightUpperArm", f, rot=(-0.6*a, -0.2*a, -0.8*a))
        kf("RightLowerArm", f, rot=(1.0*a, 0, 0))
        kf("LeftUpperArm", f, rot=(0.2*a, 0, 0.4*a))

bpy.ops.object.mode_set(mode="OBJECT")
arm.select_set(True)
export("SF_FruitEat", 36, build_eat)
export("SF_FruitSpin", 20, build_spin)
bpy.ops.wm.save_as_mainfile(filepath=BLEND)
print("DONE")
