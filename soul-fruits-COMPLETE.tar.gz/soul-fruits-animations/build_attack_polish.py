#!/usr/bin/env python3
"""Attack polish pass: snappier M1, clearer casts, stronger Susanoo."""
import math, os
import bpy
from mathutils import Euler, Vector

OUT = "/workspace/soul-fruits-animations"
FBX_DIR = os.path.join(OUT, "fbx")
BLEND = os.path.join(OUT, "blend", "SoulFruits_R15_Anims.blend")
bpy.ops.wm.open_mainfile(filepath=BLEND)
arm = bpy.data.objects.get("R15")
assert arm
bpy.ops.object.select_all(action="DESELECT")
arm.select_set(True)
bpy.context.view_layer.objects.active = arm
bpy.ops.object.mode_set(mode="POSE")
pose = arm.pose
bpy.context.scene.render.fps = 30

def clear():
    if arm.animation_data:
        arm.animation_data_clear()
    for pb in pose.bones:
        pb.rotation_mode = "XYZ"
        pb.rotation_euler = (0,0,0)
        pb.location = (0,0,0)

def kf(bone, frame, rot=None, loc=None):
    pb = pose.bones[bone]
    pb.rotation_mode = "XYZ"
    bpy.context.scene.frame_set(frame)
    if rot is not None:
        pb.rotation_euler = Euler(rot, "XYZ")
        pb.keyframe_insert(data_path="rotation_euler", frame=frame)
    if loc is not None:
        pb.location = Vector(loc)
        pb.keyframe_insert(data_path="location", frame=frame)

def export(name, frames, builder):
    clear(); builder()
    if not arm.animation_data:
        arm.animation_data_create()
    action = arm.animation_data.action
    if action is None:
        kf("UpperTorso", 1, rot=(0,0,0)); action = arm.animation_data.action
    action.name = name
    bpy.context.scene.frame_start = 1
    bpy.context.scene.frame_end = frames
    track = arm.animation_data.nla_tracks.new(); track.name = name
    track.strips.new(name, 1, action)
    path = os.path.join(FBX_DIR, f"{name}.fbx")
    bpy.ops.export_scene.fbx(
        filepath=path, use_selection=True, object_types={"ARMATURE"},
        add_leaf_bones=False, bake_anim=True, bake_anim_use_all_bones=True,
        bake_anim_use_nla_strips=False, bake_anim_use_all_actions=False,
        bake_anim_force_startend_keying=True, bake_anim_step=1.0,
        bake_anim_simplify_factor=0.0, armature_nodetype="NULL",
        use_armature_deform_only=False, primary_bone_axis="Y",
        secondary_bone_axis="X", axis_forward="-Z", axis_up="Y",
    )
    print("Exported", path)
    while arm.animation_data.nla_tracks:
        arm.animation_data.nla_tracks.remove(arm.animation_data.nla_tracks[0])
    arm.animation_data_clear()

def punch(hit_f, left=True, heavy=False):
    side = "Left" if left else "Right"
    other = "Right" if left else "Left"
    wind = max(1, hit_f - 2)
    rec = hit_f + (4 if heavy else 3)
    end = hit_f + (6 if heavy else 5)
    # windup short
    kf(f"{side}UpperArm", wind, rot=(1.0, 0.15 if left else -0.15, 0.9 if left else -0.9))
    kf(f"{side}LowerArm", wind, rot=(1.4, 0, 0))
    kf(f"{other}UpperArm", wind, rot=(-0.3, 0, -0.4 if left else 0.4))
    kf("UpperTorso", wind, rot=(0.08, 0, 0.22 if left else -0.22))
    kf("LowerTorso", wind, rot=(0, 0, 0.12 if left else -0.12), loc=(0, -0.02, 0))
    # SNAP hit
    reach = -1.45 if heavy else -1.25
    kf(f"{side}UpperArm", hit_f, rot=(reach, 0.25 if left else -0.25, 0.05 if left else -0.05))
    kf(f"{side}LowerArm", hit_f, rot=(0.05, 0, 0))
    kf(f"{other}UpperArm", hit_f, rot=(0.55, 0, -0.55 if left else 0.55))
    kf("UpperTorso", hit_f, rot=(0.22 if heavy else 0.16, 0, -0.35 if left else 0.35))
    kf("LowerTorso", hit_f, rot=(0.1, 0, -0.18 if left else 0.18), loc=(0, 0.04 if heavy else 0.02, 0))
    kf("Head", hit_f, rot=(0.05, 0, -0.12 if left else 0.12))
    # recover
    kf(f"{side}UpperArm", rec, rot=(0.25, 0, 0.3 if left else -0.3))
    kf(f"{side}LowerArm", rec, rot=(0.35, 0, 0))
    kf("UpperTorso", rec, rot=(0.04, 0, 0))
    kf("LowerTorso", rec, rot=(0, 0, 0), loc=(0,0,0))
    kf("Head", end, rot=(0,0,0))
    kf(f"{side}UpperArm", end, rot=(0.15, 0, 0.2 if left else -0.2))
    kf("UpperTorso", end, rot=(0,0,0))
    kf("LowerTorso", end, rot=(0,0,0))

def build_m1(n):
    left = n in (1, 3)
    heavy = n == 4
    punch(4, left=left, heavy=heavy)

# --- Fruit casts (dreck) more readable ---
def build_fruit_z():
    for f,a in [(1,0),(3,0.8),(5,1),(8,0.9),(12,0)]:
        kf("UpperTorso", f, rot=(0.18*a,0,0))
        kf("Head", f, rot=(-0.1*a,0,0))
        kf("LeftUpperArm", f, rot=(-1.05*a, 0.25*a, 0.75*a))
        kf("RightUpperArm", f, rot=(-1.05*a, -0.25*a, -0.75*a))
        kf("LeftLowerArm", f, rot=(1.25*a,0,0))
        kf("RightLowerArm", f, rot=(1.25*a,0,0))
        kf("LowerTorso", f, rot=(0.08*a,0,0))

def build_fruit_x():
    for f,a in [(1,0),(3,0.85),(5,1),(7,0.35),(11,0)]:
        wind = 1 if f<=3 else 0
        throw = 1 if f==5 else (0.4 if f==7 else 0)
        kf("UpperTorso", f, rot=(0.12*a,0, -0.25*wind + 0.35*throw))
        kf("LowerTorso", f, rot=(0,0, -0.12*wind + 0.15*throw))
        if f <= 3:
            kf("RightUpperArm", f, rot=(0.85*a, -0.4*a, -1.2*a))
            kf("RightLowerArm", f, rot=(1.55*a,0,0))
        else:
            kf("RightUpperArm", f, rot=(-1.35*a, 0.15*a, -0.15*a))
            kf("RightLowerArm", f, rot=(0.1*a,0,0))
        kf("LeftUpperArm", f, rot=(0.4*a,0,0.5*a))
        kf("Head", f, rot=(0,0,0.12*wind - 0.08*throw))

def build_fruit_c():
    for f,a in [(1,0),(3,0.6),(5,1),(8,0.45),(12,0)]:
        kf("LowerTorso", f, rot=(0.35*a,0,0), loc=(0,0,-0.06*a))
        kf("UpperTorso", f, rot=(0.45*a,0,0))
        kf("Head", f, rot=(0.2*a,0,0))
        kf("LeftUpperArm", f, rot=(1.0*a,0,0.35*a))
        kf("RightUpperArm", f, rot=(1.0*a,0,-0.35*a))
        kf("LeftLowerArm", f, rot=(0.5*a,0,0))
        kf("RightLowerArm", f, rot=(0.5*a,0,0))
        kf("LeftUpperLeg", f, rot=(-0.2*a,0,0))
        kf("RightUpperLeg", f, rot=(0.35*a,0,0))

def build_fruit_v():
    for f,a in [(1,0),(4,0.7),(8,1),(13,0.75),(18,0)]:
        kf("LowerTorso", f, rot=(0.1*a,0,0), loc=(0,0,-0.03*a))
        kf("UpperTorso", f, rot=(0.2*a,0,0))
        kf("LeftUpperArm", f, rot=(-0.55*a,0.15*a,1.35*a))
        kf("RightUpperArm", f, rot=(-0.55*a,-0.15*a,-1.35*a))
        kf("LeftLowerArm", f, rot=(0.55*a,0,0))
        kf("RightLowerArm", f, rot=(0.55*a,0,0))
        kf("LeftUpperLeg", f, rot=(0.15*a,0.2*a,0))
        kf("RightUpperLeg", f, rot=(0.15*a,-0.2*a,0))
        kf("Head", f, rot=(-0.08*a,0,0))

# Eye-line sharper
def build_blood_z():
    for f,a in [(1,0),(3,0.85),(6,1),(10,0.4),(15,0)]:
        kf("UpperTorso", f, rot=(0.1*a,0,0.08*a))
        kf("Head", f, rot=(-0.08*a,0,0.2*a if f<8 else -0.1*a))
        kf("RightUpperArm", f, rot=(-0.65*a,-0.5*a,-1.25*a))
        kf("RightLowerArm", f, rot=(1.75*a,0,0.25*a))
        kf("LeftUpperArm", f, rot=(0.25*a,0,0.4*a))
        kf("LowerTorso", f, rot=(0,0,0.06*a))

def build_blood_x():
    for f,a in [(1,0),(3,0.75),(6,1),(9,0.4),(13,0)]:
        m = 1 if f<=3 else 0.25
        p = 1 if f==6 else (0.45 if f==9 else 0)
        kf("UpperTorso", f, rot=(0.15*a,0,-0.25*m+0.4*p))
        kf("LeftUpperArm", f, rot=(-0.85*m-0.35*p,0.25*a,0.95*m))
        kf("RightUpperArm", f, rot=(-0.85*m-1.4*p,-0.25*a,-0.95*m+0.25*p))
        kf("LeftLowerArm", f, rot=(1.0*m,0,0))
        kf("RightLowerArm", f, rot=(1.0*m*(1-p)+0.1*p,0,0))
        kf("LowerTorso", f, rot=(0.08*a,0,0.12*p))
        kf("Head", f, rot=(0,0,0.12*a))

def build_blood_c():
    for f,a in [(1,0),(4,1),(12,1),(18,0)]:
        kf("LowerTorso", f, rot=(-0.12*a,0,0), loc=(0,-0.03*a,0))
        kf("UpperTorso", f, rot=(-0.15*a,0,0))
        kf("Head", f, rot=(0.18*a,0,0))
        kf("LeftUpperArm", f, rot=(-0.45*a,0.2*a,1.1*a))
        kf("RightUpperArm", f, rot=(-0.45*a,-0.2*a,-1.1*a))
        kf("LeftLowerArm", f, rot=(0.5*a,0,0))
        kf("RightLowerArm", f, rot=(0.5*a,0,0))
        kf("LeftUpperLeg", f, rot=(0.2*a,0.15*a,0))
        kf("RightUpperLeg", f, rot=(0.15*a,-0.15*a,0))

def build_blood_v():
    for f,a in [(1,0),(4,0.55),(8,1),(14,0.9),(20,0)]:
        kf("LowerTorso", f, rot=(0.12*a,0,0), loc=(0,0,-0.04*a))
        kf("UpperTorso", f, rot=(-0.22*a,0,0))
        kf("Head", f, rot=(-0.28*a,0,0))
        kf("LeftUpperArm", f, rot=(-1.55*a,0.25*a,1.0*a))
        kf("RightUpperArm", f, rot=(-1.55*a,-0.25*a,-1.0*a))
        kf("LeftLowerArm", f, rot=(0.35*a,0,0))
        kf("RightLowerArm", f, rot=(0.35*a,0,0))
        kf("LeftUpperLeg", f, rot=(0.25*a,0.25*a,0))
        kf("RightUpperLeg", f, rot=(0.25*a,-0.25*a,0))

def build_susanoo_start():
    for f,a in [(1,0),(3,0.55),(6,1),(10,1),(14,0.95)]:
        kf("LowerTorso", f, rot=(0.25*a if f<7 else 0.08*a,0,0), loc=(0,0,-0.07*a if f<7 else -0.03*a))
        kf("UpperTorso", f, rot=(-0.35*a,0,0))
        kf("Head", f, rot=(-0.2*a,0,0))
        kf("LeftUpperArm", f, rot=(-1.65*a,0.35*a,1.2*a))
        kf("RightUpperArm", f, rot=(-1.65*a,-0.35*a,-1.2*a))
        kf("LeftLowerArm", f, rot=(0.45*a,0,0))
        kf("RightLowerArm", f, rot=(0.45*a,0,0))
        kf("LeftUpperLeg", f, rot=(0.3*a,0.25*a,0))
        kf("RightUpperLeg", f, rot=(0.3*a,-0.25*a,0))

def build_susanoo_loop():
    for f,t in [(1,0),(11,0.5),(21,1),(31,0.5),(41,0)]:
        w = math.sin(t*math.pi*2)*0.05
        kf("LowerTorso", f, rot=(0.06,0,w), loc=(0,0,-0.03))
        kf("UpperTorso", f, rot=(-0.28+w*0.4,0,0))
        kf("Head", f, rot=(-0.12,0,0))
        kf("LeftUpperArm", f, rot=(-1.45+w,0.3,1.1))
        kf("RightUpperArm", f, rot=(-1.45-w,-0.3,-1.1))
        kf("LeftLowerArm", f, rot=(0.4,0,0))
        kf("RightLowerArm", f, rot=(0.4,0,0))
        kf("LeftUpperLeg", f, rot=(0.22,0.2,0))
        kf("RightUpperLeg", f, rot=(0.22,-0.2,0))

def build_hit_react():
    for f,a in [(1,0),(2,1),(5,0.55),(10,0.2),(14,0)]:
        kf("UpperTorso", f, rot=(-0.4*a,0,0.15*a), loc=(0,-0.05*a,0))
        kf("Head", f, rot=(-0.3*a,0,0))
        kf("LeftUpperArm", f, rot=(0.45*a,0,0.65*a))
        kf("RightUpperArm", f, rot=(0.45*a,0,-0.65*a))
        kf("LowerTorso", f, rot=(-0.15*a,0,0))

bpy.ops.object.mode_set(mode="OBJECT")
arm.select_set(True)

jobs = [
    ("SF_M1_1", 10, lambda: build_m1(1)),
    ("SF_M1_2", 10, lambda: build_m1(2)),
    ("SF_M1_3", 10, lambda: build_m1(3)),
    ("SF_M1_4", 12, lambda: build_m1(4)),
    ("SF_FruitZ", 12, build_fruit_z),
    ("SF_FruitX", 11, build_fruit_x),
    ("SF_FruitC", 12, build_fruit_c),
    ("SF_FruitV", 18, build_fruit_v),
    ("SF_BloodZ", 15, build_blood_z),
    ("SF_BloodX", 13, build_blood_x),
    ("SF_BloodC", 18, build_blood_c),
    ("SF_BloodV", 20, build_blood_v),
    ("SF_SusanooStart", 14, build_susanoo_start),
    ("SF_SusanooLoop", 40, build_susanoo_loop),
    ("SF_HitReact", 14, build_hit_react),
]
for name, fr, fn in jobs:
    export(name, fr, fn)

bpy.ops.wm.save_as_mainfile(filepath=BLEND)
print("POLISH DONE", len(jobs))
