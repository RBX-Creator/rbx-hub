#!/usr/bin/env python3
"""Add Dreck Fruit cast animations Z/X/C/V to Soul Fruits R15 package."""
import math
import os
import bpy
from mathutils import Euler, Vector

OUT = "/workspace/soul-fruits-animations"
FBX_DIR = os.path.join(OUT, "fbx")
BLEND = os.path.join(OUT, "blend", "SoulFruits_R15_Anims.blend")

bpy.ops.wm.open_mainfile(filepath=BLEND)

arm_obj = bpy.data.objects.get("R15")
if arm_obj is None:
    raise SystemExit("R15 armature missing")

bpy.ops.object.select_all(action="DESELECT")
arm_obj.select_set(True)
bpy.context.view_layer.objects.active = arm_obj
bpy.ops.object.mode_set(mode="POSE")
pose = arm_obj.pose
FPS = 30
bpy.context.scene.render.fps = FPS


def clear_anim():
    if arm_obj.animation_data:
        arm_obj.animation_data_clear()
    for pb in pose.bones:
        pb.rotation_mode = "XYZ"
        pb.rotation_euler = (0, 0, 0)
        pb.location = (0, 0, 0)


def kf(bone, frame, rot=None, loc=None):
    pb = pose.bones[bone]
    pb.rotation_mode = "XYZ"
    bpy.context.scene.frame_set(frame)
    if rot is not None:
        pb.rotation_euler = Euler(rot, "XYZ")
        pb.keyframe_insert(data_path="rotation_euler", frame=frame)
    if loc is not None:
        pb.location = Vector(loc)
        pb.keyframe_insert(data_path="location", frame=frame)


def export_action(name, frames, builder):
    clear_anim()
    builder()
    if not arm_obj.animation_data:
        arm_obj.animation_data_create()
    action = arm_obj.animation_data.action
    if action is None:
        kf("UpperTorso", 1, rot=(0, 0, 0))
        action = arm_obj.animation_data.action
    action.name = name
    bpy.context.scene.frame_start = 1
    bpy.context.scene.frame_end = frames
    track = arm_obj.animation_data.nla_tracks.new()
    track.name = name
    track.strips.new(name, 1, action)
    path = os.path.join(FBX_DIR, f"{name}.fbx")
    bpy.ops.export_scene.fbx(
        filepath=path,
        use_selection=True,
        object_types={"ARMATURE"},
        add_leaf_bones=False,
        bake_anim=True,
        bake_anim_use_all_bones=True,
        bake_anim_use_nla_strips=False,
        bake_anim_use_all_actions=False,
        bake_anim_force_startend_keying=True,
        bake_anim_step=1.0,
        bake_anim_simplify_factor=0.0,
        armature_nodetype="NULL",
        use_armature_deform_only=False,
        primary_bone_axis="Y",
        secondary_bone_axis="X",
        axis_forward="-Z",
        axis_up="Y",
    )
    print("Exported", path)
    while arm_obj.animation_data.nla_tracks:
        arm_obj.animation_data.nla_tracks.remove(arm_obj.animation_data.nla_tracks[0])
    arm_obj.animation_data_clear()


def build_z():
    # Erdkugel — beide Hände vor dem Körper, kurz
    for f, a in [(1, 0.0), (4, 1.0), (8, 0.85), (12, 0.0)]:
        kf("UpperTorso", f, rot=(0.12 * a, 0, 0))
        kf("Head", f, rot=(-0.08 * a, 0, 0))
        kf("LeftUpperArm", f, rot=(-0.9 * a, 0.2 * a, 0.6 * a))
        kf("RightUpperArm", f, rot=(-0.9 * a, -0.2 * a, -0.6 * a))
        kf("LeftLowerArm", f, rot=(1.1 * a, 0, 0))
        kf("RightLowerArm", f, rot=(1.1 * a, 0, 0))
        kf("LeftHand", f, rot=(0.2 * a, 0, 0))
        kf("RightHand", f, rot=(0.2 * a, 0, 0))
        kf("LowerTorso", f, rot=(0.05 * a, 0, 0))


def build_x():
    # Steinwurf — rechte Hand wirft nach vorne
    poses = [
        (1, 0.0),
        (3, 0.7),  # windup
        (6, 1.0),  # throw
        (10, 0.2),
        (12, 0.0),
    ]
    for f, a in poses:
        wind = 1.0 if f <= 3 else max(0.0, 1.0 - (f - 3) / 7)
        throw = 1.0 if f == 6 else (0.3 if f == 10 else 0.0)
        kf("UpperTorso", f, rot=(0.1 * a, 0, -0.2 * a if f < 6 else 0.25 * throw))
        kf("LowerTorso", f, rot=(0, 0, -0.1 * a if f < 6 else 0.12 * throw))
        # windup: arm back
        if f <= 3:
            kf("RightUpperArm", f, rot=(0.6 * a, -0.3 * a, -1.0 * a))
            kf("RightLowerArm", f, rot=(1.4 * a, 0, 0))
        else:
            kf("RightUpperArm", f, rot=(-1.2 * a, 0.1 * a, -0.2 * a))
            kf("RightLowerArm", f, rot=(0.2 * a, 0, 0))
        kf("LeftUpperArm", f, rot=(0.3 * a, 0, 0.4 * a))
        kf("Head", f, rot=(0, 0, 0.1 * a if f < 6 else -0.05))


def build_c():
    # Erdstoß — Stampfer / beide Arme runter
    for f, a in [(1, 0.0), (3, 0.5), (5, 1.0), (9, 0.4), (12, 0.0)]:
        kf("LowerTorso", f, rot=(0.25 * a, 0, 0), loc=(0, 0, -0.04 * a))
        kf("UpperTorso", f, rot=(0.35 * a, 0, 0))
        kf("Head", f, rot=(0.15 * a, 0, 0))
        kf("LeftUpperArm", f, rot=(0.8 * a, 0, 0.3 * a))
        kf("RightUpperArm", f, rot=(0.8 * a, 0, -0.3 * a))
        kf("LeftLowerArm", f, rot=(0.4 * a, 0, 0))
        kf("RightLowerArm", f, rot=(0.4 * a, 0, 0))
        kf("LeftUpperLeg", f, rot=(-0.15 * a, 0, 0))
        kf("RightUpperLeg", f, rot=(0.2 * a, 0, 0))


def build_v():
    # Erdwall — Arme seitlich hoch, breite Stance
    for f, a in [(1, 0.0), (4, 0.6), (8, 1.0), (14, 0.7), (18, 0.0)]:
        kf("LowerTorso", f, rot=(0.08 * a, 0, 0), loc=(0, 0, -0.02 * a))
        kf("UpperTorso", f, rot=(0.15 * a, 0, 0))
        kf("Head", f, rot=(-0.05 * a, 0, 0))
        kf("LeftUpperArm", f, rot=(-0.4 * a, 0.1 * a, 1.2 * a))
        kf("RightUpperArm", f, rot=(-0.4 * a, -0.1 * a, -1.2 * a))
        kf("LeftLowerArm", f, rot=(0.5 * a, 0, 0))
        kf("RightLowerArm", f, rot=(0.5 * a, 0, 0))
        kf("LeftUpperLeg", f, rot=(0.1 * a, 0.15 * a, 0))
        kf("RightUpperLeg", f, rot=(0.1 * a, -0.15 * a, 0))


bpy.ops.object.mode_set(mode="OBJECT")
arm_obj.select_set(True)
bpy.context.view_layer.objects.active = arm_obj

export_action("SF_FruitZ", 12, build_z)
export_action("SF_FruitX", 12, build_x)
export_action("SF_FruitC", 12, build_c)
export_action("SF_FruitV", 18, build_v)

bpy.ops.wm.save_as_mainfile(filepath=BLEND)
print("DONE fruit casts")
