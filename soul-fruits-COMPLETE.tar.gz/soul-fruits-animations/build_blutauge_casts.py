#!/usr/bin/env python3
"""Blutaugespiegel cast poses — stronger, eye/illusion feel than Dreck."""
import os
import bpy
from mathutils import Euler, Vector

OUT = "/workspace/soul-fruits-animations"
FBX_DIR = os.path.join(OUT, "fbx")
BLEND = os.path.join(OUT, "blend", "SoulFruits_R15_Anims.blend")
bpy.ops.wm.open_mainfile(filepath=BLEND)

arm_obj = bpy.data.objects.get("R15")
assert arm_obj
bpy.ops.object.select_all(action="DESELECT")
arm_obj.select_set(True)
bpy.context.view_layer.objects.active = arm_obj
bpy.ops.object.mode_set(mode="POSE")
pose = arm_obj.pose
bpy.context.scene.render.fps = 30


def clear_anim():
    if arm_obj.animation_data:
        arm_obj.animation_data_clear()
    for pb in pose.bones:
        pb.rotation_mode = "XYZ"
        pb.rotation_euler = (0, 0, 0)
        pb.location = (0, 0, 0)


def kf(bone, frame, rot=None, loc=None):
    pb = pose.bones[bone]
    pb.rotation_mode = "XYZ"
    bpy.context.scene.frame_set(frame)
    if rot is not None:
        pb.rotation_euler = Euler(rot, "XYZ")
        pb.keyframe_insert(data_path="rotation_euler", frame=frame)
    if loc is not None:
        pb.location = Vector(loc)
        pb.keyframe_insert(data_path="location", frame=frame)


def export_action(name, frames, builder):
    clear_anim()
    builder()
    if not arm_obj.animation_data:
        arm_obj.animation_data_create()
    action = arm_obj.animation_data.action
    if action is None:
        kf("UpperTorso", 1, rot=(0, 0, 0))
        action = arm_obj.animation_data.action
    action.name = name
    bpy.context.scene.frame_start = 1
    bpy.context.scene.frame_end = frames
    track = arm_obj.animation_data.nla_tracks.new()
    track.name = name
    track.strips.new(name, 1, action)
    path = os.path.join(FBX_DIR, f"{name}.fbx")
    bpy.ops.export_scene.fbx(
        filepath=path, use_selection=True, object_types={"ARMATURE"},
        add_leaf_bones=False, bake_anim=True, bake_anim_use_all_bones=True,
        bake_anim_use_nla_strips=False, bake_anim_use_all_actions=False,
        bake_anim_force_startend_keying=True, bake_anim_step=1.0,
        bake_anim_simplify_factor=0.0, armature_nodetype="NULL",
        use_armature_deform_only=False, primary_bone_axis="Y",
        secondary_bone_axis="X", axis_forward="-Z", axis_up="Y",
    )
    print("Exported", path)
    while arm_obj.animation_data.nla_tracks:
        arm_obj.animation_data.nla_tracks.remove(arm_obj.animation_data.nla_tracks[0])
    arm_obj.animation_data_clear()


def build_z():
    # Spiegelblick — Hand zum Auge, dann „Blick“ nach vorne
    for f, a in [(1, 0.0), (4, 0.8), (7, 1.0), (12, 0.3), (16, 0.0)]:
        kf("UpperTorso", f, rot=(0.08 * a, 0, 0.05 * a))
        kf("Head", f, rot=(-0.05 * a, 0, 0.15 * a if f < 8 else -0.05 * a))
        # right hand near face/eye
        kf("RightUpperArm", f, rot=(-0.5 * a, -0.4 * a, -1.1 * a))
        kf("RightLowerArm", f, rot=(1.6 * a, 0, 0.2 * a))
        kf("RightHand", f, rot=(0.3 * a, 0, 0))
        kf("LeftUpperArm", f, rot=(0.2 * a, 0, 0.35 * a))
        kf("LowerTorso", f, rot=(0, 0, 0.04 * a))


def build_x():
    # Echo-Schlag — Spiegel-Pose dann Mirror-Punch
    for f, a in [(1, 0.0), (4, 0.7), (7, 1.0), (11, 0.4), (14, 0.0)]:
        mirror = 1.0 if f <= 4 else 0.3
        punch = 1.0 if f == 7 else (0.4 if f == 11 else 0.0)
        kf("UpperTorso", f, rot=(0.12 * a, 0, -0.2 * mirror + 0.3 * punch))
        kf("Head", f, rot=(0, 0, 0.1 * a))
        # both arms symmetric windup then right punch
        kf("LeftUpperArm", f, rot=(-0.7 * mirror - 0.3 * punch, 0.2 * a, 0.8 * mirror))
        kf("RightUpperArm", f, rot=(-0.7 * mirror - 1.2 * punch, -0.2 * a, -0.8 * mirror + 0.2 * punch))
        kf("LeftLowerArm", f, rot=(0.9 * mirror, 0, 0))
        kf("RightLowerArm", f, rot=(0.9 * mirror * (1 - punch) + 0.15 * punch, 0, 0))
        kf("LowerTorso", f, rot=(0.05 * a, 0, 0.1 * punch))


def build_c():
    # Voraussicht — defensive ready stance, slight lean back, hands open
    for f, a in [(1, 0.0), (5, 1.0), (14, 1.0), (20, 0.0)]:
        kf("LowerTorso", f, rot=(-0.08 * a, 0, 0), loc=(0, -0.02 * a, 0))
        kf("UpperTorso", f, rot=(-0.1 * a, 0, 0))
        kf("Head", f, rot=(0.12 * a, 0, 0))
        kf("LeftUpperArm", f, rot=(-0.35 * a, 0.15 * a, 0.95 * a))
        kf("RightUpperArm", f, rot=(-0.35 * a, -0.15 * a, -0.95 * a))
        kf("LeftLowerArm", f, rot=(0.45 * a, 0, 0))
        kf("RightLowerArm", f, rot=(0.45 * a, 0, 0))
        kf("LeftUpperLeg", f, rot=(0.15 * a, 0.12 * a, 0))
        kf("RightUpperLeg", f, rot=(0.1 * a, -0.12 * a, 0))


def build_v():
    # Blutspiegel-Welt — Arms wide overhead/out, dramatic
    for f, a in [(1, 0.0), (5, 0.5), (10, 1.0), (16, 0.85), (22, 0.0)]:
        kf("LowerTorso", f, rot=(0.1 * a, 0, 0), loc=(0, 0, -0.03 * a))
        kf("UpperTorso", f, rot=(-0.15 * a, 0, 0))
        kf("Head", f, rot=(-0.2 * a, 0, 0))
        kf("LeftUpperArm", f, rot=(-1.4 * a, 0.2 * a, 0.9 * a))
        kf("RightUpperArm", f, rot=(-1.4 * a, -0.2 * a, -0.9 * a))
        kf("LeftLowerArm", f, rot=(0.3 * a, 0, 0))
        kf("RightLowerArm", f, rot=(0.3 * a, 0, 0))
        kf("LeftUpperLeg", f, rot=(0.2 * a, 0.2 * a, 0))
        kf("RightUpperLeg", f, rot=(0.2 * a, -0.2 * a, 0))


bpy.ops.object.mode_set(mode="OBJECT")
arm_obj.select_set(True)
export_action("SF_BloodZ", 16, build_z)
export_action("SF_BloodX", 14, build_x)
export_action("SF_BloodC", 20, build_c)
export_action("SF_BloodV", 22, build_v)
bpy.ops.wm.save_as_mainfile(filepath=BLEND)
print("DONE blood casts")
