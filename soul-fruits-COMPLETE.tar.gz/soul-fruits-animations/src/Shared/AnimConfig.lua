--!strict
--[[
	AnimConfig – AnimationIds für Soul Fruits (R15).
	Studio: ReplicatedStorage/SoulFruits/Shared/AnimConfig (ModuleScript)

	Nach FBX-Import im Animation Editor → Publish to Roblox → IDs hier eintragen.
	0 = noch nicht gesetzt (Controller skippt diese Anim).
]]

local AnimConfig = {}

AnimConfig.Ids = {
	Idle = 0,
	Walk = 0,
	Run = 0,
	Dash = 0,
	FlyStart = 0,
	FlyLoop = 0,
	FlyLand = 0,
	M1_1 = 0,
	M1_2 = 0,
	M1_3 = 0,
	M1_4 = 0,
	HitReact = 0,
	FruitZ = 0,
	FruitX = 0,
	FruitC = 0,
	FruitV = 0,
	-- Eye-line (Blutaugespiegel Legendary + Sharingan Mythical)
	BloodZ = 0,
	BloodX = 0,
	BloodC = 0,
	BloodV = 0,
	-- Sharingan R – Partial Susanoo
	SusanooStart = 0,
	SusanooLoop = 0,
	-- Physical fruit (BF-flow)
	FruitEat = 0,
	FruitSpin = 0,
}

AnimConfig.WALK_SPEED = 10
AnimConfig.RUN_SPEED = 18

AnimConfig.Priority = {
	Idle = Enum.AnimationPriority.Idle,
	Walk = Enum.AnimationPriority.Movement,
	Run = Enum.AnimationPriority.Movement,
	Dash = Enum.AnimationPriority.Action,
	FlyStart = Enum.AnimationPriority.Action,
	FlyLoop = Enum.AnimationPriority.Action,
	FlyLand = Enum.AnimationPriority.Action,
	M1 = Enum.AnimationPriority.Action2,
	HitReact = Enum.AnimationPriority.Action3,
	Fruit = Enum.AnimationPriority.Action2,
	Susanoo = Enum.AnimationPriority.Action3,
	FruitEat = Enum.AnimationPriority.Action4,
}

AnimConfig.Looped = {
	Idle = true,
	Walk = true,
	Run = true,
	Dash = false,
	FlyStart = false,
	FlyLoop = true,
	FlyLand = false,
	M1_1 = false,
	M1_2 = false,
	M1_3 = false,
	M1_4 = false,
	HitReact = false,
	FruitZ = false,
	FruitX = false,
	FruitC = false,
	FruitV = false,
	BloodZ = false,
	BloodX = false,
	BloodC = false,
	BloodV = false,
	SusanooStart = false,
	SusanooLoop = true,
	FruitEat = false,
	FruitSpin = false,
}

AnimConfig.ATTR_COMBO = "SF_M1_Combo"
AnimConfig.ATTR_FLYING = "IsFlying"
AnimConfig.ATTR_CURRENT_FRUIT = "SF_CurrentFruit"
AnimConfig.ATTR_SUSANOO_UNTIL = "SF_SusanooUntil"
AnimConfig.FRUIT_BLOOD = "Blutaugespiegel"
AnimConfig.FRUIT_SHARINGAN = "Sharingan"
AnimConfig.VFX_DASH = "VFX_Dash"
AnimConfig.VFX_FLY = "VFX_Fly"
AnimConfig.VFX_HIT = "VFX_Hit"
AnimConfig.VFX_SUSANOO = "VFX_Susanoo"
AnimConfig.ATTR_FRUIT_EAT = "SF_FruitEat"
AnimConfig.VFX_FRUIT_SPIN = "VFX_FruitSpin"
AnimConfig.VFX_FRUIT = {
	Z = "VFX_FruitZ",
	X = "VFX_FruitX",
	C = "VFX_FruitC",
	V = "VFX_FruitV",
}

function AnimConfig.UsesEyeCasts(fruitId: any): boolean
	return fruitId == AnimConfig.FRUIT_BLOOD or fruitId == AnimConfig.FRUIT_SHARINGAN
end

return AnimConfig
