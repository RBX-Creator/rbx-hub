--!strict
--[[
	AnimationController – dockt an Movement/Combat Attributes.
	Studio: StarterPlayerScripts/SoulFruits/Client/AnimationController (ModuleScript)
	Startet aus ClientBootstrap: require(...).Start()

	Hört:
	• Humanoid.Running → Idle / Walk / Run
	• Character Attribute SF_M1_Combo (1–4) → M1_n
	• VFX_Dash pulse → Dash
	• IsFlying / VFX_Fly → FlyStart → FlyLoop → FlyLand
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Shared = ReplicatedStorage:WaitForChild("SoulFruits"):WaitForChild("Shared")
local AnimConfig = require(Shared:WaitForChild("AnimConfig"))

local AnimationController = {}
local started = false

type Tracks = { [string]: AnimationTrack }

local function assetId(n: number): string?
	if typeof(n) ~= "number" or n <= 0 then
		return nil
	end
	return "rbxassetid://" .. tostring(n)
end

local function loadTrack(animator: Animator, key: string, idNumber: number, priority: Enum.AnimationPriority, looped: boolean): AnimationTrack?
	local id = assetId(idNumber)
	if not id then
		return nil
	end
	local anim = Instance.new("Animation")
	anim.AnimationId = id
	anim.Name = "SF_" .. key
	local ok, track = pcall(function()
		return animator:LoadAnimation(anim)
	end)
	anim:Destroy()
	if not ok or not track then
		warn("[SF Anim] Load failed:", key, id)
		return nil
	end
	track.Priority = priority
	track.Looped = looped
	return track
end

local function setupCharacter(character: Model)
	local humanoid = character:WaitForChild("Humanoid", 10)
	if not humanoid or not humanoid:IsA("Humanoid") then
		return
	end
	local animator = humanoid:FindFirstChildOfClass("Animator")
	if not animator then
		animator = Instance.new("Animator")
		animator.Parent = humanoid
	end

	local ids = AnimConfig.Ids
	local tracks: Tracks = {}

	local function add(key: string, idNumber: number, prioKey: string, loopKey: string)
		local prio = (AnimConfig.Priority :: any)[prioKey] or Enum.AnimationPriority.Core
		local looped = (AnimConfig.Looped :: any)[loopKey] == true
		local t = loadTrack(animator, key, idNumber, prio, looped)
		if t then
			tracks[key] = t
		end
	end

	add("Idle", ids.Idle, "Idle", "Idle")
	add("Walk", ids.Walk, "Walk", "Walk")
	add("Run", ids.Run, "Run", "Run")
	add("Dash", ids.Dash, "Dash", "Dash")
	add("FlyStart", ids.FlyStart, "FlyStart", "FlyStart")
	add("FlyLoop", ids.FlyLoop, "FlyLoop", "FlyLoop")
	add("FlyLand", ids.FlyLand, "FlyLand", "FlyLand")
	add("M1_1", ids.M1_1, "M1", "M1_1")
	add("M1_2", ids.M1_2, "M1", "M1_2")
	add("M1_3", ids.M1_3, "M1", "M1_3")
	add("M1_4", ids.M1_4, "M1", "M1_4")
	add("HitReact", ids.HitReact, "HitReact", "HitReact")
	add("FruitZ", ids.FruitZ, "Fruit", "FruitZ")
	add("FruitX", ids.FruitX, "Fruit", "FruitX")
	add("FruitC", ids.FruitC, "Fruit", "FruitC")
	add("FruitV", ids.FruitV, "Fruit", "FruitV")
	add("BloodZ", ids.BloodZ, "Fruit", "BloodZ")
	add("BloodX", ids.BloodX, "Fruit", "BloodX")
	add("BloodC", ids.BloodC, "Fruit", "BloodC")
	add("BloodV", ids.BloodV, "Fruit", "BloodV")
	add("SusanooStart", ids.SusanooStart, "Susanoo", "SusanooStart")
	add("SusanooLoop", ids.SusanooLoop, "Susanoo", "SusanooLoop")
	add("FruitEat", ids.FruitEat, "FruitEat", "FruitEat")
	add("FruitSpin", ids.FruitSpin, "Fruit", "FruitSpin")

	local locomotion: string? = nil
	local flying = false

	local function stopLoco()
		for _, name in { "Idle", "Walk", "Run" } do
			local t = tracks[name]
			if t and t.IsPlaying then
				t:Stop(0.15)
			end
		end
		locomotion = nil
	end

	local function playLoco(name: string)
		if flying then
			return
		end
		if locomotion == name then
			return
		end
		local nextTrack = tracks[name]
		if not nextTrack then
			-- IDs noch 0 → Default Humanoid anims bleiben
			locomotion = name
			return
		end
		stopLoco()
		nextTrack:Play(0.15)
		locomotion = name
	end

	local function playOneShot(name: string, fade: number?)
		local t = tracks[name]
		if not t then
			return
		end
		t:Play(fade or 0.05)
	end

	-- Locomotion
	if tracks.Idle then
		playLoco("Idle")
	end

	humanoid.Running:Connect(function(speed: number)
		if flying then
			return
		end
		if speed < 0.5 then
			playLoco("Idle")
		elseif speed < AnimConfig.RUN_SPEED - 1 then
			playLoco("Walk")
		else
			playLoco("Run")
		end
	end)

	-- M1 combo 1–4
	character:GetAttributeChangedSignal(AnimConfig.ATTR_COMBO):Connect(function()
		local idx = character:GetAttribute(AnimConfig.ATTR_COMBO)
		if typeof(idx) ~= "number" then
			return
		end
		local key = "M1_" .. tostring(math.clamp(math.floor(idx), 1, 4))
		playOneShot(key, 0.05)
	end)

	-- Dash pulse (any change while truthy-ish)
	character:GetAttributeChangedSignal(AnimConfig.VFX_DASH):Connect(function()
		local v = character:GetAttribute(AnimConfig.VFX_DASH)
		if v == nil or v == false then
			return
		end
		playOneShot("Dash", 0.02)
	end)

	local function onFly(on: boolean)
		if on and not flying then
			flying = true
			stopLoco()
			local start = tracks.FlyStart
			local loop = tracks.FlyLoop
			if start then
				start:Play(0.08)
				if loop then
					start.Stopped:Once(function()
						if flying and loop then
							loop:Play(0.1)
						end
					end)
				end
			elseif loop then
				loop:Play(0.1)
			end
		elseif not on and flying then
			flying = false
			local loop = tracks.FlyLoop
			if loop and loop.IsPlaying then
				loop:Stop(0.1)
			end
			local land = tracks.FlyLand
			if land then
				land:Play(0.08)
				land.Stopped:Once(function()
					if not flying then
						playLoco("Idle")
					end
				end)
			else
				playLoco("Idle")
			end
		end
	end

	character:GetAttributeChangedSignal(AnimConfig.VFX_FLY):Connect(function()
		onFly(character:GetAttribute(AnimConfig.VFX_FLY) == true)
	end)
	-- mirror player attribute too
	local player = Players:GetPlayerFromCharacter(character)
	if player then
		player:GetAttributeChangedSignal(AnimConfig.ATTR_FLYING):Connect(function()
			onFly(player:GetAttribute(AnimConfig.ATTR_FLYING) == true)
		end)
		if player:GetAttribute(AnimConfig.ATTR_FLYING) == true then
			onFly(true)
		end
	end


	-- Fruit casts (Attribute pulse = tick()); Blutaugespiegel → Blood*
	for letter, attrName in pairs(AnimConfig.VFX_FRUIT) do
		character:GetAttributeChangedSignal(attrName):Connect(function()
			local v = character:GetAttribute(attrName)
			if v == nil or v == false then
				return
			end
			local fruit = if player then player:GetAttribute(AnimConfig.ATTR_CURRENT_FRUIT) else nil
			local prefix = if AnimConfig.UsesEyeCasts(fruit) then "Blood" else "Fruit"
			local key = prefix .. letter
			if tracks[key] == nil and prefix == "Blood" then
				key = "Fruit" .. letter
			end
			playOneShot(key, 0.04)
		end)
	end


	-- Partial Susanoo (R) — VFX_Susanoo pulse + SF_SusanooUntil hold
	local function stopSusanoo()
		local loop = tracks.SusanooLoop
		if loop and loop.IsPlaying then
			loop:Stop(0.15)
		end
	end

	local function startSusanoo()
		stopLoco()
		local start = tracks.SusanooStart
		local loop = tracks.SusanooLoop
		if start then
			start:Play(0.05)
			if loop then
				start.Stopped:Once(function()
					local untilT = character:GetAttribute(AnimConfig.ATTR_SUSANOO_UNTIL)
					if typeof(untilT) == "number" and untilT > tick() and loop then
						loop:Play(0.1)
					end
				end)
			end
		elseif loop then
			loop:Play(0.1)
		end
	end

	character:GetAttributeChangedSignal(AnimConfig.VFX_SUSANOO):Connect(function()
		local v = character:GetAttribute(AnimConfig.VFX_SUSANOO)
		if v == nil or v == false then
			return
		end
		startSusanoo()
	end)

	if player then
		local function syncSusanooUntil()
			local untilT = player:GetAttribute(AnimConfig.ATTR_SUSANOO_UNTIL)
			if typeof(untilT) ~= "number" or untilT <= tick() then
				stopSusanoo()
			end
		end
		player:GetAttributeChangedSignal(AnimConfig.ATTR_SUSANOO_UNTIL):Connect(syncSusanooUntil)
		character:GetAttributeChangedSignal(AnimConfig.ATTR_SUSANOO_UNTIL):Connect(function()
			local untilT = character:GetAttribute(AnimConfig.ATTR_SUSANOO_UNTIL)
			if typeof(untilT) ~= "number" or untilT <= tick() then
				stopSusanoo()
			end
		end)
		-- end loop when armor expires
		task.spawn(function()
			while character.Parent do
				task.wait(0.2)
				local untilT = character:GetAttribute(AnimConfig.ATTR_SUSANOO_UNTIL)
				if typeof(untilT) == "number" and untilT > 0 and untilT <= tick() then
					stopSusanoo()
				end
			end
		end)
	end


	-- Physical fruit BF-flow: eat + gacha/stock spin
	character:GetAttributeChangedSignal(AnimConfig.ATTR_FRUIT_EAT):Connect(function()
		local v = character:GetAttribute(AnimConfig.ATTR_FRUIT_EAT)
		if v == nil or v == false then
			return
		end
		playOneShot("FruitEat", 0.05)
	end)
	if player then
		player:GetAttributeChangedSignal(AnimConfig.ATTR_FRUIT_EAT):Connect(function()
			local v = player:GetAttribute(AnimConfig.ATTR_FRUIT_EAT)
			if v == nil or v == false then
				return
			end
			playOneShot("FruitEat", 0.05)
		end)
	end
	character:GetAttributeChangedSignal(AnimConfig.VFX_FRUIT_SPIN):Connect(function()
		local v = character:GetAttribute(AnimConfig.VFX_FRUIT_SPIN)
		if v == nil or v == false then
			return
		end
		playOneShot("FruitSpin", 0.05)
	end)

	-- Optional HitReact when VFX_Hit fires BindableEvent
	local hitBe = character:FindFirstChild(AnimConfig.VFX_HIT)
	if hitBe and hitBe:IsA("BindableEvent") then
		hitBe.Event:Connect(function()
			-- nur leichte React wenn wir getroffen werden — hier: Swing-Feedback optional
			-- HitReact bewusst nicht bei jedem eigenen Hit; Scripter kann später
			-- Attribute SF_TookHit setzen. Stub: no-op für eigenen M1.
		end)
	end
end

function AnimationController.Start()
	if started then
		return
	end
	started = true

	local player = Players.LocalPlayer
	if player.Character then
		task.spawn(setupCharacter, player.Character)
	end
	player.CharacterAdded:Connect(function(character)
		task.defer(setupCharacter, character)
	end)
end

return AnimationController
