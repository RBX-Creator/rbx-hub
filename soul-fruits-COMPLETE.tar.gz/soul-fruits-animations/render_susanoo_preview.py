#!/usr/bin/env python3
import math, os
import bpy
from mathutils import Euler, Vector

OUT = "/workspace/soul-fruits-animations/preview"
BLEND = "/workspace/soul-fruits-animations/blend/SoulFruits_R15_Anims.blend"
os.makedirs(OUT, exist_ok=True)
bpy.ops.wm.open_mainfile(filepath=BLEND)
arm = bpy.data.objects.get("R15")
assert arm
scene = bpy.context.scene
try:
    scene.render.engine = "BLENDER_EEVEE_NEXT"
except Exception:
    scene.render.engine = "BLENDER_EEVEE"
scene.render.resolution_x = 640
scene.render.resolution_y = 640
scene.render.image_settings.file_format = "PNG"

world = bpy.data.worlds.new("W")
scene.world = world
world.use_nodes = True
bg = world.node_tree.nodes["Background"]
bg.inputs[0].default_value = (0.08, 0.06, 0.1, 1)
bg.inputs[1].default_value = 0.8

bpy.ops.object.light_add(type='SUN', location=(4, -3, 8))
bpy.context.object.data.energy = 2.8
bpy.ops.object.light_add(type='AREA', location=(-2, 2, 3))
bpy.context.object.data.energy = 40
bpy.context.object.data.color = (1.0, 0.3, 0.4)

bpy.ops.object.camera_add(location=(3.2, -3.4, 1.8))
cam = bpy.context.object
cam.rotation_euler = Euler((math.radians(72), 0, math.radians(42)), 'XYZ')
scene.camera = cam

bpy.context.view_layer.objects.active = arm
bpy.ops.object.mode_set(mode='EDIT')
ebones = {b.name: (b.head.copy(), b.tail.copy()) for b in arm.data.edit_bones}
bpy.ops.object.mode_set(mode='OBJECT')

limbs = []
for bname, (h, t) in ebones.items():
    if bname == "HumanoidRootPart":
        continue
    length = (Vector(t) - Vector(h)).length
    mid = (Vector(h) + Vector(t)) * 0.5
    bpy.ops.mesh.primitive_cylinder_add(radius=0.05, depth=max(length, 0.05), location=mid)
    obj = bpy.context.object
    obj.name = f"Mesh_{bname}"
    mat = bpy.data.materials.new(bname+"M")
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    if bsdf:
        # susanoo-ish crimson tint on limbs
        bsdf.inputs["Base Color"].default_value = (0.75, 0.25, 0.3, 1)
        if "Emission Color" in bsdf.inputs:
            bsdf.inputs["Emission Color"].default_value = (0.6, 0.05, 0.1, 1)
            bsdf.inputs["Emission Strength"].default_value = 0.35
        elif "Emission" in bsdf.inputs:
            bsdf.inputs["Emission"].default_value = (0.4, 0.05, 0.08, 1)
    obj.data.materials.append(mat)
    limbs.append((obj, bname, length))

bpy.ops.mesh.primitive_uv_sphere_add(radius=0.13, location=(0,0,1.7))
head_mesh = bpy.context.object
hmat = bpy.data.materials.new("HeadM")
hmat.use_nodes = True
bsdf = hmat.node_tree.nodes.get("Principled BSDF")
if bsdf:
    bsdf.inputs["Base Color"].default_value = (0.85, 0.55, 0.5, 1)
head_mesh.data.materials.append(hmat)

bpy.ops.mesh.primitive_plane_add(size=7, location=(0,0,0))
floor = bpy.context.object
fmat = bpy.data.materials.new("Floor")
fmat.use_nodes = True
bsdf = fmat.node_tree.nodes.get("Principled BSDF")
if bsdf:
    bsdf.inputs["Base Color"].default_value = (0.12, 0.1, 0.14, 1)
floor.data.materials.append(fmat)

# Susanoo start keys
bpy.ops.object.select_all(action='DESELECT')
arm.select_set(True)
bpy.context.view_layer.objects.active = arm
bpy.ops.object.mode_set(mode='POSE')
pose = arm.pose

def clear():
    if arm.animation_data:
        arm.animation_data_clear()
    for pb in pose.bones:
        pb.rotation_mode = 'XYZ'
        pb.rotation_euler = (0,0,0)
        pb.location = (0,0,0)

def kf(bone, frame, rot=None, loc=None):
    pb = pose.bones[bone]
    pb.rotation_mode = 'XYZ'
    scene.frame_set(frame)
    if rot is not None:
        pb.rotation_euler = Euler(rot, 'XYZ')
        pb.keyframe_insert(data_path='rotation_euler', frame=frame)
    if loc is not None:
        pb.location = Vector(loc)
        pb.keyframe_insert(data_path='location', frame=frame)

clear()
# Start (1-14) then loop pose hold (15-40)
for f,a in [(1,0),(3,0.55),(6,1),(10,1),(14,0.95)]:
    kf("LowerTorso", f, rot=(0.25*a if f<7 else 0.08*a,0,0), loc=(0,0,-0.07*a if f<7 else -0.03*a))
    kf("UpperTorso", f, rot=(-0.35*a,0,0))
    kf("Head", f, rot=(-0.2*a,0,0))
    kf("LeftUpperArm", f, rot=(-1.65*a,0.35*a,1.2*a))
    kf("RightUpperArm", f, rot=(-1.65*a,-0.35*a,-1.2*a))
    kf("LeftLowerArm", f, rot=(0.45*a,0,0))
    kf("RightLowerArm", f, rot=(0.45*a,0,0))
    kf("LeftUpperLeg", f, rot=(0.3*a,0.25*a,0))
    kf("RightUpperLeg", f, rot=(0.3*a,-0.25*a,0))

for f,t in [(15,0),(25,0.5),(35,1),(45,0.5),(55,0)]:
    w = math.sin(t*math.pi*2)*0.05
    kf("LowerTorso", f, rot=(0.06,0,w), loc=(0,0,-0.03))
    kf("UpperTorso", f, rot=(-0.28+w*0.4,0,0))
    kf("Head", f, rot=(-0.12,0,0))
    kf("LeftUpperArm", f, rot=(-1.45+w,0.3,1.1))
    kf("RightUpperArm", f, rot=(-1.45-w,-0.3,-1.1))
    kf("LeftLowerArm", f, rot=(0.4,0,0))
    kf("RightLowerArm", f, rot=(0.4,0,0))
    kf("LeftUpperLeg", f, rot=(0.22,0.2,0))
    kf("RightUpperLeg", f, rot=(0.22,-0.2,0))

scene.frame_start = 1
scene.frame_end = 55
bpy.ops.object.mode_set(mode='OBJECT')

def sync(frame):
    scene.frame_set(frame)
    bpy.context.view_layer.update()
    for obj, bname, rest_len in limbs:
        pb = arm.pose.bones[bname]
        mw = arm.matrix_world @ pb.matrix
        blen = arm.data.bones[bname].length
        direction = mw.to_3x3() @ Vector((0, 1, 0))
        if direction.length < 1e-6:
            direction = Vector((0,0,1))
        else:
            direction.normalize()
        head = mw.translation
        mid = head + direction * (blen * 0.5)
        obj.location = mid
        obj.rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
        obj.scale = (1, 1, blen / max(rest_len, 1e-4))
    pb = arm.pose.bones["Head"]
    mw = arm.matrix_world @ pb.matrix
    head_mesh.location = mw.translation + (mw.to_3x3() @ Vector((0, 0.12, 0)))

frames = [1, 3, 6, 10, 14, 25, 40, 55]
paths = []
for i,f in enumerate(frames):
    sync(f)
    path = os.path.join(OUT, f"susanoo_frame_{i:02d}.png")
    scene.render.filepath = path
    bpy.ops.render.render(write_still=True)
    paths.append(path)
    print("rendered", path)
print("DONE")
