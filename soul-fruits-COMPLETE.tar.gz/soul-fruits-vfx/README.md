# Soul Fruits – VFX (Overnight)

Client-VFX, dockt an die Scripter-Hooks. Studio-fertig, modular, `--!strict`.

## Inhalt

| Pfad | Was |
|------|-----|
| `src/Shared/VFXConfig.lua` | Farben + Intensitäten (Dash kurz, Fly leicht, Hit punchy) |
| `src/Shared/VFXTemplates.lua` | ParticleEmitter / Trail Builder |
| `src/Client/VFXController.lua` | dockt an `VFX_Dash` / `VFX_Fly` / `VFX_Hit` + Fruit stubs |

In `soul-fruits-foundation` gespiegelt und in `ClientBootstrap` gestartet.

## Was spielt wann

| Signal | Effekt |
|--------|--------|
| `VFX_Dash` pulse | Trail ~0.22s + Staub-Burst an den Füßen |
| `VFX_Fly` / `IsFlying` | Leichte Aura an Körper + Füßen (nicht Map-füllend) |
| `VFX_Hit` | Sparks + Impact-Staub vorne |
| `VFX_FruitZ` | Erdkugel: kompakter Erde-Burst |
| `VFX_FruitX` | Steinwurf: scharfe Splitter vorwärts |
| `VFX_FruitC` | Erdstoß: breiter Staub + Boden-Riss |
| `VFX_FruitV` | Erdwall: Säule + Bodenplatte (Server-Wall bleibt) |

Farben erstmal **einheitlich** (Gut/Böse später).

## Studio-Test

1. Fundament per Rojo/Spiegel rein.
2. Play Solo → Fraktion → **Q** = Dash-Trail/Dust · **F** = Flug-Aura · **LMB** = Hit-Sparks.
3. Output: `[SoulFruits.VFX] Controller ready …`

## Stil

Lesbar, kräftig, BF-Nähe. Dreck-Fruit-Partikel schon als Stub (Erde/Stein), echte Move-Meshes kommen mit Blender/Fruit-Service.

## Package

```
/workspace/soul-fruits-vfx/
/workspace/soul-fruits-vfx.tar.gz
```

## Dreck-Polish v1

Move-spezifische Partikel + kurze Crack-Decals (C/V). Server-Projektile/Wall bleiben Quelle der Wahrheit — Client nur Optik.

## Fruit-Paletten v1.6+

Gleicher Hook `VFX_FruitZ–V`, Farbe über `SF_CurrentFruit`:
Dreck Erde · Wind Türkis · Flame Orange · Ice Blau · Light Gold · Magma Lava · **Blutaugespiegel** Blutrot + Eye-Ring (stärker).

## Sharingan / Susanoo (v1.8)

• `SF_CurrentFruit = Sharingan` → Eye-VFX (stärker als Blutaugespiegel)
• `VFX_Susanoo` + `SF_SusanooUntil` → Partial Susanoo-Käfig (Neon-Knochen + Aura), ~2.5s
• **F** bleibt Flug — Susanoo nur **R**

## Physical Fruits BF-Flow (v1.10)

• `VFX_FruitSpin` + `SF_SpinFruitId` → Orbit-Glow + Palette-Sparks (Gacha/Stock)
• `SF_FruitEat` + `SF_EatFruitId` → Eat-Burst / Bite-Flash in Fruit-Farbe

## Attack-Polish (v1.10.1)

• M1 Hit-Confirm: mehr Sparks + Neon-Flash, Hit 4 stärker
• Fruit Casts: höhere Emit-Counts (Dreck/Flame/Ice/Eye)
• Susanoo: dickere Neon-Knochen + Helm-Hint, klarer Käfig
