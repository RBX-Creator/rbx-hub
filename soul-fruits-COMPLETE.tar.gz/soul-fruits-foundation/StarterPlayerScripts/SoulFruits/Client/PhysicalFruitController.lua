--!strict
--[[
	PhysicalFruitController – E = essen, B = lagern; Spin/Eat FX hooks.
	Studio: StarterPlayerScripts/SoulFruits/Client/PhysicalFruitController
]]

local Players = game:GetService("Players")
local UserInputService = game:GetService("UserInputService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Shared = ReplicatedStorage:WaitForChild("SoulFruits"):WaitForChild("Shared")
local Remotes = require(Shared:WaitForChild("Remotes"))

local PhysicalFruitController = {}
local started = false

function PhysicalFruitController.Start()
	if started then
		return
	end
	started = true

	local player = Players.LocalPlayer
	local storage: { [string]: boolean } = {}

	Remotes.Event("StorageUpdated").OnClientEvent:Connect(function(map)
		storage = map or {}
	end)

	Remotes.Event("FruitSpin").OnClientEvent:Connect(function(fruitId)
		-- Animator/VFX dock via VFX_FruitSpin attribute (server also sets)
		print("[SoulFruits] Fruit spin:", fruitId)
	end)

	Remotes.Event("FruitEatFX").OnClientEvent:Connect(function(fruitId)
		print("[SoulFruits] Fruit eat:", fruitId)
	end)

	UserInputService.InputBegan:Connect(function(input, gp)
		if gp then
			return
		end
		if input.KeyCode == Enum.KeyCode.E then
			Remotes.Event("FruitEat"):FireServer()
		elseif input.KeyCode == Enum.KeyCode.B then
			Remotes.Event("FruitStore"):FireServer()
		elseif input.KeyCode == Enum.KeyCode.N then
			-- retrieve first stored fruit (simple)
			for fruitId, on in storage do
				if on then
					Remotes.Event("FruitRetrieve"):FireServer(fruitId)
					break
				end
			end
		end
	end)

	print("[SoulFruits.Client] PhysicalFruit: E essen · B lagern · N Storage holen")
end

return PhysicalFruitController
