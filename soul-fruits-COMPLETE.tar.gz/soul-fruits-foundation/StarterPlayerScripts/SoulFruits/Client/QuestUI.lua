--!strict
--[[
	QuestUI – schlanke Anzeige aktive Quest + Fortschritt.
	Studio: StarterPlayerScripts/SoulFruits/Client/QuestUI (ModuleScript)
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Shared = ReplicatedStorage:WaitForChild("SoulFruits"):WaitForChild("Shared")
local Remotes = require(Shared:WaitForChild("Remotes"))
local QuestsConfig = require(Shared:WaitForChild("QuestsConfig"))

local QuestUI = {}
local started = false

function QuestUI.Start()
	if started then
		return
	end
	started = true

	local player = Players.LocalPlayer
	local gui = Instance.new("ScreenGui")
	gui.Name = "SF_QuestUI"
	gui.ResetOnSpawn = false
	gui.Parent = player:WaitForChild("PlayerGui")

	local frame = Instance.new("Frame")
	frame.Name = "Tracker"
	frame.Size = UDim2.fromOffset(260, 72)
	frame.Position = UDim2.new(0, 16, 0.35, 0)
	frame.BackgroundColor3 = Color3.fromRGB(20, 22, 28)
	frame.BackgroundTransparency = 0.2
	frame.Visible = false
	frame.Parent = gui

	local title = Instance.new("TextLabel")
	title.Name = "Title"
	title.Size = UDim2.new(1, -12, 0, 28)
	title.Position = UDim2.fromOffset(6, 6)
	title.BackgroundTransparency = 1
	title.TextXAlignment = Enum.TextXAlignment.Left
	title.TextColor3 = Color3.fromRGB(255, 220, 120)
	title.Font = Enum.Font.GothamBold
	title.TextSize = 16
	title.Text = ""
	title.Parent = frame

	local prog = Instance.new("TextLabel")
	prog.Name = "Progress"
	prog.Size = UDim2.new(1, -12, 0, 24)
	prog.Position = UDim2.fromOffset(6, 36)
	prog.BackgroundTransparency = 1
	prog.TextXAlignment = Enum.TextXAlignment.Left
	prog.TextColor3 = Color3.fromRGB(220, 220, 230)
	prog.Font = Enum.Font.Gotham
	prog.TextSize = 14
	prog.Text = ""
	prog.Parent = frame

	Remotes.Event("QuestUpdated").OnClientEvent:Connect(function(state)
		local id = state and state.ActiveQuestId
		if typeof(id) ~= "string" or id == "" then
			frame.Visible = false
			return
		end
		local def = QuestsConfig.Get(id)
		frame.Visible = true
		title.Text = if def then def.Name else id
		local need = if def then (def.TargetCount or 1) else 1
		local cur = tonumber(state.QuestProgress) or 0
		prog.Text = ("Fortschritt: %d / %d"):format(cur, need)
	end)

	print("[SoulFruits.Client] QuestUI ready")
end

return QuestUI
