--!strict
--[[
	StorageUI – zeigt gelagerte Fruits (1 Slot/Typ). Click = Retrieve.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Shared = ReplicatedStorage:WaitForChild("SoulFruits"):WaitForChild("Shared")
local Remotes = require(Shared:WaitForChild("Remotes"))

local StorageUI = {}
local started = false

function StorageUI.Start()
	if started then
		return
	end
	started = true

	local player = Players.LocalPlayer
	local gui = Instance.new("ScreenGui")
	gui.Name = "SF_StorageUI"
	gui.ResetOnSpawn = false
	gui.Parent = player:WaitForChild("PlayerGui")

	local frame = Instance.new("Frame")
	frame.Size = UDim2.fromOffset(200, 160)
	frame.Position = UDim2.new(1, -220, 0.55, 0)
	frame.BackgroundColor3 = Color3.fromRGB(22, 24, 30)
	frame.BackgroundTransparency = 0.15
	frame.Parent = gui

	local title = Instance.new("TextLabel")
	title.Size = UDim2.new(1, -8, 0, 24)
	title.Position = UDim2.fromOffset(4, 4)
	title.BackgroundTransparency = 1
	title.Text = "Fruit Storage"
	title.TextColor3 = Color3.fromRGB(255, 220, 120)
	title.Font = Enum.Font.GothamBold
	title.TextSize = 14
	title.TextXAlignment = Enum.TextXAlignment.Left
	title.Parent = frame

	local list = Instance.new("Frame")
	list.Name = "List"
	list.Size = UDim2.new(1, -8, 1, -36)
	list.Position = UDim2.fromOffset(4, 32)
	list.BackgroundTransparency = 1
	list.Parent = frame

	local layout = Instance.new("UIListLayout")
	layout.Padding = UDim.new(0, 4)
	layout.Parent = list

	local function rebuild(map: { [string]: boolean })
		for _, child in list:GetChildren() do
			if child:IsA("TextButton") then
				child:Destroy()
			end
		end
		for fruitId, on in map do
			if on then
				local btn = Instance.new("TextButton")
				btn.Size = UDim2.new(1, 0, 0, 26)
				btn.BackgroundColor3 = Color3.fromRGB(40, 44, 55)
				btn.Text = fruitId .. " — Ausrüsten"
				btn.TextColor3 = Color3.new(1, 1, 1)
				btn.Font = Enum.Font.Gotham
				btn.TextSize = 13
				btn.Parent = list
				btn.MouseButton1Click:Connect(function()
					Remotes.Event("FruitRetrieve"):FireServer(fruitId)
				end)
			end
		end
	end

	Remotes.Event("StorageUpdated").OnClientEvent:Connect(function(map)
		rebuild(map or {})
	end)

	print("[SoulFruits.Client] StorageUI ready")
end

return StorageUI
