--!strict
--[[
	FruitController – Client: Z/X/C/V → FruitMove; R → FruitSpecial when fruit has Special.
	F remains flight (MovementController) — never bound here.
	Studio: StarterPlayerScripts/SoulFruits/Client/FruitController (ModuleScript)
]]

local Players = game:GetService("Players")
local UserInputService = game:GetService("UserInputService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Shared = ReplicatedStorage:WaitForChild("SoulFruits"):WaitForChild("Shared")
local FruitsConfig = require(Shared:WaitForChild("FruitsConfig"))
local Remotes = require(Shared:WaitForChild("Remotes"))

local FruitController = {}
local started = false

local KEY_MAP = {
	[Enum.KeyCode.Z] = "Z",
	[Enum.KeyCode.X] = "X",
	[Enum.KeyCode.C] = "C",
	[Enum.KeyCode.V] = "V",
}

local SPECIAL_KEY_MAP = {
	[Enum.KeyCode.R] = "R", -- Partial Susanoo etc.; F = flight elsewhere
}

function FruitController.Start()
	if started then
		return
	end
	started = true

	local player = Players.LocalPlayer
	local localCd: { [string]: number } = {}

	local function resolveFruitId(): string?
		local current = player:GetAttribute("SF_CurrentFruit")
		if typeof(current) == "string" and current ~= "" then
			return current
		end
		local hat = player:GetAttribute("SF_HatDreckFruit")
		if hat == true then
			return "Dreck"
		end
		return nil
	end

	local function canLocalUse(): boolean
		local fruitId = resolveFruitId()
		if not fruitId then
			return false
		end
		return FruitsConfig.GetMoves(fruitId) ~= nil
	end

	local function tryMove(key: string)
		if not canLocalUse() then
			return
		end
		local fruitId = resolveFruitId()
		if not fruitId then
			return
		end
		local moves = FruitsConfig.GetMoves(fruitId)
		if not moves then
			return
		end
		local move = moves[key]
		if not move then
			return
		end
		local character = player.Character
		if not character then
			return
		end
		local humanoid = character:FindFirstChildOfClass("Humanoid")
		if not humanoid or humanoid.Health <= 0 then
			return
		end
		local now = os.clock()
		local cdKey = fruitId .. "_" .. key
		local last = localCd[cdKey] or 0
		if (now - last) < move.Cooldown * 0.85 then
			return
		end
		localCd[cdKey] = now
		Remotes.Event("FruitMove"):FireServer(key)
	end

	local function trySpecial(key: string)
		local fruitId = resolveFruitId()
		if not fruitId then
			return
		end
		if not FruitsConfig.HasSpecial(fruitId, key) then
			return
		end
		local specials = FruitsConfig.GetSpecial(fruitId)
		if not specials then
			return
		end
		local move = specials[key]
		if not move then
			return
		end
		local character = player.Character
		if not character then
			return
		end
		local humanoid = character:FindFirstChildOfClass("Humanoid")
		if not humanoid or humanoid.Health <= 0 then
			return
		end
		local now = os.clock()
		local cdKey = fruitId .. "_Special_" .. key
		local last = localCd[cdKey] or 0
		if (now - last) < move.Cooldown * 0.85 then
			return
		end
		localCd[cdKey] = now
		Remotes.Event("FruitSpecial"):FireServer(key)
	end

	UserInputService.InputBegan:Connect(function(input, gp)
		if gp then
			return
		end
		local key = KEY_MAP[input.KeyCode]
		if key then
			tryMove(key)
			return
		end
		local specialKey = SPECIAL_KEY_MAP[input.KeyCode]
		if specialKey then
			trySpecial(specialKey)
		end
	end)

	print("[SoulFruits.Client] FruitController Z/X/C/V + R Special ready (F = flight)")
end

return FruitController
