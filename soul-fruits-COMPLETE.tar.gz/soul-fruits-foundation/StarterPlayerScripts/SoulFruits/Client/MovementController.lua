--!strict
--[[
	MovementController – Client: Q Dash, F halten = Flug.
	Studio: StarterPlayerScripts/SoulFruits/Client/MovementController (ModuleScript)
]]

local Players = game:GetService("Players")
local UserInputService = game:GetService("UserInputService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Shared = ReplicatedStorage:WaitForChild("SoulFruits"):WaitForChild("Shared")
local Config = require(Shared:WaitForChild("Config"))
local Remotes = require(Shared:WaitForChild("Remotes"))

local MovementController = {}
local started = false

function MovementController.Start()
	if started then
		return
	end
	started = true

	local player = Players.LocalPlayer
	local lastLocalDash = 0
	local flyHeld = false

	local function tryDash()
		local now = os.clock()
		if (now - lastLocalDash) < Config.DASH_COOLDOWN * 0.9 then
			return
		end
		local character = player.Character
		if not character then
			return
		end
		local humanoid = character:FindFirstChildOfClass("Humanoid")
		if not humanoid or humanoid.Health <= 0 then
			return
		end
		lastLocalDash = now
		Remotes.Event("MovementDash"):FireServer()
	end

	local function setFly(holding: boolean)
		if flyHeld == holding then
			return
		end
		flyHeld = holding
		Remotes.Event("MovementFly"):FireServer(holding)
	end

	UserInputService.InputBegan:Connect(function(input, gp)
		if gp then
			return
		end
		if input.KeyCode == Enum.KeyCode.Q then
			tryDash()
		elseif input.KeyCode == Enum.KeyCode.F then
			setFly(true)
		end
	end)

	UserInputService.InputEnded:Connect(function(input, _gp)
		if input.KeyCode == Enum.KeyCode.F then
			setFly(false)
		end
	end)

	-- Auto release fly if energy hits 0 (server also stops)
	player:GetAttributeChangedSignal("Energy"):Connect(function()
		local energy = player:GetAttribute("Energy")
		if typeof(energy) == "number" and energy <= 0 and flyHeld then
			setFly(false)
		end
	end)

	player.CharacterAdded:Connect(function()
		flyHeld = false
	end)

	print("[SoulFruits.Client] MovementController ready (Q/F)")
end

return MovementController
