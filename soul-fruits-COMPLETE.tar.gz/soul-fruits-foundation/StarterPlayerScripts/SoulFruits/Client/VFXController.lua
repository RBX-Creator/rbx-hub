--!strict
--[[
	VFXController – dockt an VFX_Dash / VFX_Fly / VFX_Hit (+ Fruit stubs).
	Studio: StarterPlayerScripts/SoulFruits/Client/VFXController (ModuleScript)
	Startet aus ClientBootstrap: require(...).Start()

	Client-only Optik. Keine Damage-/Energy-Logik.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Shared = ReplicatedStorage:WaitForChild("SoulFruits"):WaitForChild("Shared")
local VFXConfig = require(Shared:WaitForChild("VFXConfig"))
local VFXTemplates = require(Shared:WaitForChild("VFXTemplates"))

local VFXController = {}
local started = false

type Rig = {
	hrp: BasePart,
	trail: Trail,
	dust: ParticleEmitter,
	auraBody: ParticleEmitter,
	auraFeet: ParticleEmitter,
	sparks: ParticleEmitter,
	hitDust: ParticleEmitter,
	earth: ParticleEmitter,
	chips: ParticleEmitter,
	connections: { RBXScriptConnection },
}

local rigs: { [Model]: Rig } = {}

local clearSusanoo: (Model) -> ()
local susanooParts: { [Model]: { Folder } } = {}

local function getHRP(character: Model): BasePart?
	local hrp = character:FindFirstChild("HumanoidRootPart")
	if hrp and hrp:IsA("BasePart") then
		return hrp
	end
	return nil
end

local function clearRig(character: Model)
	local rig = rigs[character]
	if not rig then
		return
	end
	for _, c in rig.connections do
		c:Disconnect()
	end
	rigs[character] = nil
	clearSusanoo(character)

	local hrp = getHRP(character)
	if hrp then
		for _, name in {
			"SF_VFX_Trail0",
			"SF_VFX_Trail1",
			"SF_VFX_Feet",
			"SF_VFX_Body",
			"SF_VFX_Hit",
			"SF_DashTrail",
		} do
			local inst = hrp:FindFirstChild(name)
			if inst then
				inst:Destroy()
			end
		end
	end
end

local function buildRig(character: Model): Rig?
	local hrp = getHRP(character)
	if not hrp then
		return nil
	end

	clearRig(character)

	local attTrail0 = VFXTemplates.EnsureAttachment(hrp, "SF_VFX_Trail0", Vector3.new(-0.35, 0, 0))
	local attTrail1 = VFXTemplates.EnsureAttachment(hrp, "SF_VFX_Trail1", Vector3.new(0.35, 0, 0))
	local attFeet = VFXTemplates.EnsureAttachment(hrp, "SF_VFX_Feet", Vector3.new(0, -2.4, 0))
	local attBody = VFXTemplates.EnsureAttachment(hrp, "SF_VFX_Body", Vector3.new(0, 0.2, 0))
	local attHit = VFXTemplates.EnsureAttachment(hrp, "SF_VFX_Hit", Vector3.new(0, 0.5, -1.5))

	local trail = VFXTemplates.MakeTrail(attTrail0, attTrail1, "SF_DashTrail")
	local dust = VFXTemplates.MakeDust(attFeet, "SF_DashDust")
	local auraBody = VFXTemplates.MakeAura(attBody, "SF_FlyAuraBody")
	local auraFeet = VFXTemplates.MakeAura(attFeet, "SF_FlyAuraFeet")
	auraFeet.Rate = math.max(4, math.floor(VFXConfig.Fly.Rate * 0.45))
	auraFeet.Size = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0.2),
		NumberSequenceKeypoint.new(1, 0.04),
	})

	local sparks = VFXTemplates.MakeSparks(attHit, "SF_HitSparks")
	local hitDust = VFXTemplates.MakeDust(attHit, "SF_HitDust")
	hitDust.Size = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0.4),
		NumberSequenceKeypoint.new(1, 1.1),
	})

	local earth = VFXTemplates.MakeEarthBurst(attFeet, "SF_FruitEarth")
	local chips = VFXTemplates.MakeStoneChips(attFeet, "SF_FruitChips")

	for _, name in { VFXConfig.ATTR.Dash, VFXConfig.ATTR.Fly, VFXConfig.ATTR.Hit } do
		if not character:FindFirstChild(name) then
			local be = Instance.new("BindableEvent")
			be.Name = name
			be.Parent = character
		end
	end

	local rig: Rig = {
		hrp = hrp,
		trail = trail,
		dust = dust,
		auraBody = auraBody,
		auraFeet = auraFeet,
		sparks = sparks,
		hitDust = hitDust,
		earth = earth,
		chips = chips,
		connections = {},
	}
	rigs[character] = rig
	return rig
end

local function playDash(rig: Rig)
	rig.trail.Enabled = true
	rig.dust:Emit(VFXConfig.Dash.DustBurst)
	task.delay(VFXConfig.Dash.TrailLifetime, function()
		if rig.trail.Parent then
			rig.trail.Enabled = false
		end
	end)
end

local function setFly(rig: Rig, on: boolean)
	rig.auraBody.Enabled = on
	rig.auraFeet.Enabled = on
	if on then
		rig.auraBody:Emit(4)
		rig.auraFeet:Emit(3)
	end
end

local function playHit(rig: Rig)
	local combo = rig.hrp.Parent and (rig.hrp.Parent :: Model):GetAttribute("SF_M1_Combo")
	local mult = 1
	if typeof(combo) == "number" and combo >= 4 then
		mult = VFXConfig.Hit.Combo4Mult or 1.45
	end
	rig.sparks.Speed = NumberRange.new(10, 22)
	rig.sparks.SpreadAngle = Vector2.new(70, 70)
	rig.sparks:Emit(math.floor(VFXConfig.Hit.Sparks * mult))
	rig.hitDust:Emit(math.floor(VFXConfig.Hit.Dust * mult))

	-- Hit-Confirm Flash (BF-lesbar, kurz)
	local hrp = rig.hrp
	local flash = Instance.new("Part")
	flash.Name = "SF_VFX_HitFlash"
	flash.Shape = Enum.PartType.Ball
	flash.Material = Enum.Material.Neon
	flash.Color = VFXConfig.Colors.ImpactFlash
	flash.Anchored = true
	flash.CanCollide = false
	flash.CanQuery = false
	flash.CanTouch = false
	flash.CastShadow = false
	local s = (VFXConfig.Hit.FlashSize or 1.1) * mult
	flash.Size = Vector3.new(s, s, s)
	flash.Transparency = 0.15
	flash.CFrame = hrp.CFrame * CFrame.new(0, 0.6, -2.2)
	flash.Parent = workspace
	local Debris = game:GetService("Debris")
	Debris:AddItem(flash, 0.28)
	task.spawn(function()
		local t0 = os.clock()
		while flash.Parent and (os.clock() - t0) < 0.25 do
			local a = (os.clock() - t0) / 0.25
			flash.Size = Vector3.new(s, s, s) * (1 + a * 1.6)
			flash.Transparency = 0.15 + a * 0.8
			task.wait(0.02)
		end
	end)
end

local function tintEmitters(rig: Rig, primary: Color3, secondary: Color3, accent: Color3)
	rig.earth.Color = ColorSequence.new({
		ColorSequenceKeypoint.new(0, primary),
		ColorSequenceKeypoint.new(1, secondary),
	})
	rig.chips.Color = ColorSequence.new(accent)
	rig.sparks.Color = ColorSequence.new({
		ColorSequenceKeypoint.new(0, accent),
		ColorSequenceKeypoint.new(1, primary),
	})
	rig.dust.Color = ColorSequence.new({
		ColorSequenceKeypoint.new(0, primary),
		ColorSequenceKeypoint.new(1, secondary),
	})
end

local function getCurrentFruit(character: Model): string
	local a = character:GetAttribute(VFXConfig.ATTR.CurrentFruit)
	if typeof(a) == "string" and a ~= "" then
		return a
	end
	local p = Players.LocalPlayer:GetAttribute(VFXConfig.ATTR.CurrentFruit)
	if typeof(p) == "string" and p ~= "" then
		return p
	end
	return "Dreck"
end

local function spawnCrackDecal(cf: CFrame, size: Vector3, life: number, color: Color3)
	local p = Instance.new("Part")
	p.Name = "SF_VFX_Crack"
	p.Anchored = true
	p.CanCollide = false
	p.CanQuery = false
	p.CanTouch = false
	p.CastShadow = false
	p.Material = Enum.Material.Slate
	p.Color = color
	p.Transparency = 0.35
	p.Size = size
	p.CFrame = cf
	p.Parent = workspace
	local Debris = game:GetService("Debris")
	Debris:AddItem(p, life)
	task.spawn(function()
		local t0 = os.clock()
		while p.Parent and (os.clock() - t0) < life do
			local a = (os.clock() - t0) / life
			p.Transparency = 0.35 + a * 0.65
			task.wait(0.05)
		end
	end)
end

local function spawnEyeRing(hrp: BasePart, color: Color3, life: number)
	local ring = Instance.new("Part")
	ring.Name = "SF_VFX_EyeRing"
	ring.Shape = Enum.PartType.Cylinder
	ring.Material = Enum.Material.Neon
	ring.Color = color
	ring.Anchored = true
	ring.CanCollide = false
	ring.CanQuery = false
	ring.CanTouch = false
	ring.CastShadow = false
	ring.Size = Vector3.new(0.2, 4, 4)
	ring.CFrame = hrp.CFrame * CFrame.new(0, 1.2, -3) * CFrame.Angles(0, 0, math.rad(90))
	ring.Transparency = 0.25
	ring.Parent = workspace
	local Debris = game:GetService("Debris")
	Debris:AddItem(ring, life)
	task.spawn(function()
		local t0 = os.clock()
		while ring.Parent and (os.clock() - t0) < life do
			local a = (os.clock() - t0) / life
			ring.Size = Vector3.new(0.2, 4 + a * 3, 4 + a * 3)
			ring.Transparency = 0.25 + a * 0.7
			task.wait(0.03)
		end
	end)
end

local function playFruit(rig: Rig, move: string)
	local hrp = rig.hrp
	local fruit = getCurrentFruit(hrp.Parent :: Model)
	local pal = VFXConfig.GetPalette(fruit)
	local mult = pal.intensity
	tintEmitters(rig, pal.primary, pal.secondary, pal.accent)

	local look = hrp.CFrame.LookVector
	local flat = Vector3.new(look.X, 0, look.Z)
	if flat.Magnitude < 0.05 then
		flat = Vector3.new(0, 0, -1)
	else
		flat = flat.Unit
	end

	local isBlood = fruit == "Blutaugespiegel" or fruit == "Sharingan"

	if isBlood then
		-- Legendary: Blutrot / Augen-Feel, stärker
		if move == "Z" then
			spawnEyeRing(hrp, pal.accent, 0.45)
			rig.sparks:Emit(math.floor(16 * mult))
			rig.earth:Emit(math.floor(10 * mult))
		elseif move == "X" then
			rig.sparks.Speed = NumberRange.new(16, 30)
			rig.sparks:Emit(math.floor(24 * mult))
			rig.chips:Emit(math.floor(12 * mult))
			rig.earth:Emit(math.floor(8 * mult))
		elseif move == "C" then
			spawnEyeRing(hrp, pal.primary, 0.7)
			rig.auraBody.Color = ColorSequence.new({
				ColorSequenceKeypoint.new(0, pal.accent),
				ColorSequenceKeypoint.new(1, pal.primary),
			})
			rig.auraBody:Emit(10)
			rig.sparks:Emit(math.floor(14 * mult))
			rig.dust:Emit(math.floor(8 * mult))
		else
			-- V Blutspiegel-Welt
			spawnEyeRing(hrp, pal.accent, 1.1)
			rig.earth.Speed = NumberRange.new(6, 14)
			rig.earth.SpreadAngle = Vector2.new(80, 80)
			rig.earth:Emit(math.floor(48 * mult))
			rig.sparks:Emit(math.floor(24 * mult))
			rig.chips:Emit(math.floor(20 * mult))
			local base = hrp.Position + Vector3.new(0, -2.2, 0)
			spawnCrackDecal(CFrame.new(base), Vector3.new(14, 0.25, 14), 1.4, pal.secondary)
		end
		return
	end

	-- Element-Fruits (Dreck / Wind / Flame / Ice / Light / Magma)
	if move == "Z" then
		rig.earth.Speed = NumberRange.new(6, 12)
		rig.earth.SpreadAngle = Vector2.new(25, 25)
		rig.earth:Emit(math.floor(18 * mult))
		rig.chips:Emit(math.floor(8 * mult))
		rig.dust:Emit(math.floor(6 * mult))
		if fruit == "Flame" or fruit == "Light" or fruit == "Magma" then
			rig.sparks:Emit(math.floor(8 * mult))
		end
	elseif move == "X" then
		rig.chips.Speed = NumberRange.new(14, 28)
		rig.chips.SpreadAngle = Vector2.new(20, 20)
		rig.chips:Emit(math.floor(16 * mult))
		rig.earth:Emit(math.floor(10 * mult))
		rig.sparks:Emit(math.floor(6 * mult))
	elseif move == "C" then
		rig.earth.Speed = NumberRange.new(8, 16)
		rig.earth.SpreadAngle = Vector2.new(70, 40)
		rig.earth:Emit(math.floor(34 * mult))
		rig.chips:Emit(math.floor(14 * mult))
		rig.dust:Emit(math.floor(12 * mult))
		local origin = hrp.Position + flat * 4 + Vector3.new(0, -2.5, 0)
		spawnCrackDecal(
			CFrame.lookAt(origin, origin + flat) * CFrame.Angles(0, 0, math.rad(90)),
			Vector3.new(0.3, 10, 4),
			0.7,
			pal.secondary
		)
	else
		rig.earth.Speed = NumberRange.new(4, 10)
		rig.earth.SpreadAngle = Vector2.new(35, 80)
		rig.earth:Emit(math.floor(42 * mult))
		rig.chips:Emit(math.floor(22 * mult))
		rig.dust:Emit(math.floor(16 * mult))
		if fruit == "Flame" or fruit == "Magma" or fruit == "Light" then
			rig.sparks:Emit(math.floor(16 * mult))
		end
		local base = hrp.Position + flat * 6 + Vector3.new(0, -2.2, 0)
		spawnCrackDecal(
			CFrame.new(base) * CFrame.Angles(0, math.atan2(-flat.X, -flat.Z), 0),
			Vector3.new(8, 0.25, 3),
			1.2,
			pal.secondary
		)
	end
end


function clearSusanoo(character: Model)
	local entry = susanooParts[character]
	if entry then
		for _, f in entry do
			if f.Parent then
				f:Destroy()
			end
		end
		susanooParts[character] = nil
	end
end

local function playSusanoo(rig: Rig, character: Model)
	clearSusanoo(character)
	local hrp = rig.hrp
	local pal = VFXConfig.GetPalette("Sharingan")
	local folder = Instance.new("Folder")
	folder.Name = "SF_VFX_Susanoo"
	folder.Parent = character

	-- Ribcage / armor silhouette (simple neon parts)
	local function bone(size: Vector3, offset: CFrame, transparency: number)
		local p = Instance.new("Part")
		p.Name = "SF_SusanooBone"
		p.Anchored = false
		p.CanCollide = false
		p.CanQuery = false
		p.CanTouch = false
		p.CastShadow = false
		p.Material = Enum.Material.Neon
		p.Color = pal.primary
		p.Transparency = transparency
		p.Size = size
		p.Massless = true
		p.CFrame = hrp.CFrame * offset
		p.Parent = folder
		local w = Instance.new("WeldConstraint")
		w.Part0 = hrp
		w.Part1 = p
		w.Parent = p
		-- lock relative pose
		p.CFrame = hrp.CFrame * offset
		return p
	end

	-- Approximate torso cage
	bone(Vector3.new(3.6, 0.35, 2.4), CFrame.new(0, 1.7, 0), 0.22)
	bone(Vector3.new(0.45, 2.8, 2.2), CFrame.new(-1.65, 0.55, 0), 0.3)
	bone(Vector3.new(0.45, 2.8, 2.2), CFrame.new(1.65, 0.55, 0), 0.3)
	bone(Vector3.new(3.6, 2.6, 0.35), CFrame.new(0, 0.55, -1.25), 0.35)
	bone(Vector3.new(3.6, 2.6, 0.35), CFrame.new(0, 0.55, 1.15), 0.55)
	-- shoulder plates
	bone(Vector3.new(1.5, 0.45, 1.2), CFrame.new(-2.0, 1.55, 0), 0.28)
	bone(Vector3.new(1.5, 0.45, 1.2), CFrame.new(2.0, 1.55, 0), 0.28)
	-- helm hint
	bone(Vector3.new(1.4, 1.0, 1.4), CFrame.new(0, 2.5, 0), 0.4)

	-- Aura particles on body
	rig.auraBody.Color = ColorSequence.new({
		ColorSequenceKeypoint.new(0, pal.accent),
		ColorSequenceKeypoint.new(1, pal.primary),
	})
	rig.auraBody.Enabled = true
	rig.auraBody:Emit(16)
	rig.sparks.Color = ColorSequence.new(pal.accent)
	rig.sparks:Emit(20)
	spawnEyeRing(hrp, pal.accent, 0.6)

	susanooParts[character] = { folder }

	-- Auto-clear when SF_SusanooUntil expires (player or character)
	local fallbackEnd = tick() + 2.6
	task.spawn(function()
		while character.Parent and folder.Parent do
			task.wait(0.15)
			local untilT = character:GetAttribute("SF_SusanooUntil")
			if typeof(untilT) ~= "number" then
				untilT = Players.LocalPlayer:GetAttribute("SF_SusanooUntil")
			end
			if typeof(untilT) == "number" then
				if untilT <= tick() then
					break
				end
			elseif tick() >= fallbackEnd then
				break
			end
		end
		if folder.Parent then
			folder:Destroy()
		end
		rig.auraBody.Enabled = false
		clearSusanoo(character)
	end)
end



local function playFruitSpin(rig: Rig, fruitId: string?)
	local pal = VFXConfig.GetPalette(if typeof(fruitId) == "string" then fruitId else nil)
	tintEmitters(rig, pal.primary, pal.secondary, pal.accent)
	rig.sparks.Color = ColorSequence.new({
		ColorSequenceKeypoint.new(0, pal.accent),
		ColorSequenceKeypoint.new(1, pal.primary),
	})
	rig.sparks.Speed = NumberRange.new(2, 6)
	rig.sparks.SpreadAngle = Vector2.new(180, 180)
	rig.sparks:Emit(math.floor(22 * pal.intensity))
	rig.auraBody.Color = ColorSequence.new({
		ColorSequenceKeypoint.new(0, pal.accent),
		ColorSequenceKeypoint.new(1, pal.primary),
	})
	rig.auraBody:Emit(math.floor(10 * pal.intensity))
	-- soft orbit glow part
	local hrp = rig.hrp
	local glow = Instance.new("Part")
	glow.Name = "SF_VFX_SpinGlow"
	glow.Shape = Enum.PartType.Ball
	glow.Material = Enum.Material.Neon
	glow.Color = pal.accent
	glow.Size = Vector3.new(1.4, 1.4, 1.4)
	glow.Transparency = 0.35
	glow.Anchored = true
	glow.CanCollide = false
	glow.CanQuery = false
	glow.CanTouch = false
	glow.CastShadow = false
	glow.CFrame = hrp.CFrame * CFrame.new(0, 2.2, 0)
	glow.Parent = workspace
	local Debris = game:GetService("Debris")
	Debris:AddItem(glow, 1.1)
	task.spawn(function()
		local t0 = os.clock()
		while glow.Parent and (os.clock() - t0) < 1.0 do
			local a = (os.clock() - t0)
			glow.CFrame = hrp.CFrame * CFrame.new(math.sin(a * 8) * 1.2, 2.2, math.cos(a * 8) * 1.2)
			glow.Transparency = 0.35 + a * 0.5
			glow.Size = Vector3.new(1.4, 1.4, 1.4) * (1 + a * 0.4)
			task.wait(0.03)
		end
	end)
end

local function playFruitEat(rig: Rig, fruitId: string?)
	local pal = VFXConfig.GetPalette(if typeof(fruitId) == "string" then fruitId else nil)
	tintEmitters(rig, pal.primary, pal.secondary, pal.accent)
	rig.earth.Speed = NumberRange.new(4, 10)
	rig.earth.SpreadAngle = Vector2.new(50, 50)
	rig.earth:Emit(math.floor(18 * pal.intensity))
	rig.sparks:Emit(math.floor(14 * pal.intensity))
	rig.chips:Emit(math.floor(8 * pal.intensity))
	rig.dust:Emit(math.floor(6 * pal.intensity))
	-- bite flash in front of face
	local hrp = rig.hrp
	local flash = Instance.new("Part")
	flash.Name = "SF_VFX_EatFlash"
	flash.Shape = Enum.PartType.Ball
	flash.Material = Enum.Material.Neon
	flash.Color = pal.accent
	flash.Size = Vector3.new(0.8, 0.8, 0.8)
	flash.Transparency = 0.2
	flash.Anchored = true
	flash.CanCollide = false
	flash.CanQuery = false
	flash.CanTouch = false
	flash.CastShadow = false
	flash.CFrame = hrp.CFrame * CFrame.new(0, 1.4, -1.2)
	flash.Parent = workspace
	local Debris = game:GetService("Debris")
	Debris:AddItem(flash, 0.45)
	task.spawn(function()
		local t0 = os.clock()
		while flash.Parent and (os.clock() - t0) < 0.4 do
			local a = (os.clock() - t0) / 0.4
			flash.Size = Vector3.new(0.8, 0.8, 0.8) * (1 + a * 1.8)
			flash.Transparency = 0.2 + a * 0.75
			task.wait(0.03)
		end
	end)
end


local function hookCharacter(character: Model)
	local rig = buildRig(character)
	if not rig then
		return
	end

	local player = Players.LocalPlayer

	local function onDash()
		if character:GetAttribute(VFXConfig.ATTR.Dash) ~= nil then
			playDash(rig)
		end
	end

	local function onFlyAttr()
		local flying = character:GetAttribute(VFXConfig.ATTR.Fly) == true
			or player:GetAttribute(VFXConfig.ATTR.Flying) == true
		setFly(rig, flying)
	end

	local function onHit()
		if character:GetAttribute(VFXConfig.ATTR.Hit) ~= nil then
			playHit(rig)
		end
	end

	table.insert(rig.connections, character:GetAttributeChangedSignal(VFXConfig.ATTR.Dash):Connect(onDash))
	table.insert(rig.connections, character:GetAttributeChangedSignal(VFXConfig.ATTR.Fly):Connect(onFlyAttr))
	table.insert(rig.connections, character:GetAttributeChangedSignal(VFXConfig.ATTR.Hit):Connect(onHit))
	table.insert(rig.connections, player:GetAttributeChangedSignal(VFXConfig.ATTR.Flying):Connect(onFlyAttr))

	for move, attr in {
		Z = VFXConfig.ATTR.FruitZ,
		X = VFXConfig.ATTR.FruitX,
		C = VFXConfig.ATTR.FruitC,
		V = VFXConfig.ATTR.FruitV,
	} do
		table.insert(
			rig.connections,
			character:GetAttributeChangedSignal(attr):Connect(function()
				if character:GetAttribute(attr) ~= nil then
					playFruit(rig, move)
				end
			end)
		)
	end

	

	-- BF physical fruit: Gacha spin + Eat burst
	local function fruitIdFrom(attrFruit: string): string?
		local id = character:GetAttribute(attrFruit)
		if typeof(id) ~= "string" or id == "" then
			id = player:GetAttribute(attrFruit)
		end
		if typeof(id) == "string" and id ~= "" then
			return id
		end
		return nil
	end

	table.insert(
		rig.connections,
		character:GetAttributeChangedSignal(VFXConfig.ATTR.FruitSpin):Connect(function()
			local v = character:GetAttribute(VFXConfig.ATTR.FruitSpin)
			if v ~= nil and v ~= false then
				playFruitSpin(rig, fruitIdFrom("SF_SpinFruitId"))
			end
		end)
	)
	table.insert(
		rig.connections,
		player:GetAttributeChangedSignal(VFXConfig.ATTR.FruitSpin):Connect(function()
			local v = player:GetAttribute(VFXConfig.ATTR.FruitSpin)
			if v ~= nil and v ~= false then
				playFruitSpin(rig, fruitIdFrom("SF_SpinFruitId"))
			end
		end)
	)
	table.insert(
		rig.connections,
		character:GetAttributeChangedSignal(VFXConfig.ATTR.FruitEat):Connect(function()
			local v = character:GetAttribute(VFXConfig.ATTR.FruitEat)
			if v ~= nil and v ~= false then
				local id = character:GetAttribute("SF_EatFruitId")
				if typeof(id) ~= "string" then
					id = player:GetAttribute("SF_EatFruitId")
				end
				playFruitEat(rig, if typeof(id) == "string" then id else nil)
			end
		end)
	)
	table.insert(
		rig.connections,
		player:GetAttributeChangedSignal(VFXConfig.ATTR.FruitEat):Connect(function()
			local v = player:GetAttribute(VFXConfig.ATTR.FruitEat)
			if v ~= nil and v ~= false then
				local id = player:GetAttribute("SF_EatFruitId")
				playFruitEat(rig, if typeof(id) == "string" then id else nil)
			end
		end)
	)

	-- Partial Susanoo (R)
	table.insert(
		rig.connections,
		character:GetAttributeChangedSignal(VFXConfig.ATTR.Susanoo):Connect(function()
			local v = character:GetAttribute(VFXConfig.ATTR.Susanoo)
			if v ~= nil and v ~= false then
				playSusanoo(rig, character)
			end
		end)
	)

	table.insert(
		rig.connections,
		character:GetAttributeChangedSignal("SF_SusanooUntil"):Connect(function()
			local untilT = character:GetAttribute("SF_SusanooUntil")
			if typeof(untilT) ~= "number" or untilT <= tick() then
				clearSusanoo(character)
				rig.auraBody.Enabled = false
			end
		end)
	)

for _, name in { VFXConfig.ATTR.Dash, VFXConfig.ATTR.Hit } do
		local be = character:FindFirstChild(name)
		if be and be:IsA("BindableEvent") then
			table.insert(
				rig.connections,
				be.Event:Connect(function()
					if name == VFXConfig.ATTR.Dash then
						playDash(rig)
					else
						playHit(rig)
					end
				end)
			)
		end
	end

	local flyBe = character:FindFirstChild(VFXConfig.ATTR.Fly)
	if flyBe and flyBe:IsA("BindableEvent") then
		table.insert(
			rig.connections,
			flyBe.Event:Connect(function(on: any)
				setFly(rig, on == true)
			end)
		)
	end

	onFlyAttr()

	local humanoid = character:FindFirstChildOfClass("Humanoid")
	if humanoid then
		table.insert(
			rig.connections,
			humanoid.Died:Connect(function()
				setFly(rig, false)
				clearRig(character)
			end)
		)
	end
end

function VFXController.Start()
	if started then
		return
	end
	started = true

	local player = Players.LocalPlayer

	local function onCharacter(character: Model)
		task.defer(function()
			if character.Parent then
				hookCharacter(character)
			end
		end)
	end

	if player.Character then
		onCharacter(player.Character)
	end
	player.CharacterAdded:Connect(onCharacter)
	player.CharacterRemoving:Connect(function(character)
		clearRig(character)
	end)

	print("[SoulFruits.VFX] Attack-Polish ready (Hit-Confirm + Casts + Susanoo)")
end

return VFXController
