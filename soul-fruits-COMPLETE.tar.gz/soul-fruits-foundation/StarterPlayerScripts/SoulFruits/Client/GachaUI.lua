--!strict
--[[
	GachaUI – Minimal dark BF-ish Stock panel + Gacha button (key G / HUD button).
	Studio: StarterPlayerScripts/SoulFruits/Client/GachaUI (ModuleScript)
]]

local Players = game:GetService("Players")
local UserInputService = game:GetService("UserInputService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Shared = ReplicatedStorage:WaitForChild("SoulFruits"):WaitForChild("Shared")
local FruitsConfig = require(Shared:WaitForChild("FruitsConfig"))
local Remotes = require(Shared:WaitForChild("Remotes"))

local GachaUI = {}
local started = false

local COLORS = {
	bg = Color3.fromRGB(14, 14, 18),
	panel = Color3.fromRGB(24, 24, 32),
	slot = Color3.fromRGB(34, 34, 44),
	text = Color3.fromRGB(235, 235, 240),
	muted = Color3.fromRGB(150, 150, 160),
	accent = Color3.fromRGB(90, 100, 220),
	buy = Color3.fromRGB(55, 130, 90),
	gacha = Color3.fromRGB(160, 90, 40),
	sold = Color3.fromRGB(70, 40, 40),
}

local function corner(parent: Instance, radius: number)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, radius)
	c.Parent = parent
end

local function pad(parent: Instance, px: number)
	local p = Instance.new("UIPadding")
	p.PaddingLeft = UDim.new(0, px)
	p.PaddingRight = UDim.new(0, px)
	p.PaddingTop = UDim.new(0, px)
	p.PaddingBottom = UDim.new(0, px)
	p.Parent = parent
end

function GachaUI.Start()
	if started then
		return
	end
	started = true

	local player = Players.LocalPlayer
	local playerGui = player:WaitForChild("PlayerGui")

	local existing = playerGui:FindFirstChild("SF_GachaUI")
	if existing then
		existing:Destroy()
	end

	local gui = Instance.new("ScreenGui")
	gui.Name = "SF_GachaUI"
	gui.ResetOnSpawn = false
	gui.IgnoreGuiInset = true
	gui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	gui.Parent = playerGui

	-- Toggle button (bottom-right-ish, above hotbar area)
	local openBtn = Instance.new("TextButton")
	openBtn.Name = "OpenStock"
	openBtn.AnchorPoint = Vector2.new(1, 1)
	openBtn.Position = UDim2.new(1, -16, 1, -120)
	openBtn.Size = UDim2.fromOffset(110, 36)
	openBtn.BackgroundColor3 = COLORS.accent
	openBtn.TextColor3 = COLORS.text
	openBtn.Font = Enum.Font.GothamBold
	openBtn.TextSize = 14
	openBtn.Text = "Stock [G]"
	openBtn.Parent = gui
	corner(openBtn, 8)

	local panel = Instance.new("Frame")
	panel.Name = "Panel"
	panel.AnchorPoint = Vector2.new(0.5, 0.5)
	panel.Position = UDim2.fromScale(0.5, 0.48)
	panel.Size = UDim2.fromOffset(520, 340)
	panel.BackgroundColor3 = COLORS.bg
	panel.Visible = false
	panel.Parent = gui
	corner(panel, 12)
	pad(panel, 14)

	local stroke = Instance.new("UIStroke")
	stroke.Color = Color3.fromRGB(60, 60, 80)
	stroke.Thickness = 1
	stroke.Parent = panel

	local title = Instance.new("TextLabel")
	title.Size = UDim2.new(1, -40, 0, 28)
	title.BackgroundTransparency = 1
	title.Text = "Fruit Stock"
	title.Font = Enum.Font.GothamBold
	title.TextSize = 20
	title.TextColor3 = COLORS.text
	title.TextXAlignment = Enum.TextXAlignment.Left
	title.Parent = panel

	local closeBtn = Instance.new("TextButton")
	closeBtn.Size = UDim2.fromOffset(28, 28)
	closeBtn.Position = UDim2.new(1, -28, 0, 0)
	closeBtn.BackgroundColor3 = COLORS.slot
	closeBtn.Text = "X"
	closeBtn.TextColor3 = COLORS.text
	closeBtn.Font = Enum.Font.GothamBold
	closeBtn.Parent = panel
	corner(closeBtn, 6)

	local timerLabel = Instance.new("TextLabel")
	timerLabel.Name = "Timer"
	timerLabel.Size = UDim2.new(1, 0, 0, 20)
	timerLabel.Position = UDim2.fromOffset(0, 32)
	timerLabel.BackgroundTransparency = 1
	timerLabel.Text = "Refresh: --"
	timerLabel.Font = Enum.Font.Gotham
	timerLabel.TextSize = 13
	timerLabel.TextColor3 = COLORS.muted
	timerLabel.TextXAlignment = Enum.TextXAlignment.Left
	timerLabel.Parent = panel

	local currencyLabel = Instance.new("TextLabel")
	currencyLabel.Name = "Currency"
	currencyLabel.Size = UDim2.new(1, 0, 0, 20)
	currencyLabel.Position = UDim2.fromOffset(0, 52)
	currencyLabel.BackgroundTransparency = 1
	currencyLabel.Text = "Coins: 0  |  Splitz: 0  |  DiceParts: 0"
	currencyLabel.Font = Enum.Font.Gotham
	currencyLabel.TextSize = 13
	currencyLabel.TextColor3 = COLORS.text
	currencyLabel.TextXAlignment = Enum.TextXAlignment.Left
	currencyLabel.Parent = panel

	local slotsRow = Instance.new("Frame")
	slotsRow.Name = "Slots"
	slotsRow.Position = UDim2.fromOffset(0, 84)
	slotsRow.Size = UDim2.new(1, 0, 0, 160)
	slotsRow.BackgroundTransparency = 1
	slotsRow.Parent = panel

	local layout = Instance.new("UIListLayout")
	layout.FillDirection = Enum.FillDirection.Horizontal
	layout.Padding = UDim.new(0, 10)
	layout.HorizontalAlignment = Enum.HorizontalAlignment.Center
	layout.Parent = slotsRow

	local slotFrames: { Frame } = {}
	for i = 1, FruitsConfig.STOCK_SIZE do
		local slot = Instance.new("Frame")
		slot.Name = "Slot" .. i
		slot.Size = UDim2.fromOffset(150, 150)
		slot.BackgroundColor3 = COLORS.slot
		slot.Parent = slotsRow
		corner(slot, 10)

		local nameLabel = Instance.new("TextLabel")
		nameLabel.Name = "FruitName"
		nameLabel.Size = UDim2.new(1, -8, 0, 28)
		nameLabel.Position = UDim2.fromOffset(4, 10)
		nameLabel.BackgroundTransparency = 1
		nameLabel.Text = "—"
		nameLabel.Font = Enum.Font.GothamBold
		nameLabel.TextSize = 16
		nameLabel.TextColor3 = COLORS.text
		nameLabel.Parent = slot

		local rarityLabel = Instance.new("TextLabel")
		rarityLabel.Name = "Rarity"
		rarityLabel.Size = UDim2.new(1, -8, 0, 20)
		rarityLabel.Position = UDim2.fromOffset(4, 40)
		rarityLabel.BackgroundTransparency = 1
		rarityLabel.Text = ""
		rarityLabel.Font = Enum.Font.Gotham
		rarityLabel.TextSize = 13
		rarityLabel.TextColor3 = COLORS.muted
		rarityLabel.Parent = slot

		local elemLabel = Instance.new("TextLabel")
		elemLabel.Name = "Element"
		elemLabel.Size = UDim2.new(1, -8, 0, 18)
		elemLabel.Position = UDim2.fromOffset(4, 62)
		elemLabel.BackgroundTransparency = 1
		elemLabel.Text = ""
		elemLabel.Font = Enum.Font.Gotham
		elemLabel.TextSize = 12
		elemLabel.TextColor3 = COLORS.muted
		elemLabel.Parent = slot

		local buy = Instance.new("TextButton")
		buy.Name = "Buy"
		buy.Size = UDim2.new(1, -16, 0, 32)
		buy.Position = UDim2.new(0, 8, 1, -40)
		buy.BackgroundColor3 = COLORS.buy
		buy.Text = "Buy"
		buy.TextColor3 = COLORS.text
		buy.Font = Enum.Font.GothamBold
		buy.TextSize = 14
		buy.Parent = slot
		corner(buy, 6)

		local slotIndex = i
		buy.MouseButton1Click:Connect(function()
			Remotes.Event("StockBuy"):FireServer(slotIndex)
		end)

		table.insert(slotFrames, slot)
	end

	local gachaBtn = Instance.new("TextButton")
	gachaBtn.Name = "GachaRoll"
	gachaBtn.Size = UDim2.new(1, 0, 0, 44)
	gachaBtn.Position = UDim2.new(0, 0, 1, -44)
	gachaBtn.BackgroundColor3 = COLORS.gacha
	gachaBtn.Text = ("Gacha Roll (−%d Splitz)"):format(FruitsConfig.GACHA_COST_SPLITZ)
	gachaBtn.TextColor3 = COLORS.text
	gachaBtn.Font = Enum.Font.GothamBold
	gachaBtn.TextSize = 16
	gachaBtn.Parent = panel
	corner(gachaBtn, 8)

	local resultLabel = Instance.new("TextLabel")
	resultLabel.Name = "LastResult"
	resultLabel.Size = UDim2.new(1, 0, 0, 22)
	resultLabel.Position = UDim2.new(0, 0, 1, -72)
	resultLabel.BackgroundTransparency = 1
	resultLabel.Text = ""
	resultLabel.Font = Enum.Font.Gotham
	resultLabel.TextSize = 14
	resultLabel.TextColor3 = COLORS.accent
	resultLabel.Parent = panel

	local lastSnap: any = nil

	local function formatTime(sec: number): string
		sec = math.max(0, math.floor(sec))
		local h = math.floor(sec / 3600)
		local m = math.floor((sec % 3600) / 60)
		local s = sec % 60
		return string.format("%02d:%02d:%02d", h, m, s)
	end

	local function refreshCurrency()
		local coins = player:GetAttribute("SF_Coins") or 0
		local splitz = player:GetAttribute("SF_Splitz") or 0
		local dice = player:GetAttribute("SF_DiceParts") or 0
		currencyLabel.Text = ("Coins: %s  |  Splitz: %s  |  DiceParts: %s"):format(
			tostring(coins),
			tostring(splitz),
			tostring(dice)
		)
	end

	local function applyStock(snap: any)
		lastSnap = snap
		if typeof(snap) ~= "table" or typeof(snap.Slots) ~= "table" then
			return
		end
		for i, slotFrame in slotFrames do
			local slotData = snap.Slots[i]
			local nameLabel = slotFrame:FindFirstChild("FruitName") :: TextLabel
			local rarityLabel = slotFrame:FindFirstChild("Rarity") :: TextLabel
			local elemLabel = slotFrame:FindFirstChild("Element") :: TextLabel
			local buy = slotFrame:FindFirstChild("Buy") :: TextButton
			if not slotData then
				nameLabel.Text = "—"
				continue
			end
			local def = FruitsConfig.Fruits[slotData.FruitId]
			nameLabel.Text = if def then def.DisplayName else tostring(slotData.FruitId)
			local rarity = if def then def.Rarity else "?"
			rarityLabel.Text = rarity
			rarityLabel.TextColor3 = FruitsConfig.RarityColors[rarity] or COLORS.muted
			elemLabel.Text = if def then def.Element else ""
			if slotData.SoldOut then
				buy.Text = "Sold Out"
				buy.BackgroundColor3 = COLORS.sold
				buy.Active = false
			else
				buy.Text = ("%d Coins"):format(slotData.PriceCoins or 0)
				buy.BackgroundColor3 = COLORS.buy
				buy.Active = true
			end
		end
		local remain = (snap.WindowEnd or 0) - (snap.ServerTime or os.time())
		timerLabel.Text = "Nächster Refresh in " .. formatTime(remain)
	end

	local function setOpen(open: boolean)
		panel.Visible = open
		if open then
			refreshCurrency()
		end
	end

	openBtn.MouseButton1Click:Connect(function()
		setOpen(not panel.Visible)
	end)
	closeBtn.MouseButton1Click:Connect(function()
		setOpen(false)
	end)
	gachaBtn.MouseButton1Click:Connect(function()
		Remotes.Event("GachaRoll"):FireServer()
	end)

	UserInputService.InputBegan:Connect(function(input, gp)
		if gp then
			return
		end
		if input.KeyCode == Enum.KeyCode.G then
			setOpen(not panel.Visible)
		end
	end)

	Remotes.Event("StockUpdated").OnClientEvent:Connect(function(snap)
		applyStock(snap)
	end)

	Remotes.Event("GachaResult").OnClientEvent:Connect(function(fruitId, rarity)
		resultLabel.Text = ("Gezogen: %s (%s)"):format(tostring(fruitId), tostring(rarity))
		refreshCurrency()
	end)

	Remotes.Event("DataUpdated").OnClientEvent:Connect(function(data)
		if typeof(data) == "table" then
			player:SetAttribute("SF_Coins", data.Coins)
			player:SetAttribute("SF_Splitz", data.Splitz)
			player:SetAttribute("SF_DiceParts", data.DiceParts or 0)
			player:SetAttribute("SF_CurrentFruit", data.CurrentFruit)
			player:SetAttribute("SF_HatDreckFruit", data.HatDreckFruit == true)
			player:SetAttribute("SF_DreckMastery", data.DreckMastery or 0)
			player:SetAttribute("SF_BlutaugespiegelMastery", data.BlutaugespiegelMastery or 0)
			local fm = data.FruitMastery or {}
			player:SetAttribute("SF_SharinganMastery", fm.Sharingan or 0)
			player:SetAttribute("SF_SharinganAwakened", data.SharinganAwakened == true)
		end
		refreshCurrency()
	end)

	-- Local countdown tick
	task.spawn(function()
		while gui.Parent do
			task.wait(1)
			if lastSnap and typeof(lastSnap.WindowEnd) == "number" then
				-- Approximate with client clock delta from last ServerTime
				local elapsed = os.time() - (lastSnap._clientRecv or os.time())
				-- Better: use WindowEnd - now assuming clocks close enough for stub
				local remain = lastSnap.WindowEnd - os.time()
				timerLabel.Text = "Nächster Refresh in " .. formatTime(remain)
			end
			refreshCurrency()
		end
	end)

	refreshCurrency()
	print("[SoulFruits.Client] GachaUI Stock/Gacha ready (key G)")
end

return GachaUI
