--!strict
--[[
	HUD – BF-like stub: HP/Energy over hotbar, Level bottom-left, Stats allocate.
	Studio: StarterPlayer > StarterPlayerScripts > SoulFruits > Client > HUD (ModuleScript)
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Shared = ReplicatedStorage:WaitForChild("SoulFruits"):WaitForChild("Shared")
local Config = require(Shared:WaitForChild("Config"))
local Remotes = require(Shared:WaitForChild("Remotes"))

local HUD = {}
local started = false

local COLORS = {
	bg = Color3.fromRGB(18, 18, 24),
	panel = Color3.fromRGB(28, 28, 36),
	hp = Color3.fromRGB(200, 55, 55),
	hpBg = Color3.fromRGB(50, 20, 20),
	energy = Color3.fromRGB(70, 140, 255),
	energyBg = Color3.fromRGB(20, 30, 55),
	text = Color3.fromRGB(235, 235, 240),
	muted = Color3.fromRGB(160, 160, 170),
	accent = Color3.fromRGB(90, 100, 220),
	btn = Color3.fromRGB(45, 45, 58),
}

local function corner(parent: Instance, radius: number)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, radius)
	c.Parent = parent
end

local function pad(parent: Instance, px: number)
	local p = Instance.new("UIPadding")
	p.PaddingLeft = UDim.new(0, px)
	p.PaddingRight = UDim.new(0, px)
	p.PaddingTop = UDim.new(0, px)
	p.PaddingBottom = UDim.new(0, px)
	p.Parent = parent
end

function HUD.Start()
	if started then
		return
	end
	started = true

	local player = Players.LocalPlayer
	local playerGui = player:WaitForChild("PlayerGui")

	local existing = playerGui:FindFirstChild("SF_HUD")
	if existing then
		existing:Destroy()
	end

	local gui = Instance.new("ScreenGui")
	gui.Name = "SF_HUD"
	gui.ResetOnSpawn = false
	gui.IgnoreGuiInset = true
	gui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	gui.Parent = playerGui

	-- Level (bottom left)
	local levelLabel = Instance.new("TextLabel")
	levelLabel.Name = "LevelLabel"
	levelLabel.AnchorPoint = Vector2.new(0, 1)
	levelLabel.Position = UDim2.new(0, 16, 1, -16)
	levelLabel.Size = UDim2.fromOffset(160, 28)
	levelLabel.BackgroundColor3 = COLORS.panel
	levelLabel.BackgroundTransparency = 0.15
	levelLabel.TextColor3 = COLORS.text
	levelLabel.Font = Enum.Font.GothamBold
	levelLabel.TextSize = 16
	levelLabel.TextXAlignment = Enum.TextXAlignment.Left
	levelLabel.Text = "Lv. 1"
	levelLabel.Parent = gui
	corner(levelLabel, 6)
	pad(levelLabel, 8)

	-- Stats button (above level)
	local statsBtn = Instance.new("TextButton")
	statsBtn.Name = "StatsButton"
	statsBtn.AnchorPoint = Vector2.new(0, 1)
	statsBtn.Position = UDim2.new(0, 16, 1, -52)
	statsBtn.Size = UDim2.fromOffset(100, 30)
	statsBtn.BackgroundColor3 = COLORS.accent
	statsBtn.TextColor3 = COLORS.text
	statsBtn.Font = Enum.Font.GothamMedium
	statsBtn.TextSize = 14
	statsBtn.Text = "Stats"
	statsBtn.AutoButtonColor = true
	statsBtn.Parent = gui
	corner(statsBtn, 6)

	-- Bars container (bottom center, above hotbar area)
	local bars = Instance.new("Frame")
	bars.Name = "Bars"
	bars.AnchorPoint = Vector2.new(0.5, 1)
	bars.Position = UDim2.new(0.5, 0, 1, -72)
	bars.Size = UDim2.fromOffset(320, 44)
	bars.BackgroundTransparency = 1
	bars.Parent = gui

	local function makeBar(name: string, y: number, fillColor: Color3, bgColor: Color3): (Frame, TextLabel)
		local row = Instance.new("Frame")
		row.Name = name
		row.Position = UDim2.fromOffset(0, y)
		row.Size = UDim2.new(1, 0, 0, 18)
		row.BackgroundColor3 = bgColor
		row.BorderSizePixel = 0
		row.Parent = bars
		corner(row, 4)

		local fill = Instance.new("Frame")
		fill.Name = "Fill"
		fill.Size = UDim2.fromScale(1, 1)
		fill.BackgroundColor3 = fillColor
		fill.BorderSizePixel = 0
		fill.Parent = row
		corner(fill, 4)

		local label = Instance.new("TextLabel")
		label.Name = "Value"
		label.Size = UDim2.fromScale(1, 1)
		label.BackgroundTransparency = 1
		label.TextColor3 = COLORS.text
		label.Font = Enum.Font.GothamMedium
		label.TextSize = 12
		label.ZIndex = 2
		label.Text = ""
		label.Parent = row

		return fill, label
	end

	local hpFill, hpText = makeBar("HP", 0, COLORS.hp, COLORS.hpBg)
	local enFill, enText = makeBar("Energy", 24, COLORS.energy, COLORS.energyBg)

	-- Stats allocate frame
	local statsFrame = Instance.new("Frame")
	statsFrame.Name = "StatsFrame"
	statsFrame.AnchorPoint = Vector2.new(0, 1)
	statsFrame.Position = UDim2.new(0, 16, 1, -90)
	statsFrame.Size = UDim2.fromOffset(260, 220)
	statsFrame.BackgroundColor3 = COLORS.bg
	statsFrame.Visible = false
	statsFrame.Parent = gui
	corner(statsFrame, 8)
	pad(statsFrame, 10)

	local statsTitle = Instance.new("TextLabel")
	statsTitle.Size = UDim2.new(1, 0, 0, 24)
	statsTitle.BackgroundTransparency = 1
	statsTitle.TextColor3 = COLORS.text
	statsTitle.Font = Enum.Font.GothamBold
	statsTitle.TextSize = 16
	statsTitle.TextXAlignment = Enum.TextXAlignment.Left
	statsTitle.Text = "Stat-Punkte"
	statsTitle.Parent = statsFrame

	local freeLabel = Instance.new("TextLabel")
	freeLabel.Name = "FreePoints"
	freeLabel.Position = UDim2.fromOffset(0, 28)
	freeLabel.Size = UDim2.new(1, 0, 0, 18)
	freeLabel.BackgroundTransparency = 1
	freeLabel.TextColor3 = COLORS.muted
	freeLabel.Font = Enum.Font.Gotham
	freeLabel.TextSize = 13
	freeLabel.TextXAlignment = Enum.TextXAlignment.Left
	freeLabel.Text = "Frei: 0"
	freeLabel.Parent = statsFrame

	local closeBtn = Instance.new("TextButton")
	closeBtn.Size = UDim2.fromOffset(28, 24)
	closeBtn.Position = UDim2.new(1, -28, 0, 0)
	closeBtn.BackgroundColor3 = COLORS.btn
	closeBtn.TextColor3 = COLORS.text
	closeBtn.Text = "X"
	closeBtn.Font = Enum.Font.GothamBold
	closeBtn.TextSize = 14
	closeBtn.Parent = statsFrame
	corner(closeBtn, 4)

	local cachedStats: { [string]: number } = {
		Melee = 0,
		Leben = 0,
		Chakra = 0,
		Schwer = 0,
	}
	local freePoints = 0
	local rowLabels: { [string]: TextLabel } = {}

	local function refreshStatRows()
		freeLabel.Text = ("Frei: %d"):format(freePoints)
		for _, key in Config.STAT_KEYS do
			local lbl = rowLabels[key]
			if lbl then
				lbl.Text = ("%s: %d"):format(key, cachedStats[key] or 0)
			end
		end
	end

	local y = 54
	for _, key in Config.STAT_KEYS do
		local row = Instance.new("Frame")
		row.Name = key
		row.Position = UDim2.fromOffset(0, y)
		row.Size = UDim2.new(1, 0, 0, 32)
		row.BackgroundTransparency = 1
		row.Parent = statsFrame

		local nameLbl = Instance.new("TextLabel")
		nameLbl.Size = UDim2.new(0.55, 0, 1, 0)
		nameLbl.BackgroundTransparency = 1
		nameLbl.TextColor3 = COLORS.text
		nameLbl.Font = Enum.Font.GothamMedium
		nameLbl.TextSize = 14
		nameLbl.TextXAlignment = Enum.TextXAlignment.Left
		nameLbl.Text = ("%s: 0"):format(key)
		nameLbl.Parent = row
		rowLabels[key] = nameLbl

		local plus = Instance.new("TextButton")
		plus.Size = UDim2.fromOffset(36, 28)
		plus.Position = UDim2.new(1, -40, 0.5, -14)
		plus.BackgroundColor3 = COLORS.accent
		plus.TextColor3 = COLORS.text
		plus.Font = Enum.Font.GothamBold
		plus.TextSize = 18
		plus.Text = "+"
		plus.Parent = row
		corner(plus, 4)

		plus.MouseButton1Click:Connect(function()
			if freePoints < 1 then
				return
			end
			Remotes.Event("AllocateStat"):FireServer(key, 1)
		end)

		y += 36
	end

	statsBtn.MouseButton1Click:Connect(function()
		statsFrame.Visible = not statsFrame.Visible
		if statsFrame.Visible then
			pcall(function()
				Remotes.Event("RequestOpenStats"):FireServer()
			end)
		end
	end)
	closeBtn.MouseButton1Click:Connect(function()
		statsFrame.Visible = false
	end)

	local function setBar(fill: Frame, label: TextLabel, current: number, max: number, prefix: string)
		max = math.max(max, 1)
		local ratio = math.clamp(current / max, 0, 1)
		fill.Size = UDim2.fromScale(ratio, 1)
		label.Text = ("%s %d / %d"):format(prefix, math.floor(current + 0.5), math.floor(max + 0.5))
	end

	local charConnections: { RBXScriptConnection } = {}

	local function clearCharConns()
		for _, c in charConnections do
			c:Disconnect()
		end
		table.clear(charConnections)
	end

	local function bindCharacter(character: Model)
		clearCharConns()
		local humanoid = character:WaitForChild("Humanoid", 10) :: Humanoid?
		if not humanoid then
			return
		end

		local function updateHp()
			setBar(hpFill, hpText, humanoid.Health, humanoid.MaxHealth, "HP")
		end
		updateHp()
		table.insert(charConnections, humanoid.HealthChanged:Connect(updateHp))
		table.insert(charConnections, humanoid:GetPropertyChangedSignal("MaxHealth"):Connect(updateHp))
	end

	local function updateEnergy()
		local cur = (player:GetAttribute("Energy") :: number?) or 0
		local max = (player:GetAttribute("MaxChakra") :: number?) or Config.BASE_MAX_CHAKRA
		setBar(enFill, enText, cur, max, "CH")
	end

	local function updateLevel()
		local lvl = (player:GetAttribute("SF_Level") :: number?) or 1
		levelLabel.Text = ("Lv. %d"):format(lvl)
		freePoints = (player:GetAttribute("SF_FreeStatPoints") :: number?) or freePoints
		refreshStatRows()
	end

	player:GetAttributeChangedSignal("Energy"):Connect(updateEnergy)
	player:GetAttributeChangedSignal("MaxChakra"):Connect(updateEnergy)
	player:GetAttributeChangedSignal("SF_Level"):Connect(updateLevel)
	player:GetAttributeChangedSignal("SF_FreeStatPoints"):Connect(function()
		freePoints = (player:GetAttribute("SF_FreeStatPoints") :: number?) or 0
		refreshStatRows()
	end)

	Remotes.Event("DataUpdated").OnClientEvent:Connect(function(data)
		if typeof(data) ~= "table" then
			return
		end
		if typeof(data.Level) == "number" then
			levelLabel.Text = ("Lv. %d"):format(data.Level)
		end
		if typeof(data.FreeStatPoints) == "number" then
			freePoints = data.FreeStatPoints
		end
		if typeof(data.Stats) == "table" then
			for _, key in Config.STAT_KEYS do
				local v = (data.Stats :: any)[key]
				if typeof(v) == "number" then
					cachedStats[key] = v
				end
			end
		end
		refreshStatRows()
	end)

	player.CharacterAdded:Connect(bindCharacter)
	if player.Character then
		task.spawn(bindCharacter, player.Character)
	end

	updateEnergy()
	updateLevel()
	refreshStatRows()

	print("[SoulFruits.Client] HUD ready (HP/Energy/Level/Stats)")
end

return HUD
