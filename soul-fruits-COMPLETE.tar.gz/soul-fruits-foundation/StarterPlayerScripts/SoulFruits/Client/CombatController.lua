--!strict
--[[
	CombatController – Client M1 input (MouseButton1).
	Fires CombatM1; local cooldown is feel-only. Server owns damage/combo.
	Studio: StarterPlayer > StarterPlayerScripts > SoulFruits > Client > CombatController (ModuleScript)
]]

local Players = game:GetService("Players")
local UserInputService = game:GetService("UserInputService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Shared = ReplicatedStorage:WaitForChild("SoulFruits"):WaitForChild("Shared")
local Config = require(Shared:WaitForChild("Config"))
local Remotes = require(Shared:WaitForChild("Remotes"))

local CombatController = {}
local started = false

function CombatController.Start()
	if started then
		return
	end
	started = true

	local player = Players.LocalPlayer
	local lastLocalSwing = 0
	local localCombo = 0

	local function tryM1()
		local now = os.clock()
		-- Mirror swing CD for feel only — server still authoritative
		if (now - lastLocalSwing) < Config.M1_SWING_COOLDOWN * 0.85 then
			return
		end

		local character = player.Character
		if not character then
			return
		end
		local humanoid = character:FindFirstChildOfClass("Humanoid")
		if not humanoid or humanoid.Health <= 0 then
			return
		end
		if player:GetAttribute("IsFlying") == true then
			return
		end
		local stunUntil = player:GetAttribute("SF_StunUntil")
		if typeof(stunUntil) == "number" and stunUntil > tick() then
			return
		end

		if localCombo > 0 and (now - lastLocalSwing) > Config.M1_COMBO_WINDOW then
			localCombo = 0
		end
		localCombo += 1
		if localCombo > Config.M1_HIT_COUNT then
			localCombo = 1
		end
		lastLocalSwing = now

		-- Hint only; server recomputes combo. No client damage.
		Remotes.Event("CombatM1"):FireServer(localCombo)
	end

	UserInputService.InputBegan:Connect(function(input, gameProcessed)
		if gameProcessed then
			return
		end
		if input.UserInputType == Enum.UserInputType.MouseButton1 then
			tryM1()
		elseif input.UserInputType == Enum.UserInputType.Touch then
			-- Mobile: left half tap could be movement; skip dedicated touch M1 for stub
		end
	end)

	print("[SoulFruits.Client] CombatController M1 ready")
end

return CombatController
