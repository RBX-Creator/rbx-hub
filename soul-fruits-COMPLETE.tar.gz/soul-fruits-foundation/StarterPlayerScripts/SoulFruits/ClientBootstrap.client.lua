--!strict
--[[
	Client bootstrap: Faction-Prompt + Data-Snapshot + HUD + Combat + Movement + Gacha + Fruit.
	Studio: StarterPlayer > StarterPlayerScripts > SoulFruits > ClientBootstrap (LocalScript)
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local player = Players.LocalPlayer
local Shared = ReplicatedStorage:WaitForChild("SoulFruits"):WaitForChild("Shared")
local Remotes = require(Shared:WaitForChild("Remotes"))
Remotes.Init()

local ClientFolder = script.Parent:WaitForChild("Client")
local HUD = require(ClientFolder:WaitForChild("HUD"))
local CombatController = require(ClientFolder:WaitForChild("CombatController"))
local MovementController = require(ClientFolder:WaitForChild("MovementController"))
local AnimationController = require(ClientFolder:WaitForChild("AnimationController"))
local GachaUI = require(ClientFolder:WaitForChild("GachaUI"))
local FruitController = require(ClientFolder:WaitForChild("FruitController"))
local VFXController = require(ClientFolder:WaitForChild("VFXController"))
local QuestUI = require(ClientFolder:WaitForChild("QuestUI"))
local PhysicalFruitController = require(ClientFolder:WaitForChild("PhysicalFruitController"))
local StorageUI = require(ClientFolder:WaitForChild("StorageUI"))

Remotes.Event("DataUpdated").OnClientEvent:Connect(function(data)
	player:SetAttribute("SF_Level", data.Level)
	player:SetAttribute("SF_Coins", data.Coins)
	player:SetAttribute("SF_Splitz", data.Splitz)
	player:SetAttribute("SF_DiceParts", data.DiceParts or 0)
	player:SetAttribute("SF_Faction", data.Faction)
	player:SetAttribute("SF_FreeStatPoints", data.FreeStatPoints)
	player:SetAttribute("SF_CurrentFruit", data.CurrentFruit)
	player:SetAttribute("SF_HatDreckFruit", data.HatDreckFruit == true)
	player:SetAttribute("SF_DreckMastery", data.DreckMastery or 0)
	player:SetAttribute("SF_BlutaugespiegelMastery", data.BlutaugespiegelMastery or 0)
end)

Remotes.Event("Notify").OnClientEvent:Connect(function(msg)
	print("[SoulFruits]", msg)
end)

-- Simple faction picker (ScreenGui) — replace with proper UI later
Remotes.Event("FactionPrompt").OnClientEvent:Connect(function()
	if player.PlayerGui:FindFirstChild("SF_FactionPrompt") then
		return
	end

	local gui = Instance.new("ScreenGui")
	gui.Name = "SF_FactionPrompt"
	gui.ResetOnSpawn = false
	gui.Parent = player.PlayerGui

	local frame = Instance.new("Frame")
	frame.Size = UDim2.fromScale(0.4, 0.25)
	frame.Position = UDim2.fromScale(0.3, 0.35)
	frame.BackgroundColor3 = Color3.fromRGB(25, 25, 30)
	frame.Parent = gui

	local title = Instance.new("TextLabel")
	title.Size = UDim2.fromScale(1, 0.35)
	title.BackgroundTransparency = 1
	title.Text = "Wähle deine Fraktion"
	title.TextColor3 = Color3.new(1, 1, 1)
	title.TextScaled = true
	title.Parent = frame

	local function makeButton(text: string, faction: string, x: number, color: Color3)
		local btn = Instance.new("TextButton")
		btn.Size = UDim2.fromScale(0.4, 0.35)
		btn.Position = UDim2.fromScale(x, 0.5)
		btn.BackgroundColor3 = color
		btn.Text = text
		btn.TextScaled = true
		btn.Parent = frame
		btn.MouseButton1Click:Connect(function()
			Remotes.Event("ChooseFaction"):FireServer(faction)
			gui:Destroy()
		end)
	end

	makeButton("Gut", "Gut", 0.08, Color3.fromRGB(60, 120, 220))
	makeButton("Böse", "Bose", 0.52, Color3.fromRGB(180, 50, 50))
end)

HUD.Start()
CombatController.Start()
MovementController.Start()
AnimationController.Start()
GachaUI.Start()
FruitController.Start()
VFXController.Start()
QuestUI.Start()
PhysicalFruitController.Start()
StorageUI.Start()

print("[SoulFruits] ClientBootstrap ready (Faction + HUD + M1 + Movement + Anim + Gacha/Stock + Fruit + VFX + Quests + PhysicalFruit)")
