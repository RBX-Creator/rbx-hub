--!strict
--[[
	Soul Fruits – Remote folder bootstrap
	Studio: ReplicatedStorage/SoulFruits/Shared/Remotes (ModuleScript)
	Creates Remotes under ReplicatedStorage/SoulFruits/Remotes if missing (server),
	or waits for them (client).
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local ROOT_NAME = "SoulFruits"
local REMOTES_FOLDER = "Remotes"

local REMOTE_EVENTS = {
	"ChooseFaction", -- Client → Server: "Gut" | "Bose"
	"AllocateStat", -- Client → Server: statKey, amount
	"FactionPrompt", -- Server → Client: show faction UI
	"DataUpdated", -- Server → Client: snapshot table
	"Notify", -- Server → Client: string message
	"CombatM1", -- Client → Server: optional comboIndex (hint only; server owns combo)
	"RequestOpenStats", -- Client → Server: optional ping; HUD may open locally
	"MovementDash", -- Client → Server: request dash (server uses LookVector)
	"MovementFly", -- Client → Server: boolean holding F
	"StockBuy", -- Client → Server: slotIndex 1..3
	"GachaRoll", -- Client → Server: (no args; Splitz cost)
	"StockUpdated", -- Server → Client: stock snapshot
	"GachaResult", -- Server → Client: fruitId, rarity
	"FruitMove", -- Client → Server: key "Z"|"X"|"C"|"V"
	"FruitSpecial", -- Client → Server: key "R" (Susanoo etc.; F stays flight)
	"QuestAccept", -- Client → Server: questId
	"QuestAbandon", -- Client → Server
	"QuestUpdated", -- Server → Client: quest state snapshot
	"FruitEat", -- Client → Server: eat held physical fruit
	"FruitStore", -- Client → Server: store held physical fruit
	"FruitRetrieve", -- Client → Server: fruitId from storage
	"FruitSpin", -- Server → Client: fruitId (gacha/stock spin FX)
	"FruitEatFX", -- Server → Client: fruitId (eat anim/VFX)
	"StorageUpdated", -- Server → Client: FruitStorage map
}

local REMOTE_FUNCTIONS = {
	-- none yet; keep list for future GetSnapshot etc.
}

local function getRoot(): Folder
	local root = ReplicatedStorage:FindFirstChild(ROOT_NAME)
	if not root then
		if RunService:IsServer() then
			root = Instance.new("Folder")
			root.Name = ROOT_NAME
			root.Parent = ReplicatedStorage
		else
			root = ReplicatedStorage:WaitForChild(ROOT_NAME, 30)
		end
	end
	assert(root, "[SoulFruits] Root folder missing")
	return root :: Folder
end

local function getRemotesFolder(): Folder
	local root = getRoot()
	local folder = root:FindFirstChild(REMOTES_FOLDER)
	if not folder then
		if RunService:IsServer() then
			folder = Instance.new("Folder")
			folder.Name = REMOTES_FOLDER
			folder.Parent = root
		else
			folder = root:WaitForChild(REMOTES_FOLDER, 30)
		end
	end
	assert(folder, "[SoulFruits] Remotes folder missing")
	return folder :: Folder
end

local Remotes = {}

function Remotes.Init()
	local folder = getRemotesFolder()
	if RunService:IsServer() then
		for _, name in REMOTE_EVENTS do
			if not folder:FindFirstChild(name) then
				local ev = Instance.new("RemoteEvent")
				ev.Name = name
				ev.Parent = folder
			end
		end
		for _, name in REMOTE_FUNCTIONS do
			if not folder:FindFirstChild(name) then
				local fn = Instance.new("RemoteFunction")
				fn.Name = name
				fn.Parent = folder
			end
		end
	end
end

function Remotes.Get(name: string): Instance
	local folder = getRemotesFolder()
	local remote = folder:FindFirstChild(name) or folder:WaitForChild(name, 15)
	assert(remote, "[SoulFruits] Remote missing: " .. name)
	return remote
end

function Remotes.Event(name: string): RemoteEvent
	return Remotes.Get(name) :: RemoteEvent
end

return Remotes
