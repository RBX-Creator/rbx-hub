--!strict
--[[
	Soul Fruits – Fruit / Gacha / Stock config (Planer v1 early table)
	Studio: ReplicatedStorage/SoulFruits/Shared/FruitsConfig (ModuleScript)
]]

local FruitsConfig = {}

FruitsConfig.STOCK_SIZE = 3
FruitsConfig.STOCK_REFRESH_SEC = 4 * 60 * 60 -- 4 hours (server os.time)
FruitsConfig.GACHA_COST_SPLITZ = 50
FruitsConfig.GACHA_COST_DICE_PARTS = 0 -- reserved; Splitz used for now

-- Rarity weights (sum 100)
FruitsConfig.RarityWeights = {
	Common = 55,
	Uncommon = 30,
	Rare = 12,
	Legendary = 3, -- Blutaugespiegel etc.; gacha normalizes with Mythical
	Mythical = 0.8, -- Sharingan (~0.8%); strongest tier
}

export type FruitDef = {
	Id: string,
	DisplayName: string,
	Rarity: string,
	Element: string,
	StockPriceCoins: number,
}

export type MoveDef = {
	Key: string,
	Name: string,
	Cost: number,
	Cooldown: number,
	Range: number,
	HitboxSize: Vector3,
	Damage: number,
	ProjectileSpeed: number,
	Description: string?,
}

local Fruits: { [string]: FruitDef } = {
	Dreck = {
		Id = "Dreck",
		DisplayName = "Dreck",
		Rarity = "Common",
		Element = "Erde",
		StockPriceCoins = 150,
	},
	Wind = {
		Id = "Wind",
		DisplayName = "Wind",
		Rarity = "Common",
		Element = "Luft",
		StockPriceCoins = 200,
	},
	Flame = {
		Id = "Flame",
		DisplayName = "Flame",
		Rarity = "Uncommon",
		Element = "Feuer",
		StockPriceCoins = 800,
	},
	Ice = {
		Id = "Ice",
		DisplayName = "Ice",
		Rarity = "Uncommon",
		Element = "Eis",
		StockPriceCoins = 800,
	},
	Light = {
		Id = "Light",
		DisplayName = "Light",
		Rarity = "Rare",
		Element = "Licht",
		StockPriceCoins = 2000,
	},
	Magma = {
		Id = "Magma",
		DisplayName = "Magma",
		Rarity = "Rare",
		Element = "Lava",
		StockPriceCoins = 2500,
	},
	Blutaugespiegel = {
		Id = "Blutaugespiegel",
		DisplayName = "Blutaugespiegel",
		Rarity = "Legendary",
		Element = "Spiegel",
		StockPriceCoins = 28000,
	},
	Sharingan = {
		Id = "Sharingan",
		DisplayName = "Sharingan",
		Rarity = "Mythical",
		Element = "Auge",
		StockPriceCoins = 100000, -- effectively gacha-primary; absurd stock price
	},
}

FruitsConfig.Fruits = Fruits

FruitsConfig.RarityOrder = { "Common", "Uncommon", "Rare", "Legendary", "Mythical" }

FruitsConfig.RarityColors = {
	Common = Color3.fromRGB(180, 180, 185),
	Uncommon = Color3.fromRGB(80, 200, 120),
	Rare = Color3.fromRGB(70, 140, 255),
	Legendary = Color3.fromRGB(255, 180, 40),
	Mythical = Color3.fromRGB(200, 40, 55), -- Sharingan crimson
}

local DreckMoves: { [string]: MoveDef } = {
	Z = {
		Key = "Z",
		Name = "Erdkugel",
		Cost = 20,
		Cooldown = 1.5,
		Range = 40,
		HitboxSize = Vector3.new(4, 4, 4),
		Damage = 12,
		ProjectileSpeed = 60,
		Description = "Erdkugel-Projektil",
	},
	X = {
		Key = "X",
		Name = "Steinwurf",
		Cost = 30,
		Cooldown = 2.5,
		Range = 50,
		HitboxSize = Vector3.new(5, 5, 5),
		Damage = 18,
		ProjectileSpeed = 70,
		Description = "Schwerer Steinwurf",
	},
	C = {
		Key = "C",
		Name = "Erdstoß",
		Cost = 40,
		Cooldown = 4.0,
		Range = 12,
		HitboxSize = Vector3.new(10, 6, 14),
		Damage = 28,
		ProjectileSpeed = 0,
		Description = "Frontaler Erdstoß",
	},
	V = {
		Key = "V",
		Name = "Erdwall",
		Cost = 55,
		Cooldown = 8.0,
		Range = 8,
		HitboxSize = Vector3.new(8, 10, 4),
		Damage = 0,
		ProjectileSpeed = 0,
		Description = "Schützender Erdwall",
	},
}

-- Planer Legendary kit (CH costs); gameplay stubs on server
local BlutaugespiegelMoves: { [string]: MoveDef } = {
	Z = {
		Key = "Z",
		Name = "Spiegelblick",
		Cost = 45,
		Cooldown = 3.0,
		Range = 28,
		HitboxSize = Vector3.new(10, 8, 18),
		Damage = 0,
		ProjectileSpeed = 0,
		Description = "Kurzer Slow/Stun-Mark auf nächsten Gegner im Kegel",
	},
	X = {
		Key = "X",
		Name = "Echo-Schlag",
		Cost = 55,
		Cooldown = 4.0,
		Range = 10,
		HitboxSize = Vector3.new(8, 6, 10),
		Damage = 22, -- fallback if no SF_LastM1Damage
		ProjectileSpeed = 0,
		Description = "Burst-Kopie des letzten M1-Treffers nach vorne",
	},
	C = {
		Key = "C",
		Name = "Voraussicht",
		Cost = 70,
		Cooldown = 10.0,
		Range = 0,
		HitboxSize = Vector3.new(1, 1, 1),
		Damage = 0,
		ProjectileSpeed = 0,
		Description = "2–3s Dodge/Parry-Fenster (SF_ParryUntil)",
	},
	V = {
		Key = "V",
		Name = "Blutspiegel-Welt",
		Cost = 100,
		Cooldown = 14.0,
		Range = 18,
		HitboxSize = Vector3.new(28, 12, 28),
		Damage = 4, -- light DoT tick damage
		ProjectileSpeed = 0,
		Description = "AoE Illusion: Desorient + leichter DoT",
	},
}



-- Mythical kit (strongest); R = Special (FruitSpecial remote), F stays flight
local SharinganMoves: { [string]: MoveDef } = {
	Z = {
		Key = "Z",
		Name = "Tomoe Burst",
		Cost = 50,
		Cooldown = 2.8,
		Range = 26,
		HitboxSize = Vector3.new(10, 8, 16),
		Damage = 26,
		ProjectileSpeed = 0,
		Description = "Tomoe-Burst frontal",
	},
	X = {
		Key = "X",
		Name = "Genjutsu Lock",
		Cost = 65,
		Cooldown = 5.0,
		Range = 24,
		HitboxSize = Vector3.new(10, 8, 16),
		Damage = 6,
		ProjectileSpeed = 0,
		Description = "Stun/Lock-Mark auf nächsten Gegner im Kegel",
	},
	C = {
		Key = "C",
		Name = "Copy Glance",
		Cost = 75,
		Cooldown = 6.0,
		Range = 12,
		HitboxSize = Vector3.new(9, 6, 12),
		Damage = 24, -- fallback if no SF_LastM1Damage
		ProjectileSpeed = 0,
		Description = "Kurze Kopie des letzten M1-Schadens (wie Echo)",
	},
	V = {
		Key = "V",
		Name = "Amaterasu",
		Cost = 110,
		Cooldown = 14.0,
		Range = 16,
		HitboxSize = Vector3.new(22, 10, 22),
		Damage = 7, -- black-flame DoT tick
		ProjectileSpeed = 0,
		Description = "Verweilendes schwarzes Flammen-AoE (DoT)",
	},
}

-- Special (R) — not in VALID_MOVE_KEYS; client uses FruitSpecial
local SharinganSpecial: { [string]: MoveDef } = {
	R = {
		Key = "R",
		Name = "Partial Susanoo",
		Cost = 90,
		Cooldown = 12.0,
		Range = 10,
		HitboxSize = Vector3.new(14, 10, 14),
		Damage = 18,
		ProjectileSpeed = 0,
		Description = "Kurze Rüstung (DR) + kleiner AoE; F bleibt Flug",
	},
}

-- Mid-tier Planer kits (between Dreck and Blutaugespiegel CH costs)
local WindMoves: { [string]: MoveDef } = {
	Z = {
		Key = "Z",
		Name = "Push",
		Cost = 22,
		Cooldown = 1.6,
		Range = 36,
		HitboxSize = Vector3.new(4, 4, 6),
		Damage = 10,
		ProjectileSpeed = 72,
		Description = "Windstoß-Projektil mit Knockback",
	},
	X = {
		Key = "X",
		Name = "Slash",
		Cost = 32,
		Cooldown = 2.4,
		Range = 14,
		HitboxSize = Vector3.new(10, 5, 8),
		Damage = 16,
		ProjectileSpeed = 0,
		Description = "Luftklingen-Slash frontal",
	},
	C = {
		Key = "C",
		Name = "Gust",
		Cost = 42,
		Cooldown = 4.0,
		Range = 16,
		HitboxSize = Vector3.new(12, 8, 16),
		Damage = 14,
		ProjectileSpeed = 0,
		Description = "Böen-Kegel mit starkem Push",
	},
	V = {
		Key = "V",
		Name = "Tornado",
		Cost = 58,
		Cooldown = 9.0,
		Range = 10,
		HitboxSize = Vector3.new(12, 14, 12),
		Damage = 8,
		ProjectileSpeed = 0,
		Description = "Kleiner Tornado-AoE",
	},
}

local FlameMoves: { [string]: MoveDef } = {
	Z = {
		Key = "Z",
		Name = "Ball",
		Cost = 25,
		Cooldown = 1.7,
		Range = 42,
		HitboxSize = Vector3.new(4, 4, 4),
		Damage = 14,
		ProjectileSpeed = 65,
		Description = "Feuerball-Projektil + leichter DoT",
	},
	X = {
		Key = "X",
		Name = "Wave",
		Cost = 35,
		Cooldown = 2.8,
		Range = 18,
		HitboxSize = Vector3.new(12, 5, 16),
		Damage = 20,
		ProjectileSpeed = 0,
		Description = "Flammenwelle frontal",
	},
	C = {
		Key = "C",
		Name = "Burst",
		Cost = 45,
		Cooldown = 4.5,
		Range = 10,
		HitboxSize = Vector3.new(14, 10, 14),
		Damage = 26,
		ProjectileSpeed = 0,
		Description = "Nah-Burst Explosion",
	},
	V = {
		Key = "V",
		Name = "Eruption",
		Cost = 65,
		Cooldown = 11.0,
		Range = 14,
		HitboxSize = Vector3.new(20, 10, 20),
		Damage = 6,
		ProjectileSpeed = 0,
		Description = "Boden-Eruption AoE mit DoT",
	},
}

local IceMoves: { [string]: MoveDef } = {
	Z = {
		Key = "Z",
		Name = "Spike",
		Cost = 25,
		Cooldown = 1.7,
		Range = 40,
		HitboxSize = Vector3.new(3.5, 3.5, 5),
		Damage = 15,
		ProjectileSpeed = 68,
		Description = "Eissplitter-Projektil",
	},
	X = {
		Key = "X",
		Name = "Freeze",
		Cost = 35,
		Cooldown = 3.0,
		Range = 22,
		HitboxSize = Vector3.new(10, 8, 14),
		Damage = 8,
		ProjectileSpeed = 0,
		Description = "Freeze-Mark + starker Slow",
	},
	C = {
		Key = "C",
		Name = "Path",
		Cost = 48,
		Cooldown = 5.0,
		Range = 20,
		HitboxSize = Vector3.new(8, 4, 22),
		Damage = 18,
		ProjectileSpeed = 0,
		Description = "Eispfad frontal + Slow",
	},
	V = {
		Key = "V",
		Name = "Prison",
		Cost = 70,
		Cooldown = 12.0,
		Range = 12,
		HitboxSize = Vector3.new(16, 12, 16),
		Damage = 10,
		ProjectileSpeed = 0,
		Description = "Eis-Gefängnis AoE (Freeze)",
	},
}


local LightMoves: { [string]: MoveDef } = {
	Z = {
		Key = "Z",
		Name = "Beam",
		Cost = 30,
		Cooldown = 1.8,
		Range = 48,
		HitboxSize = Vector3.new(3, 3, 28),
		Damage = 18,
		ProjectileSpeed = 120,
		Description = "Schneller Lichtstrahl (Ray/Beam)",
	},
	X = {
		Key = "X",
		Name = "Flash",
		Cost = 40,
		Cooldown = 5.0,
		Range = 0,
		HitboxSize = Vector3.new(8, 8, 8),
		Damage = 0,
		ProjectileSpeed = 0,
		Description = "Blitz-Flash mit kurzen i-Frames",
	},
	C = {
		Key = "C",
		Name = "Barrage",
		Cost = 55,
		Cooldown = 4.5,
		Range = 22,
		HitboxSize = Vector3.new(8, 6, 14),
		Damage = 8,
		ProjectileSpeed = 0,
		Description = "Multi-Hit Licht-Barrage",
	},
	V = {
		Key = "V",
		Name = "Nova",
		Cost = 80,
		Cooldown = 12.0,
		Range = 14,
		HitboxSize = Vector3.new(22, 12, 22),
		Damage = 32,
		ProjectileSpeed = 0,
		Description = "Licht-Nova AoE",
	},
}

local MagmaMoves: { [string]: MoveDef } = {
	Z = {
		Key = "Z",
		Name = "Glob",
		Cost = 32,
		Cooldown = 1.9,
		Range = 40,
		HitboxSize = Vector3.new(4.5, 4.5, 4.5),
		Damage = 16,
		ProjectileSpeed = 55,
		Description = "Magma-Glob Projektil",
	},
	X = {
		Key = "X",
		Name = "Pool",
		Cost = 42,
		Cooldown = 5.5,
		Range = 16,
		HitboxSize = Vector3.new(14, 4, 14),
		Damage = 6,
		ProjectileSpeed = 0,
		Description = "Verweilender Lava-Pool DoT",
	},
	C = {
		Key = "C",
		Name = "Surge",
		Cost = 58,
		Cooldown = 5.0,
		Range = 18,
		HitboxSize = Vector3.new(12, 8, 18),
		Damage = 24,
		ProjectileSpeed = 0,
		Description = "Magma-Surge Kegel",
	},
	V = {
		Key = "V",
		Name = "Volcano",
		Cost = 85,
		Cooldown = 13.0,
		Range = 16,
		HitboxSize = Vector3.new(24, 14, 24),
		Damage = 10,
		ProjectileSpeed = 0,
		Description = "Vulkan-AoE mit Lava-Ticks",
	},
}

FruitsConfig.DreckMoves = DreckMoves
FruitsConfig.WindMoves = WindMoves
FruitsConfig.FlameMoves = FlameMoves
FruitsConfig.IceMoves = IceMoves
FruitsConfig.LightMoves = LightMoves
FruitsConfig.MagmaMoves = MagmaMoves
FruitsConfig.BlutaugespiegelMoves = BlutaugespiegelMoves
FruitsConfig.SharinganMoves = SharinganMoves
FruitsConfig.SharinganSpecial = SharinganSpecial
FruitsConfig.VALID_MOVE_KEYS = { "Z", "X", "C", "V" }
FruitsConfig.VALID_SPECIAL_KEYS = { "R" }

local MovesByFruit: { [string]: { [string]: MoveDef } } = {
	Dreck = DreckMoves,
	Wind = WindMoves,
	Flame = FlameMoves,
	Ice = IceMoves,
	Light = LightMoves,
	Magma = MagmaMoves,
	Blutaugespiegel = BlutaugespiegelMoves,
	Sharingan = SharinganMoves,
}

local SpecialByFruit: { [string]: { [string]: MoveDef } } = {
	Sharingan = SharinganSpecial,
}

FruitsConfig.MovesByFruit = MovesByFruit
FruitsConfig.SpecialByFruit = SpecialByFruit

function FruitsConfig.GetMoves(fruitId: string): { [string]: MoveDef }?
	return MovesByFruit[fruitId]
end

function FruitsConfig.GetSpecial(fruitId: string): { [string]: MoveDef }?
	return SpecialByFruit[fruitId]
end

function FruitsConfig.HasSpecial(fruitId: string, key: string?): boolean
	local specials = SpecialByFruit[fruitId]
	if not specials then
		return false
	end
	if key == nil then
		return next(specials) ~= nil
	end
	return specials[key] ~= nil
end

function FruitsConfig.GetFruitsByRarity(rarity: string): { FruitDef }
	local list: { FruitDef } = {}
	for _, def in Fruits do
		if def.Rarity == rarity then
			table.insert(list, def)
		end
	end
	return list
end

function FruitsConfig.ListFruitIds(): { string }
	local ids: { string } = {}
	for id in Fruits do
		table.insert(ids, id)
	end
	table.sort(ids)
	return ids
end

return FruitsConfig
