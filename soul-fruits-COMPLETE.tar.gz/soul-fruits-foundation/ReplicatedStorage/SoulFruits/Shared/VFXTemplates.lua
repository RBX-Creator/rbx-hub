--!strict
--[[
	Soul Fruits – VFX Templates (ParticleEmitter / Trail Builder)
	Studio: ReplicatedStorage/SoulFruits/Shared/VFXTemplates (ModuleScript)
	Pure constructors – kein Gameplay, nur Optik.
]]

local VFXConfig = require(script.Parent:WaitForChild("VFXConfig"))

local VFXTemplates = {}

local function transparent(): NumberSequence
	return NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0.15),
		NumberSequenceKeypoint.new(0.5, 0.45),
		NumberSequenceKeypoint.new(1, 1),
	})
end

function VFXTemplates.EnsureAttachment(parent: BasePart, name: string, offset: Vector3?): Attachment
	local existing = parent:FindFirstChild(name)
	if existing and existing:IsA("Attachment") then
		return existing
	end
	local att = Instance.new("Attachment")
	att.Name = name
	att.Position = offset or Vector3.zero
	att.Parent = parent
	return att
end

function VFXTemplates.MakeDust(parent: Attachment, name: string): ParticleEmitter
	local p = Instance.new("ParticleEmitter")
	p.Name = name
	p.Texture = "rbxasset://textures/particles/smoke_main.dds"
	p.Color = ColorSequence.new({
		ColorSequenceKeypoint.new(0, VFXConfig.Colors.Dust),
		ColorSequenceKeypoint.new(1, VFXConfig.Colors.DustDark),
	})
	p.Size = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0.6),
		NumberSequenceKeypoint.new(1, 1.8),
	})
	p.Transparency = transparent()
	p.Lifetime = NumberRange.new(0.25, 0.45)
	p.Speed = NumberRange.new(2, 6)
	p.SpreadAngle = Vector2.new(40, 40)
	p.Rotation = NumberRange.new(0, 360)
	p.RotSpeed = NumberRange.new(-60, 60)
	p.Rate = 0
	p.Enabled = false
	p.LightEmission = 0
	p.LightInfluence = 0.6
	p.Parent = parent
	return p
end

function VFXTemplates.MakeTrail(att0: Attachment, att1: Attachment, name: string): Trail
	local t = Instance.new("Trail")
	t.Name = name
	t.Attachment0 = att0
	t.Attachment1 = att1
	t.Color = ColorSequence.new({
		ColorSequenceKeypoint.new(0, VFXConfig.Colors.TrailCore),
		ColorSequenceKeypoint.new(1, VFXConfig.Colors.Trail),
	})
	t.Transparency = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0.2),
		NumberSequenceKeypoint.new(1, 1),
	})
	t.Lifetime = VFXConfig.Dash.TrailLifetime
	t.MinLength = 0.05
	t.MaxLength = 8
	t.WidthScale = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 1),
		NumberSequenceKeypoint.new(1, 0),
	})
	t.LightEmission = 0.35
	t.FaceCamera = true
	t.Enabled = false
	t.Parent = att0.Parent
	return t
end

function VFXTemplates.MakeAura(parent: Attachment, name: string): ParticleEmitter
	local p = Instance.new("ParticleEmitter")
	p.Name = name
	p.Texture = "rbxasset://textures/particles/smoke_main.dds"
	p.Color = ColorSequence.new({
		ColorSequenceKeypoint.new(0, VFXConfig.Colors.AuraCore),
		ColorSequenceKeypoint.new(1, VFXConfig.Colors.Aura),
	})
	p.Size = VFXConfig.Fly.Size
	p.Transparency = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0.35),
		NumberSequenceKeypoint.new(1, 1),
	})
	p.Lifetime = NumberRange.new(VFXConfig.Fly.Lifetime * 0.7, VFXConfig.Fly.Lifetime)
	p.Speed = NumberRange.new(0.4, 1.2)
	p.SpreadAngle = Vector2.new(25, 25)
	p.Rate = VFXConfig.Fly.Rate
	p.Enabled = false
	p.LightEmission = 0.55
	p.LightInfluence = 0.2
	p.Drag = 1
	p.Parent = parent
	return p
end

function VFXTemplates.MakeSparks(parent: Attachment, name: string): ParticleEmitter
	local p = Instance.new("ParticleEmitter")
	p.Name = name
	p.Texture = "rbxasset://textures/particles/sparkles_main.dds"
	p.Color = ColorSequence.new({
		ColorSequenceKeypoint.new(0, VFXConfig.Colors.ImpactFlash),
		ColorSequenceKeypoint.new(1, VFXConfig.Colors.Impact),
	})
	p.Size = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0.35),
		NumberSequenceKeypoint.new(1, 0.05),
	})
	p.Transparency = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0.1),
		NumberSequenceKeypoint.new(1, 1),
	})
	p.Lifetime = NumberRange.new(0.12, 0.28)
	p.Speed = NumberRange.new(6, 14)
	p.SpreadAngle = Vector2.new(55, 55)
	p.Rate = 0
	p.Enabled = false
	p.LightEmission = 0.8
	p.Parent = parent
	return p
end

--- Dreck Fruit stubs (Z/X/C/V) – ready when Fruit service fires attributes
function VFXTemplates.MakeEarthBurst(parent: Attachment, name: string): ParticleEmitter
	local p = Instance.new("ParticleEmitter")
	p.Name = name
	p.Texture = "rbxasset://textures/particles/smoke_main.dds"
	p.Color = ColorSequence.new({
		ColorSequenceKeypoint.new(0, VFXConfig.Colors.Earth),
		ColorSequenceKeypoint.new(1, VFXConfig.Colors.EarthDark),
	})
	p.Size = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0.8),
		NumberSequenceKeypoint.new(1, 2.4),
	})
	p.Transparency = transparent()
	p.Lifetime = NumberRange.new(0.35, 0.7)
	p.Speed = NumberRange.new(4, 10)
	p.SpreadAngle = Vector2.new(50, 50)
	p.Rate = 0
	p.Enabled = false
	p.LightEmission = 0
	p.LightInfluence = 0.7
	p.Parent = parent
	return p
end

function VFXTemplates.MakeStoneChips(parent: Attachment, name: string): ParticleEmitter
	local p = Instance.new("ParticleEmitter")
	p.Name = name
	p.Texture = "rbxasset://textures/particles/smoke_main.dds"
	p.Color = ColorSequence.new(VFXConfig.Colors.Stone)
	p.Size = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0.25),
		NumberSequenceKeypoint.new(1, 0.08),
	})
	p.Transparency = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0.2),
		NumberSequenceKeypoint.new(1, 1),
	})
	p.Lifetime = NumberRange.new(0.2, 0.45)
	p.Speed = NumberRange.new(8, 16)
	p.SpreadAngle = Vector2.new(70, 70)
	p.Acceleration = Vector3.new(0, -40, 0)
	p.Rate = 0
	p.Enabled = false
	p.Parent = parent
	return p
end

return VFXTemplates
