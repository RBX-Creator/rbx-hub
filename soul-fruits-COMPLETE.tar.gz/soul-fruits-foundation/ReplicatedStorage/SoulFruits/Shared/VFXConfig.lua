--!strict
--[[
	Soul Fruits – VFX Config (Farben + Intensitäten)
	Studio: ReplicatedStorage/SoulFruits/Shared/VFXConfig (ModuleScript)
]]

local VFXConfig = {}

-- Basis (Dash/Fly/Hit) – Gut/Böse später
VFXConfig.Colors = {
	Dust = Color3.fromRGB(180, 160, 130),
	DustDark = Color3.fromRGB(110, 95, 75),
	Trail = Color3.fromRGB(220, 230, 255),
	TrailCore = Color3.fromRGB(255, 255, 255),
	Aura = Color3.fromRGB(170, 210, 255),
	AuraCore = Color3.fromRGB(240, 250, 255),
	Impact = Color3.fromRGB(255, 230, 180),
	ImpactFlash = Color3.fromRGB(255, 255, 240),
	Earth = Color3.fromRGB(140, 105, 70),
	EarthDark = Color3.fromRGB(90, 70, 45),
	Stone = Color3.fromRGB(160, 150, 140),
}

-- Fruit-Paletten (Primary / Secondary) – gleiche Hooks VFX_FruitZ–V
VFXConfig.FruitPalettes = {
	Dreck = {
		primary = Color3.fromRGB(140, 105, 70),
		secondary = Color3.fromRGB(90, 70, 45),
		accent = Color3.fromRGB(160, 150, 140),
		intensity = 1,
	},
	Wind = {
		primary = Color3.fromRGB(140, 230, 220),
		secondary = Color3.fromRGB(90, 190, 200),
		accent = Color3.fromRGB(220, 255, 250),
		intensity = 1.05,
	},
	Flame = {
		primary = Color3.fromRGB(255, 140, 50),
		secondary = Color3.fromRGB(220, 60, 20),
		accent = Color3.fromRGB(255, 220, 120),
		intensity = 1.25,
	},
	Ice = {
		primary = Color3.fromRGB(160, 220, 255),
		secondary = Color3.fromRGB(100, 170, 230),
		accent = Color3.fromRGB(240, 250, 255),
		intensity = 1.2,
	},
	Light = {
		primary = Color3.fromRGB(255, 230, 140),
		secondary = Color3.fromRGB(255, 250, 220),
		accent = Color3.fromRGB(255, 255, 255),
		intensity = 1.25,
	},
	Magma = {
		primary = Color3.fromRGB(255, 90, 30),
		secondary = Color3.fromRGB(60, 40, 35),
		accent = Color3.fromRGB(255, 180, 60),
		intensity = 1.3,
	},
	Blutaugespiegel = {
		primary = Color3.fromRGB(180, 20, 40),
		secondary = Color3.fromRGB(40, 10, 20),
		accent = Color3.fromRGB(255, 60, 80),
		intensity = 1.85,
	},
}

VFXConfig.Dash = {
	TrailLifetime = 0.22,
	DustBurst = 18,
	DustLifetime = 0.35,
}

VFXConfig.Fly = {
	Rate = 12,
	Lifetime = 0.55,
	Size = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0.35),
		NumberSequenceKeypoint.new(1, 0.05),
	}),
}

VFXConfig.Hit = {
	Sparks = 18,
	Dust = 14,
	Lifetime = 0.22,
	FlashSize = 1.1,
	Combo4Mult = 1.45,
}

VFXConfig.ATTR = {
	Dash = "VFX_Dash",
	Fly = "VFX_Fly",
	Hit = "VFX_Hit",
	FruitZ = "VFX_FruitZ",
	FruitX = "VFX_FruitX",
	FruitC = "VFX_FruitC",
	FruitV = "VFX_FruitV",
	Susanoo = "VFX_Susanoo",
	FruitSpin = "VFX_FruitSpin",
	FruitEat = "SF_FruitEat",
	Flying = "IsFlying",
	CurrentFruit = "SF_CurrentFruit",
}

function VFXConfig.GetPalette(fruitId: string?): {
	primary: Color3,
	secondary: Color3,
	accent: Color3,
	intensity: number,
}
	if fruitId == "Sharingan" then
		fruitId = "Blutaugespiegel"
	end
	if fruitId and VFXConfig.FruitPalettes[fruitId] then
		return VFXConfig.FruitPalettes[fruitId]
	end
	return VFXConfig.FruitPalettes.Dreck
end

return VFXConfig
