--!strict
--[[
	Soul Fruits – Shared type aliases (documentation / Luau types)
	Studio: ReplicatedStorage/SoulFruits/Shared/Types (ModuleScript)
]]

export type Faction = "Gut" | "Bose"

export type Stats = {
	Melee: number,
	Leben: number,
	Chakra: number,
	Schwer: number,
}

export type HomePoint = {
	X: number,
	Y: number,
	Z: number,
	PlaceId: number?,
}

export type PlayerProfile = {
	Level: number,
	XP: number,
	Coins: number,
	Splitz: number,
	DiceParts: number,
	Faction: Faction?,
	Stats: Stats,
	FreeStatPoints: number,
	HatDreckFruit: boolean,
	CurrentFruit: string?,
	DreckMastery: number,
	BlutaugespiegelMastery: number,
	FruitMastery: { [string]: number },
	OwnedFruits: { [string]: boolean },
	-- SharinganAwakened: legacy unused stub (Susanoo later)
	SharinganAwakened: boolean,
	HomePoint: HomePoint?,
	ActiveQuestId: string?,
	QuestProgress: number,
	CompletedQuests: { [string]: boolean },
	FruitStorage: { [string]: boolean }, -- 1 slot per fruit type (uneaten)
}

return {}
