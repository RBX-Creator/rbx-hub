--!strict
--[[
	Soul Fruits – Shared Config
	Studio: ReplicatedStorage/SoulFruits/Shared/Config (ModuleScript)
]]

local Config = {}

Config.DATASTORE_NAME = "SoulFruits_PlayerData_v1"
Config.DATASTORE_SCOPE = "Sea1"

-- Level / XP (Sea 1 cap)
Config.MAX_LEVEL = 700
Config.STAT_POINTS_PER_LEVEL = 3

-- Base energy (Chakra) before stat scaling
Config.BASE_MAX_CHAKRA = 100
-- Extra max energy per Chakra-stat point
Config.CHAKRA_PER_STAT = 5
-- Extra max HP per Leben-stat point
Config.HP_PER_LEBEN = 10
Config.BASE_MAX_HP = 100

-- Energy regen (units / second)
Config.ENERGY_REGEN_STANDING = 8
Config.ENERGY_REGEN_RUNNING = 4
Config.ENERGY_REGEN_FLYING = 0

-- Movement costs (hooks for later Movement system)
Config.FLIGHT_COST_PER_SEC = 10 -- F hold
Config.DASH_COST = 15 -- Q
Config.DASH_COOLDOWN = 1.2
Config.DASH_SPEED = 80 -- studs/s impulse feel
Config.DASH_DURATION = 0.18 -- seconds of forced velocity
Config.FLIGHT_SPEED = 48 -- normal run-ish, not overpowered
Config.FLIGHT_VERTICAL_FACTOR = 0.85

-- Combat M1 (melee combo, 0 energy)
Config.M1_HIT_COUNT = 4
Config.M1_ENERGY_COST = 0
-- BF-ähnlich (eigenes Timing, kein Copy): schneller Takt, Stun-Weave, Finisher-Knockback
Config.M1_SWING_COOLDOWN = 0.24 -- Attack-Polish: kürzerer Windup
Config.M1_COMBO_WINDOW = 0.85 -- Attack-Polish: straffer Combo-Takt
Config.M1_RANGE = 7 -- studs in front of character
Config.M1_HITBOX_SIZE = Vector3.new(5.5, 5.5, 7)
Config.M1_BASE_DAMAGE = 9
Config.M1_MELEE_FACTOR = 0.55 -- damage += Melee * factor
Config.M1_STUN_PER_HIT = 0.26 -- Attack-Polish: mehr Hit-Confirm
Config.M1_FINISHER_STUN = 0.5 -- hit 4 Confirm
Config.M1_FINISHER_KNOCKBACK = 42 -- studs/s horizontal
Config.M1_LUNGE_SPEED = 32 -- Attack-Polish: klarerer Lunge

-- Anti-Cheat soft limits
Config.ANTICHEAT_MAX_REMOTE_PER_SEC = 12
Config.ANTICHEAT_SOFT_KICK_THRESHOLD = 40 -- suspicious pattern count before soft kick
Config.ANTICHEAT_DEFAULT_COOLDOWN = 0.05 -- min gap between same remote if not specified

-- Day / Night (server cycle, not real time)
Config.DAY_DURATION = 10 * 60 -- seconds
Config.NIGHT_DURATION = 10 * 60
Config.CYCLE_STARTS_DAY = true

-- Factions
Config.FACTIONS = {
	Gut = "Gut",
	Bose = "Bose", -- Böse without umlaut in identifiers
}

Config.STAT_KEYS = { "Melee", "Leben", "Chakra", "Schwer" }

-- Fruit ability energy costs (Dreck – mirrored in FruitsConfig.DreckMoves)
Config.FRUIT_DRECK_Z_COST = 20
Config.FRUIT_DRECK_X_COST = 30
Config.FRUIT_DRECK_C_COST = 40
Config.FRUIT_DRECK_V_COST = 55

-- Blutaugespiegel (Legendary) – mirrored in FruitsConfig.BlutaugespiegelMoves
Config.FRUIT_BLUT_Z_COST = 45
Config.FRUIT_BLUT_X_COST = 55
Config.FRUIT_BLUT_C_COST = 70
Config.FRUIT_BLUT_V_COST = 100

-- Wind (Common mid) – mirrored in FruitsConfig.WindMoves
Config.FRUIT_WIND_Z_COST = 22
Config.FRUIT_WIND_X_COST = 32
Config.FRUIT_WIND_C_COST = 42
Config.FRUIT_WIND_V_COST = 58

-- Flame (Uncommon) – mirrored in FruitsConfig.FlameMoves
Config.FRUIT_FLAME_Z_COST = 25
Config.FRUIT_FLAME_X_COST = 35
Config.FRUIT_FLAME_C_COST = 45
Config.FRUIT_FLAME_V_COST = 65

-- Ice (Uncommon) – mirrored in FruitsConfig.IceMoves
Config.FRUIT_ICE_Z_COST = 25
Config.FRUIT_ICE_X_COST = 35
Config.FRUIT_ICE_C_COST = 48
Config.FRUIT_ICE_V_COST = 70

-- Light (Rare) – mirrored in FruitsConfig.LightMoves
Config.FRUIT_LIGHT_Z_COST = 30
Config.FRUIT_LIGHT_X_COST = 40
Config.FRUIT_LIGHT_C_COST = 55
Config.FRUIT_LIGHT_V_COST = 80

-- Magma (Rare) – mirrored in FruitsConfig.MagmaMoves
Config.FRUIT_MAGMA_Z_COST = 32
Config.FRUIT_MAGMA_X_COST = 42
Config.FRUIT_MAGMA_C_COST = 58
Config.FRUIT_MAGMA_V_COST = 85

-- Blutaugespiegel (Mythical eye) – costs live in FruitsConfig.BlutaugespiegelMoves
-- Susanoo / R special later (stub disabled)

-- VFX attribute / BindableEvent names (Animator / VFX scripter hooks)
Config.VFX = {
	Dash = "VFX_Dash",
	Fly = "VFX_Fly",
	Hit = "VFX_Hit",
	FruitZ = "VFX_FruitZ",
	FruitX = "VFX_FruitX",
	FruitC = "VFX_FruitC",
	FruitV = "VFX_FruitV",
	Susanoo = "VFX_Susanoo",
}

return Config
