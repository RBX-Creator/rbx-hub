# FruitToolTemplates

Optional Handle-Meshes pro FruitId (Dreck, Wind, …).
Blender Tool-Handle Scale → hier als Part/Model PrimaryPart.
Ohne Template: farbiger Ball-Handle.
