# EnemyTemplates (R15 / Toolbox)

**Optik = R15 Spieler-Look** (Marketplace/Toolbox Free oder von Leeam gekauft). Keine Tier-Körper.

## Template-Namen (exakt)

| Id | Display | Outfit-Hinweis |
|----|---------|----------------|
| `Bandit` | Bandit | Pirate/Bandit R15 |
| `MobLeader` | Mob Leader | dunkleres Outfit / Cape |
| `Affe` | Jungle Brawler | Jungle-Outfit R15 |
| `Gorilla` | Heavy Brawler | Brawler R15, Scale ~1.15 |
| `GorillaKing` | Brawler King | Brawler + Krone, Scale ~1.35 |
| `Outlaw` | Outlaw | Outlaw Village R15 |
| `Brute` | Brute | schweres Outfit, Scale ~1.2 |
| `ClownCaptain` | Clown Captain | Boss-Outfit, Scale ~1.3 |
| `DesertBandit` | Desert Bandit | Desert/Pirate R15 |
| `DesertOfficer` | Desert Officer | Officer R15 |
| `SandKing` | Sand King | Boss R15, Scale ~1.4 |

Humanoid + Animator behalten. `EnemyService` clont diese Models sobald vorhanden.


## Late Sea 1 (Frozen→Cap)

`SnowBandit` `Yeti` `IceWarden` · `Officer` `Elite` `ViceAdmiral` · `SkyBandit` `DarkMaster` `SkyKing` · `MagmaSoldier` `Spy` `MagmaAdmiral` · `FishWarrior` `Commando` `SeaBeast` · `Gladiator` `Toga` `ArenaChamp` · `GalleyPirate` `Captain` `CyborgFinale`

All R15 Toolbox/Marketplace — Scripts strippen.
