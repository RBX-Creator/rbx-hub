# Soul Fruits – Fundament (Overnight v1.9)

# Soul Fruits – Fundament (Overnight v1.8 / Scripter 2)

Studio-fertige Luau-Module: **DataStore, Fraktion, Level/Stats, Energy, Tag/Nacht, AntiCheat, Combat M1, Movement (Q/F), Gacha/Stock, Dreck + Wind/Flame/Ice/Light/Magma + Blutaugespiegel + **Sharingan (Mythical)**, HUD, Anim hooks**.

## v1.8 – Sharingan Mythical (strongest)

- **FruitsConfig**: `Sharingan` (**Mythical**, Element Auge, Stock **100000** — effectively gacha-primary); moves Z/X/C/V CH **50 / 65 / 75 / 110**; Special **R Partial Susanoo** CH **90**, CD **12s**; rarity weights Common 55 / Uncommon 30 / Rare 12 / Legendary **3** / Mythical **0.8** (gacha normalizes); Blutaugespiegel stays Legendary unchanged
- **Remotes**: `FruitSpecial` (C→S, key `"R"`) — **F remains flight for everyone** (never hijacked)
- **FruitService**: Sharingan kit — **Tomoe Burst**, **Genjutsu Lock** (`SF_GenjutsuLock` + stun), **Copy Glance** (Echo-like from `SF_LastM1Damage`), **Amaterasu** (lingering black-flame DoT); **R Partial Susanoo** (`SF_SusanooUntil` armor + small AoE, `VFX_Susanoo`); passive **`SF_SharinganSight`** while equipped; AntiCheat on `FruitSpecial`; Awakened stub boosts V/R slightly when `SharinganAwakened==true`
- **FruitController**: binds **R** → `FruitSpecial` when fruit has Special; Z/X/C/V unchanged
- **CombatService**: if `SF_SusanooUntil > tick()` reduce incoming M1 (~55% DR); optional `SF_TomoeM1` pulse on M1 hit when CurrentFruit is Sharingan
- Profile: `OwnedFruits.Sharingan`, `FruitMastery.Sharingan`, **`SharinganAwakened=false`** (Mangekyo stub — not fully implemented)
- Mesh ready at `/workspace/soul-fruits-assets/SharinganFruit.fbx` (**not** imported into Luau)
- Config mirrors: `FRUIT_SHARINGAN_*` costs + `VFX.Susanoo`

## v1.7 – Light / Magma move kits (Rare)

- **FruitsConfig**: full Z/X/C/V kits for **Light** (Rare, Beam/Flash/Barrage/Nova, CH **30/40/55/80**), **Magma** (Rare, Glob/Pool/Surge/Volcano, **32/42/58/85**); wired in `MovesByFruit` + `GetMoves`
- Stock: Light **2000**, Magma **2500** (between Ice/Flame 800 and Blutaugespiegel 28000)
- **FruitService**: Light — fast Beam ray, Flash brief `SF_IFramesUntil`, multi-hit Barrage, Nova AoE; Magma — Glob projectile + burn, lingering Pool DoT, Surge cone, Volcano AoE ticks; energy + CD + Gut≠Gut + `VFX_FruitZ|X|C|V`; mastery `FruitMastery.Light/Magma` + attrs `SF_LightMastery` / `SF_MagmaMastery`
- **CombatService**: respects `SF_IFramesUntil` (Light Flash) for M1
- **FruitController** already generic — no client change
- Meshes ready at `/workspace/soul-fruits-assets/LightFruit.fbx`, `MagmaFruit.fbx` (not imported into Luau)
- Config mirrors: `FRUIT_LIGHT_*`, `FRUIT_MAGMA_*` costs

## v1.6 – Wind / Flame / Ice move kits

- **FruitsConfig**: full Z/X/C/V kits for **Wind** (Common, Push/Slash/Gust/Tornado, CH **22/32/42/58**), **Flame** (Uncommon, Ball/Wave/Burst/Eruption, **25/35/45/65**), **Ice** (Uncommon, Spike/Freeze/Path/Prison, **25/35/48/70**); wired in `MovesByFruit` + `GetMoves`
- Stock prices unchanged & sensible: Wind **200**, Flame/Ice **800** (mid), Light/Magma 2500, Blutaugespiegel 28000
- **FruitService**: server kits — Wind knockback Push/Gust/Tornado, Flame burn DoT Ball/Wave/Burst/Eruption, Ice freeze/slow Spike/Freeze/Path/Prison; energy spend + CD + Gut≠Gut PvP + `VFX_FruitZ|X|C|V`; mastery via `FruitMastery[fruit]` + attrs `SF_WindMastery` / `SF_FlameMastery` / `SF_IceMastery`
- **OnFruitGranted** generalized for any `FruitsConfig` fruit (OwnedFruits + FruitMastery init + auto-equip if empty)
- **FruitController** already generic via `GetMoves` — no client change required
- Meshes ready at `/workspace/soul-fruits-assets/WindFruit.fbx`, `FlameFruit.fbx`, `IceFruit.fbx` (not imported into Luau)
- Config mirrors: `FRUIT_WIND_*`, `FRUIT_FLAME_*`, `FRUIT_ICE_*` costs

## v1.5 – Legendary Blutaugespiegel

- **FruitsConfig**: `Blutaugespiegel` (Legendary, Element Spiegel, Stock **28000** Coins); moves Z/X/C/V with CH costs **45 / 55 / 70 / 100**; `GetMoves(fruitId)`; gacha weight Legendary **3%** now rolls when present
- **FruitService**: `CurrentFruit=="Blutaugespiegel"` kit — **Spiegelblick** (StunMark/slow), **Echo-Schlag** (burst from `SF_LastM1Damage` or fixed), **Voraussicht** (`SF_ParryUntil`), **Blutspiegel-Welt** (AoE confusion + light DoT); mastery `BlutaugespiegelMastery` + `FruitMastery` map; PvP Gut≠Gut; AntiCheat on `FruitMove`
- **CombatService**: consume `SF_ParryUntil` once (heavy reduce); set `SF_LastM1Damage` on successful M1 for Echo
- **FruitController**: Z/X/C/V for **any** equipped fruit with moves (not only Dreck)
- Profile: `BlutaugespiegelMastery`, `FruitMastery` (Reconcile-safe); `OwnedFruits.Blutaugespiegel`
- Mesh ready at `/workspace/soul-fruits-assets/Blutaugespiegel.fbx` (not imported into Luau — config + gameplay stubs only)

## v1.4 – Gacha + Stock + Dreck Fruit (overnight / joint block)

- **FruitsConfig** (`Shared/FruitsConfig`): Early fruits (Dreck/Wind/Flame/Ice/Light/Magma), rarity weights 55/30/12/3, stock 3 slots / 4h, Dreck move costs Z20 X30 C40 V55
- **StockService**: 3 display fruits, `os.time` window refresh, buy with **Coins**, `StockBuy` + `StockUpdated` (S→C)
- **GachaService**: Weighted roll for **Splitz** (`GACHA_COST_SPLITZ=50`), `GachaRoll` + `GachaResult` (S→C); `DiceParts` on profile (default 0, reserved)
- **FruitService**: Equip attrs + **Dreck** moves Z Erdkugel / X Steinwurf / C Erdstoß / V Erdwall — EnergyService.Spend, per-move CD, hitbox/projectile stubs, `VFX_FruitZ|X|C|V`, `DreckMastery` +1, PvP Gut≠Gut like Combat
- **GachaUI** / **FruitController**: dark BF-ish Stock panel (key **G** or HUD button) + Z/X/C/V → `FruitMove`
- Profile: `DiceParts`, `CurrentFruit`, `DreckMastery`, `OwnedFruits`, `HatDreckFruit` (Reconcile-safe)
- Remotes neu: `StockBuy`, `GachaRoll`, `StockUpdated`, `GachaResult`, `FruitMove`
- AntiCheat.Validate auf allen neuen C→S Remotes

## v1.3 – Movement

- **Q** Dash: 15 Chakra, CD 1.2s, `VFX_Dash` / `SF_Dash` Attribute
- **F halten** Flug: 10 Chakra/s, Stopp bei 0, `VFX_Fly`, Speed ~48 (nicht overpowered)
- Kein Doppelsprung
- AntiCheat.Validate auch auf `ChooseFaction` + `AllocateStat`
- `Shared/AnimConfig` + `Client/AnimationController` — FBX-IDs nach Publish in `AnimConfig.Ids`

## v1.2 – AntiCheat + Combat M1 + HUD

- **AntiCheat**: `Validate(player, remoteName, opts) → boolean`
- **CombatService**: M1 4-Hit, Damage `8 + Melee * 0.5`, PvP Gut≠Gut
- **HUD**: HP/Chakra, Level, Stats allocate

## Import in Roblox Studio

Spiegle die Ordner 1:1:

| Repo-Pfad | Studio |
|-----------|--------|
| `ReplicatedStorage/SoulFruits/Shared/*.lua` | `ReplicatedStorage > SoulFruits > Shared` → **ModuleScripts** |
| `ServerScriptService/SoulFruits/Data/*.lua` | `ServerScriptService > SoulFruits > Data` → **ModuleScripts** |
| `ServerScriptService/SoulFruits/Systems/*.lua` | `ServerScriptService > SoulFruits > Systems` → **ModuleScripts** |
| `ServerScriptService/SoulFruits/Init.server.lua` | `ServerScriptService > SoulFruits` → **Script** `Init` |
| `StarterPlayerScripts/SoulFruits/Client/*.lua` | `StarterPlayer > StarterPlayerScripts > SoulFruits > Client` → **ModuleScripts** |
| `StarterPlayerScripts/SoulFruits/ClientBootstrap.client.lua` | `StarterPlayer > StarterPlayerScripts > SoulFruits` → **LocalScript** `ClientBootstrap` |

Oder: `rojo serve` mit `default.project.json`.

Remotes werden zur Laufzeit unter `ReplicatedStorage/SoulFruits/Remotes` erzeugt.

## Studio-Einstellungen

1. Game Settings → Security → **Enable Studio Access to API Services** (DataStore-Tests).
2. Place → R15 empfohlen.
3. Play Solo: Fraktions-UI + HUD erscheinen; Linksklick = M1.

## Wie testen (Studio Play Solo) — v1.8 path

1. Play → Fraktion wählen (Gut/Böse).
2. HUD: HP/Chakra, Level, Stats; **Q** Dash, **F** Flug bis Energy leer; LMB = M1.
3. **Gacha/Stock:** Taste **G** oder Button „Stock [G]“ → Panel mit 3 Slots + Gacha (zeigt Blutaugespiegel wenn im Stock / gezogen).
4. **Währungen für Test:** In `ProfileTemplate` temporär z. B. `Coins = 50000`, `Splitz = 500` setzen (Defaults sind 0), Place neu laden / neuen Slot-User nutzen.
5. Stock: **Dreck** kaufen (Coins) → `HatDreckFruit`, `CurrentFruit="Dreck"`, `OwnedFruits.Dreck`.
   Oder Gacha / Stock: **Blutaugespiegel** (Legendary, ~28000 Coins / 3% gacha) → `OwnedFruits.Blutaugespiegel`, equip `CurrentFruit="Blutaugespiegel"`.
6. Mit Dreck: **Z / X / C / V** → Chakra sinkt, `VFX_FruitZ` etc., `SF_DreckMastery` steigt.
6b. Mit **Wind** equipped (Stock ~200 / Common gacha):
   - **Z Push** (−22 CH): Projektil + Knockback
   - **X Slash** (−32 CH): Frontal-Slash
   - **C Gust** (−42 CH): Böen-Push
   - **V Tornado** (−58 CH): kleiner AoE-Tornado; `SF_WindMastery` / `FruitMastery.Wind`
6c. Mit **Flame** (Stock ~800 / Uncommon):
   - **Z Ball** (−25), **X Wave** (−35), **C Burst** (−45), **V Eruption** (−65) — Burn-DoT stubs; `SF_FlameMastery`
6d. Mit **Ice** (Stock ~800 / Uncommon):
   - **Z Spike** (−25), **X Freeze** (−35), **C Path** (−48), **V Prison** (−70) — Freeze/Slow (`SF_FreezeUntil`); `SF_IceMastery`
6e. Mit **Light** equipped (Stock ~2000 / Rare gacha):
   - **Z Beam** (−30 CH): schneller Ray/Strahl
   - **X Flash** (−40 CH): kurze i-Frames (`SF_IFramesUntil`)
   - **C Barrage** (−55 CH): Multi-Hit frontal
   - **V Nova** (−80 CH): Licht-AoE; `SF_LightMastery` / `FruitMastery.Light`
6f. Mit **Magma** (Stock ~2500 / Rare):
   - **Z Glob** (−32), **X Pool** (−42 lingering DoT), **C Surge** (−58), **V Volcano** (−85) — Lava/Burn feel; `SF_MagmaMastery`
7. Mit **Blutaugespiegel** equipped:
   - **Z Spiegelblick** (−45 CH): nächster Gegner im Kegel bekommt `SF_StunMark` + kurzer WalkSpeed-Slow
   - **X Echo-Schlag** (−55 CH): Frontal-Burst; nutzt `SF_LastM1Damage` nach M1-Treffer (sonst Fixed)
   - **C Voraussicht** (−70 CH): `SF_ParryUntil = tick()+2.5` — nächster M1-Treffer auf dich stark reduziert / verbraucht
   - **V Blutspiegel-Welt** (−100 CH): AoE um dich, Confusion-Slow + DoT-Ticks, `VFX_FruitV`
   - `SF_BlutaugespiegelMastery` / `FruitMastery.Blutaugespiegel` steigt
7b. Mit **Sharingan** equipped (Mythical ~0.8% gacha / Stock 100000):
   - Passive: `SF_SharinganSight=true` while equipped
   - **Z Tomoe Burst** (−50 CH): Frontal-Burst; `VFX_FruitZ`
   - **X Genjutsu Lock** (−65 CH): Stun/Lock-Mark (`SF_GenjutsuLock` / `SF_StunMark`)
   - **C Copy Glance** (−75 CH): Burst aus `SF_LastM1Damage` (sonst Fixed)
   - **V Amaterasu** (−110 CH): schwarzes Flammen-AoE DoT (`SF_AmaterasuUntil`, `VFX_FruitV`)
   - **R Partial Susanoo** (−90 CH, CD ~12s): `SF_SusanooUntil` DR + kleiner AoE, `VFX_Susanoo` — **F bleibt Flug**
   - M1 hit → optional `SF_TomoeM1` pulse; `FruitMastery.Sharingan` / `SF_SharinganMastery`
   - Profile stub: `SharinganAwakened=false` (Mangekyo later; if true, V/R leicht verstärkt)
8. PvP: zwei Clients beide **Gut** → Fruit-Schaden untereinander blockiert (wie M1); Gut vs Bose / NPCs OK.
9. Output: FruitService log `… + Sharingan Mythical`; Client `FruitController Z/X/C/V + R Special` (F = flight).

## Was steckt drin

- **DataManager**: Session-Load/Save, Autosave 60s, BindToClose, Reconcile
- **FactionService**: einmalig Gut / Bose
- **LevelService**: `AddXP`; 3 FreeStatPoints / Level; Cap 700
- **StatService**: `AllocateStat`; Leben→MaxHP, Chakra→MaxChakra
- **EnergyService**: Pool + Regen; `Spend` / `SetFlying` / `SetRunning`
- **DayNightService**: 10+10 Min, `workspace.SoulFruits_IsNight`
- **AntiCheat**: defensive Validate helpers
- **CombatService**: M1 combo + server hit detection
- **MovementService**: Q Dash + F Flight
- **StockService** / **GachaService** / **FruitService**: Shop, Roll, Dreck + Wind/Flame/Ice/Light/Magma + Blutaugespiegel + Sharingan (Mythical) abilities

## API für andere Scripter

```lua
local LevelService = require(ServerScriptService.SoulFruits.Systems.LevelService)
LevelService.AddXP(player, 100)

local EnergyService = require(...EnergyService)
EnergyService.Spend(player, 15) -- Dash
EnergyService.SetFlying(player, true) -- F hold

local AntiCheat = require(...AntiCheat)
if not AntiCheat.Validate(player, "AllocateStat", { cooldown = 0.1, maxArgs = 2 }) then return end

local FruitService = require(...FruitService)
if FruitService.HasDreck(player) then -- ...
```

### Combat / VFX / Fruit hooks

| Name | Bedeutung |
|------|-----------|
| `VFX_Dash` / `VFX_Fly` / `VFX_Hit` | Attribute auf Character (`tick()`) oder BindableEvent |
| `VFX_FruitZ` / `X` / `C` / `V` / `VFX_Susanoo` | Fruit ability hooks (server setzt `tick()`) inkl. Sharingan Susanoo |
| `SF_M1_Combo` | 1–4 auf Character + Player für Animator |
| `SF_CurrentFruit` / `SF_HatDreckFruit` / `SF_*Mastery` (inkl. `SF_SharinganMastery`) / `SF_SharinganAwakened` | Player attributes |
| `SF_IFramesUntil` | Light Flash brief invuln (tick deadline) |
| `SF_SharinganSight` / `SF_SusanooUntil` / `SF_GenjutsuLock` / `SF_AmaterasuUntil` / `SF_TomoeM1` | Sharingan passive / Susanoo DR / lock / DoT / M1 pulse |

Damage immer nur Server (`Humanoid:TakeDamage`). Kein Client-Trust. Keine erfundenen Asset-IDs.

### Config keys (Auswahl)

- `M1_*`, `DASH_*`, `FLIGHT_*`, AntiCheat thresholds
- `FRUIT_DRECK_Z_COST=20` … `V_COST=55` (gespiegelt in `FruitsConfig.DreckMoves`)
- `FRUIT_WIND_Z_COST=22` … `V_COST=58` / `FRUIT_FLAME_*=25/35/45/65` / `FRUIT_ICE_*=25/35/48/70`
- `FRUIT_LIGHT_*=30/40/55/80` / `FRUIT_MAGMA_*=32/42/58/85`
- `FRUIT_BLUT_Z_COST=45` … `V_COST=100` (gespiegelt in `FruitsConfig.BlutaugespiegelMoves`)
- `FRUIT_SHARINGAN_*=50/65/75/110` + `FRUIT_SHARINGAN_R_COST=90` (Special)
- Stock/Gacha Zahlen in `FruitsConfig` (Refresh 4h, weights 55/30/12/3/0.8, prices; Legendary Blutaugespiegel 28000, Mythical Sharingan 100000)

## XP-Kurve

Planer v1: `XPToNext(level) = math.floor(100 * level ^ 1.35 + 50)`.

## Animator overnight (v1.3+)

- `Shared/AnimConfig` + `Client/AnimationController` (ClientBootstrap)
- FBX-Quellen: `/workspace/soul-fruits-animations/fbx/` — IDs nach Publish in `AnimConfig.Ids`
- Dockt an `SF_M1_Combo`, `VFX_Dash`, `VFX_Fly` / `IsFlying`; Fruit-VFX bereit für späteren Animator-Pass


## v1.9 – Quests + Enemies + World Pads

**Leeam baut nur Inseln:** verschiebe die Parts unter `Workspace/SoulFruitsWorld`.

| Ordner | Inhalt |
|--------|--------|
| `EnemySpawns` | Pads mit `SF_EnemyType` (`Bandit`,`Affe`,`Gorilla`,`MobLeader`,`GorillaKing`) + optional `SF_MaxCount` |
| `QuestNPCs` | Models mit `SF_QuestId` (z.B. `starter_erste_schritte`) → ProximityPrompt |
| `Spots` | `SF_InteractId`: `Gacha`,`Stock`,`BoatVendor`,`HomePoint`,`SailOutlaw`,`Spawn` |
| `Enemies` | Live-Spawns (auto) |
| `ReplicatedStorage/SoulFruits/EnemyTemplates` | Optional: echte Meshes namens wie EnemyType |

Systeme: `QuestService`, `EnemyService`, `WorldBootstrap`, Client `QuestUI`.
Kill-Quests wiederholbar; Talk/Find/Sail einmalig laut Config.

**Test:** Play Solo → Faction → NPC Erste Schritte → Banditen paddeln → Tracker füllt sich → XP/Coins.


## v1.9.1 – BF-Combat-Feel + Mob-Templates

- M1 näher an Blox Fruits **Feel** (eigenes Timing): schneller Swing, Stun-Weave (`SF_StunUntil`), Hit-4 Knockback, kurzer Lunge
- Stun blockiert Dash/Flug/M1 kurz
- Mob-FBX: `/workspace/soul-fruits-assets/mobs/` → nach Studio-Import als Models in `EnemyTemplates/` (Namen = EnemyType)
- Kein Copy von Blox-Fruits-Scripts (IP) — nur vergleichbares Gameplay-Feel


## v1.9.2 – Outlaw Config + R15 Enemy IDs

- Enemies: `Outlaw`, `Brute`, `ClownCaptain` (+ Stats)
- Quests: Gesetzlose → Brutale Bande → Clown Captain → Weitersegeln
- Affe/Gorilla/GorillaKing bleiben **IDs**, Optik R15 Brawler (Scale bei Heavy/King)
- Pads unter `SoulFruitsWorld/EnemySpawns` vorbereitet


## v1.9.3 – Desert Island

- Enemies: `DesertBandit`, `DesertOfficer`, `SandKing`
- Quests: Sandräuber → Offiziere → Sandkönig → Weitersegeln (Frozen)
- Pads + NPC + `SailFrozen` Spot in WorldBootstrap


## v1.10 – Physical Fruits (Blox Fruits Flow)

1. **Gacha (G) / Stock** → physisches **Tool** + Spin (`VFX_FruitSpin` / `FruitSpin`)
2. **E** = essen (`SF_FruitEat` / `FruitEatFX`) → `CurrentFruit` aktiv, Z/X/C/V nutzbar
3. **B** = lagern (1 Slot pro Fruit-Typ) · Storage-UI · **N** / Klick = holen
4. Neue Fruit essen **ersetzt** die aktuelle; Mastery pro Typ bleibt
5. Kein Auto-Equip mehr beim Kauf/Roll

Animator: Eat-Anim an `SF_FruitEat`. VFX: Spin-Glow + Eat-Burst.


## v1.11 – Frozen → Cap City (Sea 1 complete tables)

Enemies + Quests + Pads for: Frozen, Fortress, Sky, Magma, Underwater, Arena, Cap City.
Sail spots: `SailFortress` `SailSky` `SailMagma` `SailUnderwater` `SailArena` `SailCapCity`.
Sea-1-Finale: `cap_cyborg_finale` / `CyborgFinale`.
