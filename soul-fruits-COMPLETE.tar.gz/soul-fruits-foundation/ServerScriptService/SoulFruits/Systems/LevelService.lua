--!strict
--[[
	LevelService – XP / Level-Ups (server-only API).
	Studio: ServerScriptService/SoulFruits/Systems/LevelService (ModuleScript)

	XP-Kurve v1 (Planer): math.floor(100 * level ^ 1.35 + 50)
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Shared = ReplicatedStorage:WaitForChild("SoulFruits"):WaitForChild("Shared")
local Config = require(Shared:WaitForChild("Config"))

local DataManager = require(script.Parent.Parent.Data:WaitForChild("DataManager"))

local LevelService = {}

function LevelService.XPToNext(level: number): number
	-- Planer XP-Kurve v1
	return math.floor(100 * level ^ 1.35 + 50)
end

--- Server-only: add XP and process level-ups. Returns new level.
function LevelService.AddXP(player: Player, amount: number): number?
	if typeof(amount) ~= "number" or amount ~= amount or amount <= 0 then
		return nil
	end
	amount = math.floor(amount)

	local newLevel: number? = nil
	DataManager.Update(player, function(profile)
		if profile.Level >= Config.MAX_LEVEL then
			newLevel = profile.Level
			return
		end

		profile.XP += amount
		while profile.Level < Config.MAX_LEVEL do
			local need = LevelService.XPToNext(profile.Level)
			if profile.XP < need then
				break
			end
			profile.XP -= need
			profile.Level += 1
			profile.FreeStatPoints += Config.STAT_POINTS_PER_LEVEL
		end
		if profile.Level >= Config.MAX_LEVEL then
			profile.XP = 0
		end
		newLevel = profile.Level
	end)
	return newLevel
end

function LevelService.Start()
	-- no remotes: XP only via server APIs (quests later)
end

return LevelService
