--!strict
--[[
	AntiCheat – defensive remote validation skeleton (Server-Authority).
	Rate-limits, type/range checks, soft kick on suspicious patterns.
	Studio: ServerScriptService/SoulFruits/Systems/AntiCheat (ModuleScript)

	Usage (CombatService / later StatService / FactionService):
		if not AntiCheat.Validate(player, "CombatM1", { cooldown = 0.2, maxArgs = 1 }) then return end
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Shared = ReplicatedStorage:WaitForChild("SoulFruits"):WaitForChild("Shared")
local Config = require(Shared:WaitForChild("Config"))

export type ValidateOpts = {
	cooldown: number?, -- min seconds between accepted fires for this remote
	maxPerSecond: number?, -- soft ignore if exceeded (default Config)
	maxArgs: number?, -- max extra args after player (informational; caller still checks)
	argTypes: { string }?, -- expected typeof for each arg: "number" | "string" | "boolean" | "nil" | "any"
	argRanges: { { min: number?, max: number? }? }?, -- for number args
	allowNilArgs: boolean?,
}

type RemoteBucket = {
	lastAccept: number,
	windowStart: number,
	windowCount: number,
}

type PlayerState = {
	remotes: { [string]: RemoteBucket },
	suspicious: number,
}

local AntiCheat = {}
local states: { [Player]: PlayerState } = {}
local started = false

local ATTR_SUSPICIOUS = "SF_AC_Suspicious"
local ATTR_LAST_REMOTE = "SF_AC_LastRemote"

local function ensure(player: Player): PlayerState
	local state = states[player]
	if not state then
		state = {
			remotes = {},
			suspicious = (player:GetAttribute(ATTR_SUSPICIOUS) :: number?) or 0,
		}
		states[player] = state
	end
	return state
end

local function bumpSuspicious(player: Player, state: PlayerState, reason: string)
	state.suspicious += 1
	player:SetAttribute(ATTR_SUSPICIOUS, state.suspicious)
	player:SetAttribute(ATTR_LAST_REMOTE, reason)
	if state.suspicious >= Config.ANTICHEAT_SOFT_KICK_THRESHOLD then
		warn(("[SoulFruits.AntiCheat] Soft-kick %s (%d) — %s"):format(player.Name, player.UserId, reason))
		player:Kick("Zu viele ungültige Aktionen. Bitte erneut joinen.")
	end
end

local function getBucket(state: PlayerState, remoteName: string): RemoteBucket
	local bucket = state.remotes[remoteName]
	if not bucket then
		bucket = {
			lastAccept = 0,
			windowStart = os.clock(),
			windowCount = 0,
		}
		state.remotes[remoteName] = bucket
	end
	return bucket
end

--- Returns true if the fire is allowed. False = ignore (do not process).
function AntiCheat.Validate(player: Player, remoteName: string, opts: ValidateOpts?, ...: any): boolean
	if typeof(player) ~= "Instance" or not player:IsA("Player") or player.Parent == nil then
		return false
	end
	if typeof(remoteName) ~= "string" or remoteName == "" then
		return false
	end

	local options: ValidateOpts = opts or {}
	local state = ensure(player)
	local now = os.clock()
	local bucket = getBucket(state, remoteName)

	-- Per-second window
	local maxPerSec = options.maxPerSecond or Config.ANTICHEAT_MAX_REMOTE_PER_SEC
	if now - bucket.windowStart >= 1 then
		bucket.windowStart = now
		bucket.windowCount = 0
	end
	bucket.windowCount += 1
	if bucket.windowCount > maxPerSec then
		bumpSuspicious(player, state, remoteName .. ":rate")
		return false
	end

	-- Cooldown between accepted fires
	local cd = options.cooldown or Config.ANTICHEAT_DEFAULT_COOLDOWN
	if cd > 0 and (now - bucket.lastAccept) < cd then
		-- Soft ignore — do not always count as suspicious (legit spam from lag)
		if (now - bucket.lastAccept) < (cd * 0.25) then
			bumpSuspicious(player, state, remoteName .. ":cd")
		end
		return false
	end

	-- Argument type / range validation (extra args passed via ...)
	local args = { ... }
	if options.maxArgs ~= nil and #args > options.maxArgs then
		bumpSuspicious(player, state, remoteName .. ":args")
		return false
	end

	if options.argTypes then
		for i, expected in options.argTypes do
			local value = args[i]
			if expected == "any" then
				continue
			end
			if expected == "nil" then
				if value ~= nil then
					bumpSuspicious(player, state, remoteName .. ":type")
					return false
				end
				continue
			end
			if value == nil then
				if options.allowNilArgs then
					continue
				end
				bumpSuspicious(player, state, remoteName .. ":nil")
				return false
			end
			if typeof(value) ~= expected then
				bumpSuspicious(player, state, remoteName .. ":type")
				return false
			end
			if expected == "number" then
				if value ~= value then -- NaN
					bumpSuspicious(player, state, remoteName .. ":nan")
					return false
				end
				local range = if options.argRanges then options.argRanges[i] else nil
				if range then
					if range.min ~= nil and value < range.min then
						bumpSuspicious(player, state, remoteName .. ":range")
						return false
					end
					if range.max ~= nil and value > range.max then
						bumpSuspicious(player, state, remoteName .. ":range")
						return false
					end
				end
			end
		end
	end

	bucket.lastAccept = now
	return true
end

function AntiCheat.GetSuspicious(player: Player): number
	return ensure(player).suspicious
end

function AntiCheat.ResetPlayer(player: Player)
	states[player] = nil
	pcall(function()
		player:SetAttribute(ATTR_SUSPICIOUS, 0)
		player:SetAttribute(ATTR_LAST_REMOTE, "")
	end)
end

function AntiCheat.Start()
	if started then
		return
	end
	started = true

	Players.PlayerRemoving:Connect(function(player)
		states[player] = nil
	end)

	print("[SoulFruits.AntiCheat] Rate-limit / Validate ready (defensive only)")
end

return AntiCheat
