--!strict
--[[
	WorldBootstrap – legt Workspace/SoulFruitsWorld Ordner + Beispiel-Pads an,
	falls noch nicht vorhanden. Leeam ersetzt/verschiebt Pads auf echte Inseln.
	Studio: ServerScriptService/SoulFruits/Systems/WorldBootstrap (ModuleScript)
]]

local CollectionService = game:GetService("CollectionService")

local WorldBootstrap = {}
local started = false

local function ensureFolder(parent: Instance, name: string): Folder
	local f = parent:FindFirstChild(name)
	if f and f:IsA("Folder") then
		return f
	end
	local folder = Instance.new("Folder")
	folder.Name = name
	folder.Parent = parent
	return folder
end

local function makePad(parent: Instance, name: string, position: Vector3, color: Color3): Part
	local existing = parent:FindFirstChild(name)
	if existing and existing:IsA("BasePart") then
		return existing
	end
	local p = Instance.new("Part")
	p.Name = name
	p.Anchored = true
	p.Size = Vector3.new(6, 1, 6)
	p.Position = position
	p.Color = color
	p.Material = Enum.Material.Neon
	p.Transparency = 0.35
	p.Parent = parent
	return p
end

local function makeNpcMarker(parent: Instance, name: string, position: Vector3, questId: string): Model
	local existing = parent:FindFirstChild(name)
	if existing and existing:IsA("Model") then
		return existing
	end
	local model = Instance.new("Model")
	model.Name = name
	local part = Instance.new("Part")
	part.Name = "Torso"
	part.Size = Vector3.new(2, 5, 1)
	part.Anchored = true
	part.Position = position
	part.Color = Color3.fromRGB(80, 140, 220)
	part.Parent = model
	model.PrimaryPart = part
	model:SetAttribute("SF_QuestId", questId)
	CollectionService:AddTag(model, "SF_QuestGiver")
	model.Parent = parent
	return model
end

local function makeInteract(parent: Instance, name: string, position: Vector3, interactId: string, color: Color3): Part
	local p = makePad(parent, name, position, color)
	p:SetAttribute("SF_InteractId", interactId)
	CollectionService:AddTag(p, "SF_Interact")
	return p
end

function WorldBootstrap.Start()
	if started then
		return
	end
	started = true

	local world = ensureFolder(workspace, "SoulFruitsWorld")
	local enemySpawns = ensureFolder(world, "EnemySpawns")
	local enemies = ensureFolder(world, "Enemies")
	local questNpcs = ensureFolder(world, "QuestNPCs")
	local spots = ensureFolder(world, "Spots")
	ensureFolder(world, "HomePoints")

	-- Example pads near 0,0,0 — Leeam moves these onto islands
	local banditPad = makePad(enemySpawns, "Pad_Bandit_1", Vector3.new(20, 1, 0), Color3.fromRGB(160, 100, 60))
	banditPad:SetAttribute("SF_EnemyType", "Bandit")
	banditPad:SetAttribute("SF_MaxCount", 3)
	CollectionService:AddTag(banditPad, "SF_EnemySpawn")

	local affePad = makePad(enemySpawns, "Pad_Affe_1", Vector3.new(40, 1, 20), Color3.fromRGB(120, 90, 40))
	affePad:SetAttribute("SF_EnemyType", "Affe")
	affePad:SetAttribute("SF_MaxCount", 2)
	CollectionService:AddTag(affePad, "SF_EnemySpawn")

	local gorillaPad = makePad(enemySpawns, "Pad_Gorilla_1", Vector3.new(60, 1, 20), Color3.fromRGB(70, 70, 80))
	gorillaPad:SetAttribute("SF_EnemyType", "Gorilla")
	gorillaPad:SetAttribute("SF_MaxCount", 1)
	CollectionService:AddTag(gorillaPad, "SF_EnemySpawn")

	local bossPad = makePad(enemySpawns, "Pad_MobLeader", Vector3.new(25, 1, -20), Color3.fromRGB(180, 40, 40))
	bossPad:SetAttribute("SF_EnemyType", "MobLeader")
	bossPad:SetAttribute("SF_MaxCount", 1)
	CollectionService:AddTag(bossPad, "SF_EnemySpawn")

	local outlawPad = makePad(enemySpawns, "Pad_Outlaw_1", Vector3.new(90, 1, 0), Color3.fromRGB(140, 50, 50))
	outlawPad:SetAttribute("SF_EnemyType", "Outlaw")
	outlawPad:SetAttribute("SF_MaxCount", 3)
	CollectionService:AddTag(outlawPad, "SF_EnemySpawn")

	local brutePad = makePad(enemySpawns, "Pad_Brute_1", Vector3.new(100, 1, 10), Color3.fromRGB(100, 30, 30))
	brutePad:SetAttribute("SF_EnemyType", "Brute")
	brutePad:SetAttribute("SF_MaxCount", 2)
	CollectionService:AddTag(brutePad, "SF_EnemySpawn")

	local clownPad = makePad(enemySpawns, "Pad_ClownCaptain", Vector3.new(110, 1, -10), Color3.fromRGB(220, 40, 90))
	clownPad:SetAttribute("SF_EnemyType", "ClownCaptain")
	clownPad:SetAttribute("SF_MaxCount", 1)
	CollectionService:AddTag(clownPad, "SF_EnemySpawn")

	local desertBandit = makePad(enemySpawns, "Pad_DesertBandit_1", Vector3.new(140, 1, 0), Color3.fromRGB(210, 180, 90))
	desertBandit:SetAttribute("SF_EnemyType", "DesertBandit")
	desertBandit:SetAttribute("SF_MaxCount", 3)
	CollectionService:AddTag(desertBandit, "SF_EnemySpawn")

	local desertOfficer = makePad(enemySpawns, "Pad_DesertOfficer_1", Vector3.new(150, 1, 10), Color3.fromRGB(190, 150, 70))
	desertOfficer:SetAttribute("SF_EnemyType", "DesertOfficer")
	desertOfficer:SetAttribute("SF_MaxCount", 2)
	CollectionService:AddTag(desertOfficer, "SF_EnemySpawn")

	local sandKing = makePad(enemySpawns, "Pad_SandKing", Vector3.new(160, 1, -10), Color3.fromRGB(230, 190, 50))
	sandKing:SetAttribute("SF_EnemyType", "SandKing")
	sandKing:SetAttribute("SF_MaxCount", 1)
	CollectionService:AddTag(sandKing, "SF_EnemySpawn")

	makeInteract(spots, "Spot_SailFrozen", Vector3.new(155, 1, -25), "SailFrozen", Color3.fromRGB(160, 210, 255))

	makeNpcMarker(questNpcs, "NPC_ErsteSchritte", Vector3.new(0, 3, 12), "starter_erste_schritte")
	makeNpcMarker(questNpcs, "NPC_MehrUebung", Vector3.new(4, 3, 12), "starter_mehr_uebung")
	makeNpcMarker(questNpcs, "NPC_Affenplage", Vector3.new(40, 3, 28), "jungle_affenplage")
	makeNpcMarker(questNpcs, "NPC_Gesetzlose", Vector3.new(90, 3, 12), "outlaw_kill_outlaws")
	makeNpcMarker(questNpcs, "NPC_Sandraeuber", Vector3.new(140, 3, 12), "desert_sandraeuber")

	makeInteract(spots, "Spot_Spawn", Vector3.new(0, 1, 0), "Spawn", Color3.fromRGB(100, 200, 100))
	makeInteract(spots, "Spot_Gacha", Vector3.new(-15, 1, 10), "Gacha", Color3.fromRGB(200, 160, 40))
	makeInteract(spots, "Spot_Stock", Vector3.new(-15, 1, 18), "Stock", Color3.fromRGB(160, 120, 40))
	makeInteract(spots, "Spot_BoatVendor", Vector3.new(10, 1, -15), "BoatVendor", Color3.fromRGB(60, 120, 200))
	makeInteract(spots, "Spot_HomePoint", Vector3.new(-8, 1, -8), "HomePoint", Color3.fromRGB(180, 80, 180))
	makeInteract(spots, "Spot_SailOutlaw", Vector3.new(15, 1, -25), "SailOutlaw", Color3.fromRGB(40, 80, 160))

	-- Enemy template folder for Blender meshes later
	local rs = game:GetService("ReplicatedStorage")
	local sf = rs:FindFirstChild("SoulFruits")
	if sf then
		local templates = sf:FindFirstChild("EnemyTemplates")
		if not templates then
			templates = Instance.new("Folder")
			templates.Name = "EnemyTemplates"
			templates.Parent = sf
		end
	end


	-- Frozen → Cap City pads (Leeam moves onto islands)
	local late = {
		{ "Pad_SnowBandit_1", "SnowBandit", 200, 0, 3, Color3.fromRGB(200, 220, 255) },
		{ "Pad_Yeti_1", "Yeti", 210, 10, 2, Color3.fromRGB(230, 240, 255) },
		{ "Pad_IceWarden", "IceWarden", 220, -10, 1, Color3.fromRGB(140, 200, 255) },
		{ "Pad_Officer_1", "Officer", 260, 0, 3, Color3.fromRGB(40, 70, 140) },
		{ "Pad_Elite_1", "Elite", 270, 10, 2, Color3.fromRGB(30, 50, 110) },
		{ "Pad_ViceAdmiral", "ViceAdmiral", 280, -10, 1, Color3.fromRGB(20, 40, 100) },
		{ "Pad_SkyBandit_1", "SkyBandit", 320, 0, 3, Color3.fromRGB(220, 210, 160) },
		{ "Pad_DarkMaster_1", "DarkMaster", 330, 10, 2, Color3.fromRGB(60, 40, 80) },
		{ "Pad_SkyKing", "SkyKing", 340, -10, 1, Color3.fromRGB(255, 230, 120) },
		{ "Pad_MagmaSoldier_1", "MagmaSoldier", 380, 0, 3, Color3.fromRGB(220, 80, 30) },
		{ "Pad_Spy_1", "Spy", 390, 10, 2, Color3.fromRGB(80, 80, 90) },
		{ "Pad_MagmaAdmiral", "MagmaAdmiral", 400, -10, 1, Color3.fromRGB(255, 60, 20) },
		{ "Pad_FishWarrior_1", "FishWarrior", 440, 0, 3, Color3.fromRGB(40, 120, 160) },
		{ "Pad_Commando_1", "Commando", 450, 10, 2, Color3.fromRGB(30, 90, 130) },
		{ "Pad_SeaBeast", "SeaBeast", 460, -10, 1, Color3.fromRGB(20, 60, 100) },
		{ "Pad_Gladiator_1", "Gladiator", 500, 0, 3, Color3.fromRGB(180, 120, 60) },
		{ "Pad_Toga_1", "Toga", 510, 10, 2, Color3.fromRGB(220, 200, 180) },
		{ "Pad_ArenaChamp", "ArenaChamp", 520, -10, 1, Color3.fromRGB(200, 40, 40) },
		{ "Pad_GalleyPirate_1", "GalleyPirate", 560, 0, 3, Color3.fromRGB(100, 70, 50) },
		{ "Pad_Captain_1", "Captain", 570, 10, 2, Color3.fromRGB(80, 40, 40) },
		{ "Pad_CyborgFinale", "CyborgFinale", 580, -10, 1, Color3.fromRGB(120, 140, 160) },
	}
	for _, row in late do
		local pad = makePad(enemySpawns, row[1], Vector3.new(row[3], 1, row[4]), row[6])
		pad:SetAttribute("SF_EnemyType", row[2])
		pad:SetAttribute("SF_MaxCount", row[5])
		CollectionService:AddTag(pad, "SF_EnemySpawn")
	end

	makeNpcMarker(questNpcs, "NPC_Schneebanditen", Vector3.new(200, 3, 12), "frozen_schneebanditen")
	makeNpcMarker(questNpcs, "NPC_OffiziereFort", Vector3.new(260, 3, 12), "fortress_officers")
	makeNpcMarker(questNpcs, "NPC_Himmelsbanditen", Vector3.new(320, 3, 12), "sky_bandits")
	makeNpcMarker(questNpcs, "NPC_MagmaSoldaten", Vector3.new(380, 3, 12), "magma_soldiers")
	makeNpcMarker(questNpcs, "NPC_FishWarriors", Vector3.new(440, 3, 12), "uw_fish_warriors")
	makeNpcMarker(questNpcs, "NPC_Gladiatoren", Vector3.new(500, 3, 12), "arena_gladiators")
	makeNpcMarker(questNpcs, "NPC_Galley", Vector3.new(560, 3, 12), "cap_galley")

	makeInteract(spots, "Spot_SailFortress", Vector3.new(215, 1, -25), "SailFortress", Color3.fromRGB(100, 140, 200))
	makeInteract(spots, "Spot_SailSky", Vector3.new(275, 1, -25), "SailSky", Color3.fromRGB(240, 230, 180))
	makeInteract(spots, "Spot_SailMagma", Vector3.new(335, 1, -25), "SailMagma", Color3.fromRGB(255, 100, 40))
	makeInteract(spots, "Spot_SailUnderwater", Vector3.new(395, 1, -25), "SailUnderwater", Color3.fromRGB(40, 120, 180))
	makeInteract(spots, "Spot_SailArena", Vector3.new(455, 1, -25), "SailArena", Color3.fromRGB(200, 160, 80))
	makeInteract(spots, "Spot_SailCapCity", Vector3.new(515, 1, -25), "SailCapCity", Color3.fromRGB(180, 180, 200))

	print("[SoulFruits.World] SoulFruitsWorld templates ready (Sea1 full pads) — move onto islands")
end

return WorldBootstrap
