--!strict
--[[
	CombatService – Server-authoritative M1 melee combo (4 hits, 0 energy).
	Hit detection on server only; client never computes damage.
	Parry hook: SF_ParryUntil (Blutaugespiegel Voraussicht).
	Susanoo DR: SF_SusanooUntil (Sharingan Partial Susanoo).
	Tomoe M1 pulse when CurrentFruit == Sharingan.
	Studio: ServerScriptService/SoulFruits/Systems/CombatService (ModuleScript)
]]

local Players = game:GetService("Players")
local Workspace = game:GetService("Workspace")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Shared = ReplicatedStorage:WaitForChild("SoulFruits"):WaitForChild("Shared")
local Config = require(Shared:WaitForChild("Config"))
local Remotes = require(Shared:WaitForChild("Remotes"))

local DataManager = require(script.Parent.Parent.Data:WaitForChild("DataManager"))
local AntiCheat = require(script.Parent:WaitForChild("AntiCheat"))
local EnemyService = require(script.Parent:WaitForChild("EnemyService"))

type ComboState = {
	index: number, -- last completed hit 0..4
	lastSwingAt: number,
}

local CombatService = {}
local combos: { [Player]: ComboState } = {}
local started = false

local ATTR_COMBO = "SF_M1_Combo"
local ATTR_FLYING = "IsFlying"
local ATTR_PARRY_UNTIL = "SF_ParryUntil"
local ATTR_IFRAMES = "SF_IFramesUntil"
local ATTR_LAST_M1 = "SF_LastM1Damage"
local ATTR_SUSANOO_UNTIL = "SF_SusanooUntil"
local ATTR_TOMOE_M1 = "SF_TomoeM1"
local ATTR_STUN_UNTIL = "SF_StunUntil"
local PARRY_REDUCE_FACTOR = 0.1 -- nearly negate
local SUSANOO_REDUCE_FACTOR = 0.45 -- ~55% damage reduction while armored

local function getCombo(player: Player): ComboState
	local state = combos[player]
	if not state then
		state = { index = 0, lastSwingAt = 0 }
		combos[player] = state
	end
	return state
end

local function getFaction(player: Player): string?
	local data = DataManager.Get(player)
	if data and data.Faction then
		return data.Faction
	end
	local attr = player:GetAttribute("SF_Faction")
	if typeof(attr) == "string" then
		return attr
	end
	return nil
end

--- Gut may not damage Gut players; Gut may hit Bose + NPCs. Bose hits all.
local function canDamage(attacker: Player, targetHumanoid: Humanoid): boolean
	local targetChar = targetHumanoid.Parent
	if not targetChar or not targetChar:IsA("Model") then
		return false
	end
	local targetPlayer = Players:GetPlayerFromCharacter(targetChar)
	if not targetPlayer then
		return true -- NPC / world humanoid
	end
	if targetPlayer == attacker then
		return false
	end

	local atkFaction = getFaction(attacker)
	local tgtFaction = getFaction(targetPlayer)
	if atkFaction == Config.FACTIONS.Gut and tgtFaction == Config.FACTIONS.Gut then
		return false
	end
	return true
end

local function computeDamage(attacker: Player): number
	local melee = 0
	local data = DataManager.Get(attacker)
	if data and data.Stats then
		melee = data.Stats.Melee or 0
	end
	return Config.M1_BASE_DAMAGE + melee * Config.M1_MELEE_FACTOR
end

local function fireVfxHit(character: Model)
	local name = Config.VFX.Hit
	character:SetAttribute(name, tick())
	local be = character:FindFirstChild(name)
	if be and be:IsA("BindableEvent") then
		be:Fire()
	end
end

local function getRoot(character: Model): BasePart?
	local hrp = character:FindFirstChild("HumanoidRootPart")
	if hrp and hrp:IsA("BasePart") then
		return hrp
	end
	local primary = character.PrimaryPart
	if primary then
		return primary
	end
	return nil
end

--- If target (or attacker) has active SF_ParryUntil, consume once and heavily reduce.
local function resolveParry(attacker: Player, targetModel: Model, damage: number): number
	local now = tick()
	local targetPlayer = Players:GetPlayerFromCharacter(targetModel)

	local function clearParry(plr: Player?, model: Model)
		if plr then
			plr:SetAttribute(ATTR_PARRY_UNTIL, 0)
		end
		model:SetAttribute(ATTR_PARRY_UNTIL, 0)
	end

	-- Defender parry (primary)
	local defUntil = if targetPlayer then targetPlayer:GetAttribute(ATTR_PARRY_UNTIL) else targetModel:GetAttribute(ATTR_PARRY_UNTIL)
	if typeof(defUntil) ~= "number" then
		defUntil = targetModel:GetAttribute(ATTR_PARRY_UNTIL)
	end
	if typeof(defUntil) == "number" and defUntil > now then
		clearParry(targetPlayer, targetModel)
		return damage * PARRY_REDUCE_FACTOR
	end

	-- Light Flash i-frames (do not consume early; duration-based)
	local iframes = if targetPlayer then targetPlayer:GetAttribute(ATTR_IFRAMES) else targetModel:GetAttribute(ATTR_IFRAMES)
	if typeof(iframes) ~= "number" then
		iframes = targetModel:GetAttribute(ATTR_IFRAMES)
	end
	if typeof(iframes) == "number" and iframes > now then
		return 0
	end

	-- Attacker parry window (edge case from plan: attacker/target)
	local atkUntil = attacker:GetAttribute(ATTR_PARRY_UNTIL)
	local atkChar = attacker.Character
	if typeof(atkUntil) == "number" and atkUntil > now then
		clearParry(attacker, if atkChar then atkChar else targetModel)
		-- Attacker mid-parry still deals full; only defender blocks. No-op for damage.
	end

	return damage
end

--- Server hitbox: GetPartBoundsInBox in front of character (~M1_RANGE).
local function collectHitHumanoids(attacker: Player, character: Model): { Humanoid }
	local root = getRoot(character)
	if not root then
		return {}
	end

	local look = root.CFrame.LookVector
	local center = root.Position + look * (Config.M1_RANGE * 0.5)
	local cf = CFrame.lookAt(center, center + look)
	local size = Config.M1_HITBOX_SIZE

	local overlap = OverlapParams.new()
	overlap.FilterType = Enum.RaycastFilterType.Exclude
	overlap.FilterDescendantsInstances = { character }
	overlap.MaxParts = 32

	local parts = Workspace:GetPartBoundsInBox(cf, size, overlap)
	local seen: { [Humanoid]: boolean } = {}
	local results: { Humanoid } = {}

	for _, part in parts do
		local model = part:FindFirstAncestorOfClass("Model")
		if not model then
			continue
		end
		local humanoid = model:FindFirstChildOfClass("Humanoid")
		if humanoid and humanoid.Health > 0 and not seen[humanoid] then
			seen[humanoid] = true
			if canDamage(attacker, humanoid) then
				table.insert(results, humanoid)
			end
		end
	end
	return results
end

local function handleM1(player: Player, comboIndexHint: any?)
	if not AntiCheat.Validate(player, "CombatM1", {
		cooldown = Config.M1_SWING_COOLDOWN * 0.5,
		maxPerSecond = 8,
		maxArgs = 1,
		argTypes = { "number" },
		argRanges = { { min = 1, max = Config.M1_HIT_COUNT } },
		allowNilArgs = true,
	}, comboIndexHint) then
		return
	end

	if comboIndexHint ~= nil and typeof(comboIndexHint) ~= "number" then
		return
	end

	local character = player.Character
	if not character then
		return
	end
	local humanoid = character:FindFirstChildOfClass("Humanoid")
	if not humanoid or humanoid.Health <= 0 then
		return
	end

	if player:GetAttribute(ATTR_FLYING) == true then
		return
	end

	local now = os.clock()
	local state = getCombo(player)

	if (now - state.lastSwingAt) < Config.M1_SWING_COOLDOWN then
		return
	end

	if state.index > 0 and (now - state.lastSwingAt) > Config.M1_COMBO_WINDOW then
		state.index = 0
	end

	local nextIndex = state.index + 1
	if nextIndex > Config.M1_HIT_COUNT then
		nextIndex = 1
	end

	state.index = nextIndex
	state.lastSwingAt = now

	character:SetAttribute(ATTR_COMBO, nextIndex)
	player:SetAttribute(ATTR_COMBO, nextIndex)

	-- Short BF-style forward lunge (server)
	local root = getRoot(character)
	if root then
		local flat = Vector3.new(root.CFrame.LookVector.X, 0, root.CFrame.LookVector.Z)
		if flat.Magnitude > 0.05 then
			flat = flat.Unit
			local v = root.AssemblyLinearVelocity
			root.AssemblyLinearVelocity = Vector3.new(flat.X * Config.M1_LUNGE_SPEED, v.Y, flat.Z * Config.M1_LUNGE_SPEED)
		end
	end

	local damage = computeDamage(player)
	local hits = collectHitHumanoids(player, character)
	local didHit = false
	local lastApplied = 0
	for _, targetHum in hits do
		local targetModel = targetHum.Parent
		local applied = damage
		if targetModel and targetModel:IsA("Model") then
			applied = resolveParry(player, targetModel, damage)
			-- Partial Susanoo armor on defender
			local tgtPlayer = Players:GetPlayerFromCharacter(targetModel)
			local susUntil = if tgtPlayer then tgtPlayer:GetAttribute(ATTR_SUSANOO_UNTIL) else targetModel:GetAttribute(ATTR_SUSANOO_UNTIL)
			if typeof(susUntil) ~= "number" then
				susUntil = targetModel:GetAttribute(ATTR_SUSANOO_UNTIL)
			end
			if typeof(susUntil) == "number" and susUntil > tick() and applied > 0 then
				applied = applied * SUSANOO_REDUCE_FACTOR
			end
		end
		if applied > 0.05 then
			EnemyService.TagDamage(targetHum, player)
			targetHum:TakeDamage(applied)
			-- Stun weave (BF-ähnlich): hält Combos zusammen
			local stunDur = if nextIndex >= Config.M1_HIT_COUNT then Config.M1_FINISHER_STUN else Config.M1_STUN_PER_HIT
			local untilT = tick() + stunDur
			targetHum:SetAttribute(ATTR_STUN_UNTIL, untilT)
			if targetModel and targetModel:IsA("Model") then
				targetModel:SetAttribute(ATTR_STUN_UNTIL, untilT)
				local tgtPlr = Players:GetPlayerFromCharacter(targetModel)
				if tgtPlr then
					tgtPlr:SetAttribute(ATTR_STUN_UNTIL, untilT)
				end
				-- Finisher knockback
				if nextIndex >= Config.M1_HIT_COUNT then
					local tRoot = targetModel:FindFirstChild("HumanoidRootPart")
					local aRoot = getRoot(character)
					if tRoot and tRoot:IsA("BasePart") and aRoot then
						local dir = (tRoot.Position - aRoot.Position)
						dir = Vector3.new(dir.X, 0, dir.Z)
						if dir.Magnitude > 0.05 then
							dir = dir.Unit
							local tv = tRoot.AssemblyLinearVelocity
							tRoot.AssemblyLinearVelocity = dir * Config.M1_FINISHER_KNOCKBACK + Vector3.new(0, 18, 0)
						end
					end
				end
			end
			lastApplied = applied
			didHit = true
		else
			-- Fully negated by parry — still counts as interaction
			didHit = true
		end
	end

	if didHit and lastApplied > 0 then
		player:SetAttribute(ATTR_LAST_M1, lastApplied)
		character:SetAttribute(ATTR_LAST_M1, lastApplied)
		-- Optional Tomoe feel: pulse when Sharingan equipped (Combat M1 stays generic)
		local cur = player:GetAttribute("SF_CurrentFruit")
		if cur == "Sharingan" then
			player:SetAttribute(ATTR_TOMOE_M1, tick())
			character:SetAttribute(ATTR_TOMOE_M1, tick())
		end
	end

	fireVfxHit(character)
end

function CombatService.Start()
	if started then
		return
	end
	started = true

	Remotes.Event("CombatM1").OnServerEvent:Connect(function(player, comboIndexHint)
		handleM1(player, comboIndexHint)
	end)

	Remotes.Event("RequestOpenStats").OnServerEvent:Connect(function(player)
		if not AntiCheat.Validate(player, "RequestOpenStats", {
			cooldown = 0.5,
			maxPerSecond = 4,
			maxArgs = 0,
		}) then
			return
		end
	end)

	Players.PlayerRemoving:Connect(function(player)
		combos[player] = nil
	end)

	print("[SoulFruits.Combat] M1 combo online (parry + Susanoo DR + Tomoe pulse)")
end

return CombatService
