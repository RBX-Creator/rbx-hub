--!strict
--[[
	FactionService – Gut / Böse einmalig beim ersten Join.
	Studio: ServerScriptService/SoulFruits/Systems/FactionService (ModuleScript)
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Shared = ReplicatedStorage:WaitForChild("SoulFruits"):WaitForChild("Shared")
local Config = require(Shared:WaitForChild("Config"))
local Remotes = require(Shared:WaitForChild("Remotes"))

local DataManager = require(script.Parent.Parent.Data:WaitForChild("DataManager"))
local AntiCheat = require(script.Parent:WaitForChild("AntiCheat"))

local FactionService = {}
local started = false

local function isValidFaction(value: any): boolean
	return value == Config.FACTIONS.Gut or value == Config.FACTIONS.Bose
end

function FactionService.Start()
	if started then
		return
	end
	started = true

	Remotes.Event("ChooseFaction").OnServerEvent:Connect(function(player, faction)
		if not AntiCheat.Validate(player, "ChooseFaction", {
			cooldown = 1,
			maxPerSecond = 3,
			maxArgs = 1,
			argTypes = { "string" },
		}, faction) then
			return
		end
		if typeof(faction) ~= "string" or not isValidFaction(faction) then
			Remotes.Event("Notify"):FireClient(player, "Ungültige Fraktion.")
			return
		end

		local data = DataManager.Get(player)
		if not data then
			return
		end
		if data.Faction ~= nil then
			Remotes.Event("Notify"):FireClient(player, "Fraktion bereits gewählt.")
			return
		end

		DataManager.Update(player, function(profile)
			profile.Faction = faction :: any
		end)
		player:SetAttribute("SF_Faction", faction)
		Remotes.Event("Notify"):FireClient(player, "Fraktion: " .. faction)
	end)
end

return FactionService
