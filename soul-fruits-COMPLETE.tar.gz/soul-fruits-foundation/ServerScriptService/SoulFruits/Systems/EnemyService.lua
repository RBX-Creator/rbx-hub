--!strict
--[[
	EnemyService – Spawn from pads + simple chase AI + rewards.
	Pad: Part with Attribute SF_EnemyType = Bandit|Affe|... and optional SF_MaxCount
	Folder: Workspace/SoulFruitsWorld/EnemySpawns
	Studio: ServerScriptService/SoulFruits/Systems/EnemyService (ModuleScript)
]]

local Players = game:GetService("Players")
local PathfindingService = game:GetService("PathfindingService")
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local Shared = ReplicatedStorage:WaitForChild("SoulFruits"):WaitForChild("Shared")
local EnemiesConfig = require(Shared:WaitForChild("EnemiesConfig"))
local DataManager = require(script.Parent.Parent.Data:WaitForChild("DataManager"))
local LevelService = require(script.Parent:WaitForChild("LevelService"))
local QuestService = require(script.Parent:WaitForChild("QuestService"))

local EnemyService = {}
local started = false
local TAG_SPAWN = "SF_EnemySpawn"

type AliveEnemy = {
	Model: Model,
	DefId: string,
	Pad: BasePart,
	LastAttack: number,
}

local alive: { [Model]: AliveEnemy } = {}
local padCounts: { [BasePart]: number } = {}

local function createDummyEnemy(def: EnemiesConfig.EnemyDef, cframe: CFrame): Model
	local model = Instance.new("Model")
	model.Name = def.DisplayName

	local root = Instance.new("Part")
	root.Name = "HumanoidRootPart"
	root.Size = Vector3.new(2, 2, 1) * def.Scale
	root.CFrame = cframe + Vector3.new(0, 3 * def.Scale, 0)
	root.Anchored = false
	root.CanCollide = true
	root.Color = def.Color
	root.Material = Enum.Material.SmoothPlastic
	root.Parent = model

	local torso = Instance.new("Part")
	torso.Name = "Torso"
	torso.Size = Vector3.new(2, 2, 1) * def.Scale
	torso.CFrame = root.CFrame * CFrame.new(0, 0.5 * def.Scale, 0)
	torso.Color = def.Color
	torso.CanCollide = false
	torso.Massless = true
	torso.Parent = model
	local weld = Instance.new("WeldConstraint")
	weld.Part0 = root
	weld.Part1 = torso
	weld.Parent = root

	local head = Instance.new("Part")
	head.Name = "Head"
	head.Shape = Enum.PartType.Ball
	head.Size = Vector3.new(1.2, 1.2, 1.2) * def.Scale
	head.CFrame = root.CFrame * CFrame.new(0, 1.6 * def.Scale, 0)
	head.Color = def.Color
	head.CanCollide = false
	head.Massless = true
	head.Parent = model
	local weld2 = Instance.new("WeldConstraint")
	weld2.Part0 = root
	weld2.Part1 = head
	weld2.Parent = root

	local humanoid = Instance.new("Humanoid")
	humanoid.MaxHealth = def.MaxHealth
	humanoid.Health = def.MaxHealth
	humanoid.WalkSpeed = def.WalkSpeed
	humanoid.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.Subject
	humanoid.Parent = model

	model.PrimaryPart = root
	model:SetAttribute("SF_EnemyType", def.Id)
	model:SetAttribute("SF_IsEnemy", true)
	CollectionService:AddTag(model, "SF_Enemy")

	-- Prefer custom mesh template if present
	local templates = ReplicatedStorage:FindFirstChild("SoulFruits")
		and ReplicatedStorage.SoulFruits:FindFirstChild("EnemyTemplates")
	if templates then
		local tmpl = templates:FindFirstChild(def.Id)
		if tmpl and tmpl:IsA("Model") then
			local clone = tmpl:Clone()
			clone:PivotTo(cframe + Vector3.new(0, 3 * def.Scale, 0))
			clone:SetAttribute("SF_EnemyType", def.Id)
			clone:SetAttribute("SF_IsEnemy", true)
			CollectionService:AddTag(clone, "SF_Enemy")
			local hum = clone:FindFirstChildOfClass("Humanoid")
			if hum then
				hum.MaxHealth = def.MaxHealth
				hum.Health = def.MaxHealth
				hum.WalkSpeed = def.WalkSpeed
			end
			model:Destroy()
			return clone
		end
	end

	return model
end

local function nearestPlayer(position: Vector3, range: number): Player?
	local best: Player? = nil
	local bestDist = range
	for _, player in Players:GetPlayers() do
		local char = player.Character
		local hrp = char and char:FindFirstChild("HumanoidRootPart")
		if hrp and hrp:IsA("BasePart") then
			local d = (hrp.Position - position).Magnitude
			if d < bestDist then
				bestDist = d
				best = player
			end
		end
	end
	return best
end

local function onEnemyDied(entry: AliveEnemy, killer: Player?)
	alive[entry.Model] = nil
	padCounts[entry.Pad] = math.max(0, (padCounts[entry.Pad] or 1) - 1)

	local def = EnemiesConfig.Get(entry.DefId)
	if def and killer then
		LevelService.AddXP(killer, def.XP)
		DataManager.Update(killer, function(profile)
			profile.Coins = (profile.Coins or 0) + def.Coins
		end)
		QuestService.OnEnemyKilled(killer, entry.DefId)
		-- light VFX hook
		local char = killer.Character
		if char then
			char:SetAttribute("VFX_Hit", tick())
		end
	end

	task.delay(0.4, function()
		if entry.Model.Parent then
			entry.Model:Destroy()
		end
	end)

	-- respawn after delay
	task.delay(8, function()
		EnemyService.TrySpawnAtPad(entry.Pad)
	end)
end

function EnemyService.TrySpawnAtPad(pad: BasePart)
	local enemyType = pad:GetAttribute("SF_EnemyType")
	if typeof(enemyType) ~= "string" then
		return
	end
	local def = EnemiesConfig.Get(enemyType)
	if not def then
		warn("[SoulFruits.Enemy] Unknown type", enemyType)
		return
	end
	local maxCount = pad:GetAttribute("SF_MaxCount")
	if typeof(maxCount) ~= "number" then
		maxCount = 1
	end
	local count = padCounts[pad] or 0
	if count >= maxCount then
		return
	end

	local model = createDummyEnemy(def, pad.CFrame)
	model.Parent = workspace:FindFirstChild("SoulFruitsWorld")
		and workspace.SoulFruitsWorld:FindFirstChild("Enemies")
		or workspace

	padCounts[pad] = count + 1
	local entry: AliveEnemy = {
		Model = model,
		DefId = def.Id,
		Pad = pad,
		LastAttack = 0,
	}
	alive[model] = entry

	local humanoid = model:FindFirstChildOfClass("Humanoid")
	if humanoid then
		humanoid.Died:Connect(function()
			local killer: Player? = nil
			local creator = humanoid:FindFirstChild("creator")
			if creator and creator:IsA("ObjectValue") and creator.Value and creator.Value:IsA("Player") then
				killer = creator.Value
			else
				-- fallback: nearest player in 30 studs
				local root = model.PrimaryPart
				if root then
					killer = nearestPlayer(root.Position, 30)
				end
			end
			onEnemyDied(entry, killer)
		end)
	end
end

--- Tag damage source for attribution (CombatService / FruitService should set creator)
function EnemyService.TagDamage(humanoid: Humanoid, attacker: Player)
	local creator = humanoid:FindFirstChild("creator")
	if not creator then
		creator = Instance.new("ObjectValue")
		creator.Name = "creator"
		creator.Parent = humanoid
	end
	if creator:IsA("ObjectValue") then
		creator.Value = attacker
	end
end

local function hookPad(inst: Instance)
	if not inst:IsA("BasePart") then
		return
	end
	if typeof(inst:GetAttribute("SF_EnemyType")) ~= "string" then
		return
	end
	CollectionService:AddTag(inst, TAG_SPAWN)
	padCounts[inst] = padCounts[inst] or 0
	EnemyService.TrySpawnAtPad(inst)
end

function EnemyService.Start()
	if started then
		return
	end
	started = true

	task.defer(function()
		local world = workspace:FindFirstChild("SoulFruitsWorld")
		local spawns = world and world:FindFirstChild("EnemySpawns")
		if spawns then
			for _, child in spawns:GetDescendants() do
				if child:IsA("BasePart") and child:GetAttribute("SF_EnemyType") then
					hookPad(child)
				end
			end
			spawns.DescendantAdded:Connect(function(desc)
				if desc:IsA("BasePart") and desc:GetAttribute("SF_EnemyType") then
					hookPad(desc)
				end
			end)
		end
		for _, inst in CollectionService:GetTagged(TAG_SPAWN) do
			if inst:IsA("BasePart") then
				hookPad(inst)
			end
		end
	end)

	-- Simple AI loop
	RunService.Heartbeat:Connect(function()
		local now = os.clock()
		for model, entry in alive do
			local humanoid = model:FindFirstChildOfClass("Humanoid")
			local root = model.PrimaryPart
			if not humanoid or not root or humanoid.Health <= 0 then
				continue
			end
			local def = EnemiesConfig.Get(entry.DefId)
			if not def then
				continue
			end
			local targetPlayer = nearestPlayer(root.Position, def.AggroRange)
			if not targetPlayer or not targetPlayer.Character then
				continue
			end
			local thrp = targetPlayer.Character:FindFirstChild("HumanoidRootPart")
			local thum = targetPlayer.Character:FindFirstChildOfClass("Humanoid")
			if not thrp or not thum or thum.Health <= 0 then
				continue
			end
			humanoid:MoveTo(thrp.Position)
			local dist = (thrp.Position - root.Position).Magnitude
			if dist <= def.AttackRange and (now - entry.LastAttack) >= def.AttackCooldown then
				entry.LastAttack = now
				-- respect Susanoo / IFrames lightly
				local iframes = targetPlayer:GetAttribute("SF_IFramesUntil")
				local sus = targetPlayer:GetAttribute("SF_SusanooUntil")
				local t = tick()
				if typeof(iframes) == "number" and t < iframes then
					continue
				end
				local dmg = def.Damage
				if typeof(sus) == "number" and t < sus then
					dmg = math.floor(dmg * 0.35)
				end
				thum:TakeDamage(dmg)
				targetPlayer.Character:SetAttribute("VFX_Hit", tick())
			end
		end
	end)

	print("[SoulFruits.Enemy] Spawn + AI online (dummy meshes; swap EnemyTemplates later)")
end

return EnemyService
