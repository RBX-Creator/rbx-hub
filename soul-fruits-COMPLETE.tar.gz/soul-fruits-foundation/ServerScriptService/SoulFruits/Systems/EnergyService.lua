--!strict
--[[
	EnergyService – Chakra-Pool + Regen (Server-Authority).
	Movement (F Flug / Q Dash) dockt später an Spend/CanSpend an.
	Studio: ServerScriptService/SoulFruits/Systems/EnergyService (ModuleScript)
]]

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Shared = ReplicatedStorage:WaitForChild("SoulFruits"):WaitForChild("Shared")
local Config = require(Shared:WaitForChild("Config"))

local DataManager = require(script.Parent.Parent.Data:WaitForChild("DataManager"))
local StatService = require(script.Parent:WaitForChild("StatService"))

type EnergyState = {
	Current: number,
	Flying: boolean,
	Running: boolean,
}

local EnergyService = {}
local states: { [Player]: EnergyState } = {}
local started = false

local function maxFor(player: Player): number
	local data = DataManager.Get(player)
	if not data then
		return Config.BASE_MAX_CHAKRA
	end
	return StatService.GetMaxChakra(data.Stats)
end

local function ensure(player: Player): EnergyState
	local state = states[player]
	if not state then
		state = {
			Current = maxFor(player),
			Flying = false,
			Running = false,
		}
		states[player] = state
	end
	return state
end

local function replicate(player: Player, state: EnergyState)
	player:SetAttribute("Energy", state.Current)
	player:SetAttribute("MaxChakra", maxFor(player))
	player:SetAttribute("IsFlying", state.Flying)
end

function EnergyService.Get(player: Player): number
	return ensure(player).Current
end

function EnergyService.SetFlying(player: Player, flying: boolean)
	local state = ensure(player)
	state.Flying = flying == true
	replicate(player, state)
end

function EnergyService.SetRunning(player: Player, running: boolean)
	local state = ensure(player)
	state.Running = running == true
end

function EnergyService.CanSpend(player: Player, amount: number): boolean
	return ensure(player).Current >= amount
end

--- Returns true if spent. Server-only.
function EnergyService.Spend(player: Player, amount: number): boolean
	if typeof(amount) ~= "number" or amount <= 0 then
		return false
	end
	local state = ensure(player)
	if state.Current < amount then
		return false
	end
	state.Current -= amount
	replicate(player, state)
	return true
end

function EnergyService.RefillToMax(player: Player)
	local state = ensure(player)
	state.Current = maxFor(player)
	replicate(player, state)
end

function EnergyService.Start()
	if started then
		return
	end
	started = true

	local function hook(player: Player)
		ensure(player)
		replicate(player, states[player])
		player:GetAttributeChangedSignal("StatsVersion"):Connect(function()
			local state = ensure(player)
			local max = maxFor(player)
			state.Current = math.min(state.Current, max)
			replicate(player, state)
		end)
	end

	Players.PlayerAdded:Connect(hook)
	Players.PlayerRemoving:Connect(function(player)
		states[player] = nil
	end)
	for _, player in Players:GetPlayers() do
		hook(player)
	end

	-- Regen loop
	local acc = 0
	RunService.Heartbeat:Connect(function(dt)
		acc += dt
		if acc < 0.2 then
			return
		end
		local step = acc
		acc = 0
		for player, state in states do
			local max = maxFor(player)
			local rate = Config.ENERGY_REGEN_STANDING
			if state.Flying then
				rate = Config.ENERGY_REGEN_FLYING
				-- flight drain is applied by Movement later via Spend; optional drain here:
				-- state.Current = math.max(0, state.Current - Config.FLIGHT_COST_PER_SEC * step)
			elseif state.Running then
				rate = Config.ENERGY_REGEN_RUNNING
			end
			if rate > 0 and state.Current < max then
				state.Current = math.min(max, state.Current + rate * step)
				replicate(player, state)
			elseif state.Current > max then
				state.Current = max
				replicate(player, state)
			end
		end
	end)
end

return EnergyService
