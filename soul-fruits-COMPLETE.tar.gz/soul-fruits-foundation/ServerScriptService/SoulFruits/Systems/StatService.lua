--!strict
--[[
	StatService – FreeStatPoints verteilen (Melee / Leben / Chakra / Schwer).
	Leben & Chakra wirken sofort auf Max HP / Max Energy.
	Studio: ServerScriptService/SoulFruits/Systems/StatService (ModuleScript)
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Shared = ReplicatedStorage:WaitForChild("SoulFruits"):WaitForChild("Shared")
local Config = require(Shared:WaitForChild("Config"))
local Remotes = require(Shared:WaitForChild("Remotes"))
local Types = require(Shared:WaitForChild("Types"))

local DataManager = require(script.Parent.Parent.Data:WaitForChild("DataManager"))
local AntiCheat = require(script.Parent:WaitForChild("AntiCheat"))

local StatService = {}
local started = false

local function isStatKey(key: any): boolean
	for _, k in Config.STAT_KEYS do
		if k == key then
			return true
		end
	end
	return false
end

function StatService.GetMaxHP(stats: Types.Stats): number
	return Config.BASE_MAX_HP + stats.Leben * Config.HP_PER_LEBEN
end

function StatService.GetMaxChakra(stats: Types.Stats): number
	return Config.BASE_MAX_CHAKRA + stats.Chakra * Config.CHAKRA_PER_STAT
end

--- Apply current Leben/Chakra to Humanoid + attribute MaxChakra
function StatService.ApplyCombatStats(player: Player)
	local data = DataManager.Get(player)
	if not data then
		return
	end
	local character = player.Character
	if not character then
		return
	end
	local humanoid = character:FindFirstChildOfClass("Humanoid")
	if not humanoid then
		return
	end

	local maxHp = StatService.GetMaxHP(data.Stats)
	local maxChakra = StatService.GetMaxChakra(data.Stats)

	local ratio = if humanoid.MaxHealth > 0 then humanoid.Health / humanoid.MaxHealth else 1
	humanoid.MaxHealth = maxHp
	humanoid.Health = math.clamp(maxHp * ratio, 1, maxHp)

	player:SetAttribute("MaxChakra", maxChakra)
end

--- Retries when Character spawns before DataStore load finishes.
function StatService.ApplyCombatStatsWhenReady(player: Player)
	task.spawn(function()
		local data = DataManager.WaitFor(player, 20)
		if not data or player.Parent == nil then
			return
		end
		-- Character / Humanoid may still be streaming in
		for _ = 1, 50 do
			local character = player.Character
			if character then
				local humanoid = character:FindFirstChildOfClass("Humanoid")
				if humanoid then
					StatService.ApplyCombatStats(player)
					return
				end
			end
			task.wait(0.1)
		end
	end)
end

function StatService.Start()
	if started then
		return
	end
	started = true

	Remotes.Event("AllocateStat").OnServerEvent:Connect(function(player, statKey, amount)
		if not AntiCheat.Validate(player, "AllocateStat", {
			cooldown = 0.1,
			maxPerSecond = 10,
			maxArgs = 2,
			argTypes = { "string", "number" },
			argRanges = { nil, { min = 1, max = 100 } },
		}, statKey, amount) then
			return
		end
		if typeof(statKey) ~= "string" or not isStatKey(statKey) then
			return
		end
		if typeof(amount) ~= "number" or amount ~= amount then
			return
		end
		amount = math.floor(amount)
		if amount < 1 or amount > 100 then
			return
		end

		local data = DataManager.Get(player)
		if not data or data.FreeStatPoints < amount then
			Remotes.Event("Notify"):FireClient(player, "Nicht genug Stat-Punkte.")
			return
		end

		DataManager.Update(player, function(profile)
			profile.FreeStatPoints -= amount
			profile.Stats[statKey] = (profile.Stats :: any)[statKey] + amount
		end)

		StatService.ApplyCombatStats(player)
		player:SetAttribute("StatsVersion", (player:GetAttribute("StatsVersion") :: number? or 0) + 1)
	end)

	local function hookPlayer(player: Player)
		player.CharacterAdded:Connect(function()
			StatService.ApplyCombatStatsWhenReady(player)
		end)
		if player.Character then
			StatService.ApplyCombatStatsWhenReady(player)
		end
	end

	Players.PlayerAdded:Connect(hookPlayer)
	for _, player in Players:GetPlayers() do
		hookPlayer(player)
	end
end

return StatService
