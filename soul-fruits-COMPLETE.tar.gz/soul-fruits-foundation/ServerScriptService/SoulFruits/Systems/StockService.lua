--!strict
--[[
	StockService – Blox Fruits-like fruit stock (3 slots, refresh every 4h, Coins).
	Server clock via os.time; purchase only on server + AntiCheat.Validate.
	Studio: ServerScriptService/SoulFruits/Systems/StockService (ModuleScript)
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Shared = ReplicatedStorage:WaitForChild("SoulFruits"):WaitForChild("Shared")
local FruitsConfig = require(Shared:WaitForChild("FruitsConfig"))
local Remotes = require(Shared:WaitForChild("Remotes"))

local DataManager = require(script.Parent.Parent.Data:WaitForChild("DataManager"))
local AntiCheat = require(script.Parent:WaitForChild("AntiCheat"))
local PhysicalFruitService = require(script.Parent:WaitForChild("PhysicalFruitService"))

export type StockSlot = {
	FruitId: string,
	PriceCoins: number,
	SoldOut: boolean,
}

export type StockSnapshot = {
	Slots: { StockSlot },
	WindowStart: number,
	WindowEnd: number,
	ServerTime: number,
}

local StockService = {}
local started = false

local currentWindow = -1
local slots: { StockSlot } = {}
local rng = Random.new()

local function windowStart(now: number): number
	local period = FruitsConfig.STOCK_REFRESH_SEC
	return math.floor(now / period) * period
end

local function fruitIdList(): { string }
	return FruitsConfig.ListFruitIds()
end

local function rollSlot(): StockSlot
	local ids = fruitIdList()
	local id = ids[rng:NextInteger(1, #ids)]
	local def = FruitsConfig.Fruits[id]
	return {
		FruitId = id,
		PriceCoins = def.StockPriceCoins,
		SoldOut = false,
	}
end

local function rebuildStock(force: boolean?)
	local now = os.time()
	local win = windowStart(now)
	if not force and win == currentWindow and #slots == FruitsConfig.STOCK_SIZE then
		return
	end
	currentWindow = win
	slots = {}
	-- MVP: Slot 1 immer Dreck (testbar kaufen→Lager→Ausrüsten→Essen)
	table.insert(slots, {
		FruitId = "Dreck",
		PriceCoins = (FruitsConfig.Fruits.Dreck and FruitsConfig.Fruits.Dreck.StockPriceCoins) or 100,
		SoldOut = false,
	})
	for _ = 2, FruitsConfig.STOCK_SIZE do
		table.insert(slots, rollSlot())
	end
end

local function snapshot(): StockSnapshot
	rebuildStock(false)
	local now = os.time()
	local win = windowStart(now)
	return {
		Slots = slots,
		WindowStart = win,
		WindowEnd = win + FruitsConfig.STOCK_REFRESH_SEC,
		ServerTime = now,
	}
end

function StockService.GetSnapshot(): StockSnapshot
	return snapshot()
end

local function pushTo(player: Player)
	Remotes.Event("StockUpdated"):FireClient(player, snapshot())
end

local function pushAll()
	local snap = snapshot()
	for _, player in Players:GetPlayers() do
		Remotes.Event("StockUpdated"):FireClient(player, snap)
	end
end

local function handleBuy(player: Player, slotIndex: any)
	if not AntiCheat.Validate(player, "StockBuy", {
		cooldown = 0.35,
		maxPerSecond = 4,
		maxArgs = 1,
		argTypes = { "number" },
		argRanges = { { min = 1, max = FruitsConfig.STOCK_SIZE } },
	}, slotIndex) then
		return
	end
	if typeof(slotIndex) ~= "number" then
		return
	end
	local idx = math.floor(slotIndex)
	if idx < 1 or idx > FruitsConfig.STOCK_SIZE then
		return
	end

	rebuildStock(false)
	local slot = slots[idx]
	if not slot or slot.SoldOut then
		Remotes.Event("Notify"):FireClient(player, "Dieser Stock-Slot ist ausverkauft.")
		return
	end

	local data = DataManager.Get(player)
	if not data then
		return
	end
	if (data.Coins or 0) < slot.PriceCoins then
		Remotes.Event("Notify"):FireClient(player, ("Nicht genug Coins (%d benötigt)."):format(slot.PriceCoins))
		return
	end

	local fruitId = slot.FruitId
	local price = slot.PriceCoins

	local ok = DataManager.Update(player, function(profile)
		profile.Coins -= price
	end)
	if not ok then
		return
	end

	slot.SoldOut = true
	PhysicalFruitService.GrantToStorage(player, fruitId, true)
	Remotes.Event("Notify"):FireClient(player, ("Stock: %s (−%d Coins) — ins Lager"):format(fruitId, price))
	pushAll()
end

function StockService.Start()
	if started then
		return
	end
	started = true

	rebuildStock(true)

	Remotes.Event("StockBuy").OnServerEvent:Connect(handleBuy)

	Players.PlayerAdded:Connect(function(player)
		task.defer(function()
			DataManager.WaitFor(player, 20)
			if player.Parent then
				pushTo(player)
			end
		end)
	end)
	for _, player in Players:GetPlayers() do
		task.defer(function()
			pushTo(player)
		end)
	end

	-- Poll window change (cheap)
	task.spawn(function()
		while true do
			task.wait(5)
			local win = windowStart(os.time())
			if win ~= currentWindow then
				rebuildStock(true)
				pushAll()
			end
		end
	end)

	print("[SoulFruits.Stock] 3-slot stock online (4h refresh)")
end

return StockService
