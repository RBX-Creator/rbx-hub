--!strict
--[[
	DayNightService – Server-Zyklus ~20 Min (10 Tag + 10 Nacht).
	Neue Server starten am Tag. Mondphasen später.
	Studio: ServerScriptService/SoulFruits/Systems/DayNightService (ModuleScript)
]]

local Lighting = game:GetService("Lighting")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Shared = ReplicatedStorage:WaitForChild("SoulFruits"):WaitForChild("Shared")
local Config = require(Shared:WaitForChild("Config"))

local DayNightService = {}
local started = false
local cycleStart = os.clock()
local isNight = false

local function ensureAtmosphere()
	local atm = Lighting:FindFirstChildOfClass("Atmosphere")
	if not atm then
		atm = Instance.new("Atmosphere")
		atm.Name = "SoulFruitsAtmosphere"
		atm.Parent = Lighting
	end
	return atm
end

local function applyDay()
	isNight = false
	Lighting.ClockTime = 14
	Lighting.Brightness = 2
	Lighting.OutdoorAmbient = Color3.fromRGB(180, 180, 180)
	local atm = ensureAtmosphere()
	atm.Density = 0.25
	atm.Haze = 0
	workspace:SetAttribute("SoulFruits_IsNight", false)
end

local function applyNight()
	isNight = true
	Lighting.ClockTime = 0
	Lighting.Brightness = 1
	Lighting.OutdoorAmbient = Color3.fromRGB(60, 70, 100)
	local atm = ensureAtmosphere()
	atm.Density = 0.35
	atm.Haze = 1.5
	workspace:SetAttribute("SoulFruits_IsNight", true)
end

function DayNightService.IsNight(): boolean
	return isNight
end

function DayNightService.GetCycleProgress(): number
	local total = Config.DAY_DURATION + Config.NIGHT_DURATION
	local t = (os.clock() - cycleStart) % total
	return t / total
end

function DayNightService.Start()
	if started then
		return
	end
	started = true
	cycleStart = os.clock()

	if Config.CYCLE_STARTS_DAY then
		applyDay()
	else
		applyNight()
	end

	task.spawn(function()
		while true do
			local total = Config.DAY_DURATION + Config.NIGHT_DURATION
			local elapsed = (os.clock() - cycleStart) % total
			if elapsed < Config.DAY_DURATION then
				if isNight then
					applyDay()
				end
				-- soft clock drift during day 6 → 18
				local alpha = elapsed / Config.DAY_DURATION
				Lighting.ClockTime = 6 + alpha * 12
			else
				if not isNight then
					applyNight()
				end
				local alpha = (elapsed - Config.DAY_DURATION) / Config.NIGHT_DURATION
				Lighting.ClockTime = (18 + alpha * 12) % 24
			end
			task.wait(1)
		end
	end)
end

return DayNightService
