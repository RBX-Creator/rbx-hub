--!strict
--[[
	QuestService – Accept / Progress / Complete (Server-Authority).
	NPC: ProximityPrompt on models tagged Attribute SF_QuestGiver = questId
	Interact spots: Attribute SF_InteractId = BoatVendor | Gacha | SailOutlaw | ...
	Studio: ServerScriptService/SoulFruits/Systems/QuestService (ModuleScript)
]]

local Players = game:GetService("Players")
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Shared = ReplicatedStorage:WaitForChild("SoulFruits"):WaitForChild("Shared")
local Remotes = require(Shared:WaitForChild("Remotes"))
local QuestsConfig = require(Shared:WaitForChild("QuestsConfig"))
local AntiCheat = require(script.Parent:WaitForChild("AntiCheat"))
local DataManager = require(script.Parent.Parent.Data:WaitForChild("DataManager"))
local LevelService = require(script.Parent:WaitForChild("LevelService"))

local QuestService = {}
local started = false

local TAG_QUEST_GIVER = "SF_QuestGiver"
local TAG_INTERACT = "SF_Interact"

local function pushQuestState(player: Player)
	local data = DataManager.Get(player)
	if not data then
		return
	end
	Remotes.Event("QuestUpdated"):FireClient(player, {
		ActiveQuestId = (data :: any).ActiveQuestId,
		QuestProgress = (data :: any).QuestProgress or 0,
		CompletedQuests = (data :: any).CompletedQuests or {},
	})
end

local function grantRewards(player: Player, xp: number, coins: number)
	if xp > 0 then
		LevelService.AddXP(player, xp)
	end
	if coins > 0 then
		DataManager.Update(player, function(profile)
			profile.Coins = (profile.Coins or 0) + coins
		end)
	end
end

local function canAccept(player: Player, questId: string): (boolean, string?)
	local def = QuestsConfig.Get(questId)
	if not def then
		return false, "Unbekannte Quest."
	end
	local data = DataManager.Get(player)
	if not data then
		return false, "Daten laden…"
	end
	if data.Level < def.MinLevel then
		return false, ("Level %d benötigt."):format(def.MinLevel)
	end
	local completed = (data :: any).CompletedQuests or {}
	if not def.Repeatable and completed[questId] then
		return false, "Quest bereits abgeschlossen."
	end
	if def.RequiresQuest and not completed[def.RequiresQuest] then
		return false, "Vorherige Quest fehlt."
	end
	local active = (data :: any).ActiveQuestId
	if active and active ~= "" then
		return false, "Du hast schon eine aktive Quest."
	end
	return true, nil
end

function QuestService.Accept(player: Player, questId: string): boolean
	local ok, err = canAccept(player, questId)
	if not ok then
		Remotes.Event("Notify"):FireClient(player, err or "Quest abgelehnt.")
		return false
	end
	local def = QuestsConfig.Get(questId)
	if not def then
		return false
	end
	DataManager.Update(player, function(profile)
		(profile :: any).ActiveQuestId = questId
		(profile :: any).QuestProgress = 0
	end)
	pushQuestState(player)
	Remotes.Event("Notify"):FireClient(player, ("Quest: %s"):format(def.Name))
	return true
end

function QuestService.Abandon(player: Player)
	DataManager.Update(player, function(profile)
		(profile :: any).ActiveQuestId = nil
		(profile :: any).QuestProgress = 0
	end)
	pushQuestState(player)
	Remotes.Event("Notify"):FireClient(player, "Quest abgebrochen.")
end

local function tryComplete(player: Player)
	local data = DataManager.Get(player)
	if not data then
		return
	end
	local questId = (data :: any).ActiveQuestId
	if not questId then
		return
	end
	local def = QuestsConfig.Get(questId)
	if not def then
		return
	end
	local need = def.TargetCount or 1
	local progress = (data :: any).QuestProgress or 0
	if progress < need then
		return
	end

	DataManager.Update(player, function(profile)
		(profile :: any).ActiveQuestId = nil
		(profile :: any).QuestProgress = 0
		if not (profile :: any).CompletedQuests then
			(profile :: any).CompletedQuests = {}
		end
		(profile :: any).CompletedQuests[questId] = true
	end)
	grantRewards(player, def.XP, def.Coins)
	pushQuestState(player)
	Remotes.Event("Notify"):FireClient(player, ("Fertig: %s (+%d XP, +%d Coins)"):format(def.Name, def.XP, def.Coins))
end

--- Called by EnemyService on kill
function QuestService.OnEnemyKilled(player: Player, enemyType: string)
	local data = DataManager.Get(player)
	if not data then
		return
	end
	local questId = (data :: any).ActiveQuestId
	if not questId then
		return
	end
	local def = QuestsConfig.Get(questId)
	if not def or def.Kind ~= "Kill" then
		return
	end
	if def.TargetEnemy ~= enemyType then
		-- Boss kills can also count if MiniBoss matches
		if def.MiniBoss ~= enemyType then
			return
		end
	end

	DataManager.Update(player, function(profile)
		local p = ((profile :: any).QuestProgress or 0) + 1
		(profile :: any).QuestProgress = p
	end)
	pushQuestState(player)
	tryComplete(player)
end

--- Talk / Find / Sail interact
function QuestService.OnInteract(player: Player, interactId: string)
	local data = DataManager.Get(player)
	if not data then
		return
	end
	local questId = (data :: any).ActiveQuestId
	if not questId then
		-- Still allow talking to quest givers to accept
		return
	end
	local def = QuestsConfig.Get(questId)
	if not def then
		return
	end
	if def.Kind ~= "Talk" and def.Kind ~= "Find" and def.Kind ~= "Sail" then
		return
	end
	if def.TargetSpot ~= interactId then
		return
	end
	DataManager.Update(player, function(profile)
		(profile :: any).QuestProgress = def.TargetCount or 1
	end)
	pushQuestState(player)
	tryComplete(player)
end

local function hookQuestGiver(inst: Instance)
	if not inst:IsA("Model") and not inst:IsA("BasePart") then
		return
	end
	local questId = inst:GetAttribute("SF_QuestId")
	if typeof(questId) ~= "string" then
		return
	end
	local parent: Instance = inst
	local part: BasePart? = if inst:IsA("BasePart") then inst else inst:FindFirstChildWhichIsA("BasePart", true)
	if not part then
		return
	end
	if part:FindFirstChild("SF_QuestPrompt") then
		return
	end
	local prompt = Instance.new("ProximityPrompt")
	prompt.Name = "SF_QuestPrompt"
	prompt.ActionText = "Quest"
	prompt.ObjectText = (QuestsConfig.Get(questId) and QuestsConfig.Get(questId).Name) or "Quest"
	prompt.HoldDuration = 0.2
	prompt.MaxActivationDistance = 12
	prompt.Parent = part
	prompt.Triggered:Connect(function(player)
		QuestService.Accept(player, questId)
	end)
end

local function hookInteract(inst: Instance)
	local interactId = inst:GetAttribute("SF_InteractId")
	if typeof(interactId) ~= "string" then
		return
	end
	local part: BasePart? = if inst:IsA("BasePart") then inst else inst:FindFirstChildWhichIsA("BasePart", true)
	if not part then
		return
	end
	if part:FindFirstChild("SF_InteractPrompt") then
		return
	end
	local prompt = Instance.new("ProximityPrompt")
	prompt.Name = "SF_InteractPrompt"
	prompt.ActionText = "Interagieren"
	prompt.ObjectText = interactId
	prompt.HoldDuration = 0.25
	prompt.MaxActivationDistance = 14
	prompt.Parent = part
	prompt.Triggered:Connect(function(player)
		if not AntiCheat.Validate(player, "QuestInteract", {
			cooldown = 0.4,
			maxPerSecond = 4,
			maxArgs = 0,
		}) then
			return
		end
		QuestService.OnInteract(player, interactId)
	end)
end

function QuestService.Start()
	if started then
		return
	end
	started = true

	Remotes.Event("QuestAccept").OnServerEvent:Connect(function(player, questId)
		if not AntiCheat.Validate(player, "QuestAccept", {
			cooldown = 0.5,
			maxPerSecond = 3,
			maxArgs = 1,
			argTypes = { "string" },
		}, questId) then
			return
		end
		if typeof(questId) ~= "string" then
			return
		end
		QuestService.Accept(player, questId)
	end)

	Remotes.Event("QuestAbandon").OnServerEvent:Connect(function(player)
		if not AntiCheat.Validate(player, "QuestAbandon", {
			cooldown = 1,
			maxPerSecond = 2,
			maxArgs = 0,
		}) then
			return
		end
		QuestService.Abandon(player)
	end)

	for _, inst in CollectionService:GetTagged(TAG_QUEST_GIVER) do
		hookQuestGiver(inst)
	end
	CollectionService:GetInstanceAddedSignal(TAG_QUEST_GIVER):Connect(hookQuestGiver)

	for _, inst in CollectionService:GetTagged(TAG_INTERACT) do
		hookInteract(inst)
	end
	CollectionService:GetInstanceAddedSignal(TAG_INTERACT):Connect(hookInteract)

	-- Also scan Attribute-only NPCs under World folder (no tag required if attribute set)
	task.defer(function()
		local world = workspace:FindFirstChild("SoulFruitsWorld")
		if not world then
			return
		end
		for _, desc in world:GetDescendants() do
			if desc:GetAttribute("SF_QuestId") then
				CollectionService:AddTag(desc, TAG_QUEST_GIVER)
				hookQuestGiver(desc)
			end
			if desc:GetAttribute("SF_InteractId") then
				CollectionService:AddTag(desc, TAG_INTERACT)
				hookInteract(desc)
			end
		end
	end)

	Players.PlayerAdded:Connect(function(player)
		task.defer(function()
			DataManager.WaitFor(player, 20)
			pushQuestState(player)
		end)
	end)
	for _, player in Players:GetPlayers() do
		task.defer(function()
			DataManager.WaitFor(player, 20)
			pushQuestState(player)
		end)
	end

	print("[SoulFruits.Quest] Starter→Jungle quests online")
end

return QuestService
