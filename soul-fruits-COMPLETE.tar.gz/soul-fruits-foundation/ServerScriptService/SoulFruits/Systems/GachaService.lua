--!strict
--[[
	GachaService – Weighted fruit roll (Splitz cost; DiceParts reserved).
	Rarity: Common 55 / Uncommon 30 / Rare 12 / Legendary 3 / Mythical 0.8 (normalize).
	Studio: ServerScriptService/SoulFruits/Systems/GachaService (ModuleScript)
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Shared = ReplicatedStorage:WaitForChild("SoulFruits"):WaitForChild("Shared")
local FruitsConfig = require(Shared:WaitForChild("FruitsConfig"))
local Remotes = require(Shared:WaitForChild("Remotes"))

local DataManager = require(script.Parent.Parent.Data:WaitForChild("DataManager"))
local AntiCheat = require(script.Parent:WaitForChild("AntiCheat"))
local PhysicalFruitService = require(script.Parent:WaitForChild("PhysicalFruitService"))

local GachaService = {}
local started = false
local rng = Random.new()

local function pickRarity(): string
	-- Only rarities that currently have at least one fruit (Legendary may be empty early)
	local weighted: { { rarity: string, w: number } } = {}
	local total = 0
	for rarity, weight in FruitsConfig.RarityWeights do
		local list = FruitsConfig.GetFruitsByRarity(rarity)
		if #list > 0 and weight > 0 then
			table.insert(weighted, { rarity = rarity, w = weight })
			total += weight
		end
	end
	if total <= 0 then
		return "Common"
	end
	local roll = rng:NextNumber() * total
	local acc = 0
	for _, entry in weighted do
		acc += entry.w
		if roll <= acc then
			return entry.rarity
		end
	end
	return weighted[#weighted].rarity
end

local function pickFruitId(): (string, string)
	local rarity = pickRarity()
	local list = FruitsConfig.GetFruitsByRarity(rarity)
	if #list == 0 then
		-- fallback Common
		list = FruitsConfig.GetFruitsByRarity("Common")
		rarity = "Common"
	end
	local def = list[rng:NextInteger(1, #list)]
	return def.Id, rarity
end

local function handleRoll(player: Player)
	if not AntiCheat.Validate(player, "GachaRoll", {
		cooldown = 0.5,
		maxPerSecond = 3,
		maxArgs = 0,
	}) then
		return
	end

	local data = DataManager.Get(player)
	if not data then
		return
	end

	local cost = FruitsConfig.GACHA_COST_SPLITZ
	if (data.Splitz or 0) < cost then
		Remotes.Event("Notify"):FireClient(player, ("Nicht genug Splitz (%d benötigt)."):format(cost))
		return
	end

	-- Ensure DiceParts exists via reconcile path / mutate
	local fruitId, rarity = pickFruitId()

	local ok = DataManager.Update(player, function(profile)
		profile.Splitz -= cost
		if typeof(profile.DiceParts) ~= "number" then
			profile.DiceParts = 0
		end
	end)
	if not ok then
		return
	end

	PhysicalFruitService.GivePhysical(player, fruitId, true)
	Remotes.Event("GachaResult"):FireClient(player, fruitId, rarity)
	Remotes.Event("Notify"):FireClient(player, ("Gacha: %s (%s) — drehen, dann essen oder lagern"):format(fruitId, rarity))
end

function GachaService.Start()
	if started then
		return
	end
	started = true

	Remotes.Event("GachaRoll").OnServerEvent:Connect(handleRoll)
	print("[SoulFruits.Gacha] Weighted roll online (Splitz)")
end

return GachaService
