--!strict
--[[
	PhysicalFruitService – Blox Fruits-like flow:
	Gacha/Stock → physisches Tool (Dreh) → Essen ODER Lagern → erst nach Essen Z/X/C/V.
	Sea 1 Storage: 1 Slot pro Fruit-Typ.
	Studio: ServerScriptService/SoulFruits/Systems/PhysicalFruitService (ModuleScript)
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Shared = ReplicatedStorage:WaitForChild("SoulFruits"):WaitForChild("Shared")
local FruitsConfig = require(Shared:WaitForChild("FruitsConfig"))
local Remotes = require(Shared:WaitForChild("Remotes"))

local DataManager = require(script.Parent.Parent.Data:WaitForChild("DataManager"))
local AntiCheat = require(script.Parent:WaitForChild("AntiCheat"))
local FruitService = require(script.Parent:WaitForChild("FruitService"))

local PhysicalFruitService = {}
local started = false

local TOOL_NAME_PREFIX = "SF_Fruit_"
local ATTR_FRUIT_ID = "SF_FruitId"
local ATTR_PHYSICAL = "SF_IsPhysicalFruit"
local ATTR_SPIN = "VFX_FruitSpin"
local ATTR_EAT = "SF_FruitEat"

local ELEMENT_COLORS = {
	Dreck = Color3.fromRGB(110, 85, 55),
	Wind = Color3.fromRGB(180, 220, 255),
	Flame = Color3.fromRGB(255, 110, 40),
	Ice = Color3.fromRGB(140, 210, 255),
	Light = Color3.fromRGB(255, 245, 180),
	Magma = Color3.fromRGB(220, 60, 20),
	Blutaugespiegel = Color3.fromRGB(140, 20, 40),
	Sharingan = Color3.fromRGB(200, 25, 35),
}

local function pushStorage(player: Player)
	local data = DataManager.Get(player)
	if not data then
		return
	end
	Remotes.Event("StorageUpdated"):FireClient(player, (data :: any).FruitStorage or {})
end

local function createFruitTool(fruitId: string): Tool?
	local def = FruitsConfig.Fruits[fruitId]
	if not def then
		return nil
	end
	local tool = Instance.new("Tool")
	tool.Name = TOOL_NAME_PREFIX .. fruitId
	tool.CanBeDropped = true
	tool.RequiresHandle = true
	tool:SetAttribute(ATTR_FRUIT_ID, fruitId)
	tool:SetAttribute(ATTR_PHYSICAL, true)

	local handle = Instance.new("Part")
	handle.Name = "Handle"
	handle.Size = Vector3.new(1.2, 1.2, 1.2)
	handle.Shape = Enum.PartType.Ball
	handle.Color = ELEMENT_COLORS[fruitId] or Color3.fromRGB(200, 160, 80)
	handle.Material = Enum.Material.SmoothPlastic
	handle.Massless = true
	handle.Parent = tool

	-- Optional mesh template
	local templates = ReplicatedStorage:FindFirstChild("SoulFruits")
		and ReplicatedStorage.SoulFruits:FindFirstChild("FruitToolTemplates")
	if templates then
		local tmpl = templates:FindFirstChild(fruitId)
		if tmpl and tmpl:IsA("BasePart") then
			handle:Destroy()
			local clone = tmpl:Clone()
			clone.Name = "Handle"
			clone.Massless = true
			clone.Parent = tool
		elseif tmpl and tmpl:IsA("Model") and tmpl.PrimaryPart then
			handle:Destroy()
			local clone = tmpl.PrimaryPart:Clone()
			clone.Name = "Handle"
			clone.Massless = true
			clone.Parent = tool
		end
	end

	return tool
end

local function findHeldPhysicalTool(player: Player): Tool?
	local function scan(container: Instance?): Tool?
		if not container then
			return nil
		end
		for _, child in container:GetChildren() do
			if child:IsA("Tool") and child:GetAttribute(ATTR_PHYSICAL) == true then
				return child
			end
		end
		return nil
	end
	-- Prefer character (equipped)
	local charTool = scan(player.Character)
	if charTool then
		return charTool
	end
	return scan(player:FindFirstChildOfClass("Backpack"))
end

local function pulseSpin(player: Player, fruitId: string)
	local character = player.Character
	if character then
		character:SetAttribute(ATTR_SPIN, tick())
		character:SetAttribute("SF_SpinFruitId", fruitId)
	end
	player:SetAttribute(ATTR_SPIN, tick())
	player:SetAttribute("SF_SpinFruitId", fruitId)
	Remotes.Event("FruitSpin"):FireClient(player, fruitId)
end

--- Grant a physical fruit tool (from Gacha/Stock). Does NOT eat / equip abilities.
function PhysicalFruitService.GivePhysical(player: Player, fruitId: string, playSpin: boolean?): boolean
	if not FruitsConfig.Fruits[fruitId] then
		return false
	end
	local tool = createFruitTool(fruitId)
	if not tool then
		return false
	end
	local backpack = player:FindFirstChildOfClass("Backpack")
	if not backpack then
		tool:Destroy()
		return false
	end
	tool.Parent = backpack
	if playSpin ~= false then
		pulseSpin(player, fruitId)
	end
	Remotes.Event("Notify"):FireClient(player, ("Fruit erhalten: %s — essen oder lagern"):format(fruitId))
	return true
end

function PhysicalFruitService.Eat(player: Player): boolean
	local tool = findHeldPhysicalTool(player)
	if not tool then
		Remotes.Event("Notify"):FireClient(player, "Keine physische Fruit in der Hand/Backpack.")
		return false
	end
	local fruitId = tool:GetAttribute(ATTR_FRUIT_ID)
	if typeof(fruitId) ~= "string" or not FruitsConfig.Fruits[fruitId] then
		return false
	end

	-- Eat anim pulse first
	local character = player.Character
	if character then
		character:SetAttribute(ATTR_EAT, tick())
		character:SetAttribute("SF_EatFruitId", fruitId)
	end
	player:SetAttribute(ATTR_EAT, tick())
	player:SetAttribute("SF_EatFruitId", fruitId)
	Remotes.Event("FruitEatFX"):FireClient(player, fruitId)

	tool:Destroy()

	-- Apply eaten state (replaces CurrentFruit; mastery kept per type)
	DataManager.Update(player, function(profile)
		if not profile.OwnedFruits then
			profile.OwnedFruits = {}
		end
		profile.OwnedFruits[fruitId] = true
		if not profile.FruitMastery then
			profile.FruitMastery = {}
		end
		if typeof(profile.FruitMastery[fruitId]) ~= "number" then
			profile.FruitMastery[fruitId] = 0
		end
		profile.CurrentFruit = fruitId
		if fruitId == "Dreck" then
			profile.HatDreckFruit = true
		end
		-- Remove from storage if it was retrieved then eaten
		local storage = (profile :: any).FruitStorage
		if typeof(storage) == "table" then
			storage[fruitId] = nil
		end
	end)

	FruitService.OnFruitGranted(player, fruitId)
	-- OnFruitGranted also sets CurrentFruit — fine
	Remotes.Event("Notify"):FireClient(player, ("Gegessen: %s — Fähigkeiten aktiv"):format(fruitId))
	pushStorage(player)
	return true
end

function PhysicalFruitService.Store(player: Player): boolean
	local tool = findHeldPhysicalTool(player)
	if not tool then
		Remotes.Event("Notify"):FireClient(player, "Keine physische Fruit zum Lagern.")
		return false
	end
	local fruitId = tool:GetAttribute(ATTR_FRUIT_ID)
	if typeof(fruitId) ~= "string" then
		return false
	end

	local data = DataManager.Get(player)
	if not data then
		return false
	end
	local storage = (data :: any).FruitStorage or {}
	if storage[fruitId] == true then
		Remotes.Event("Notify"):FireClient(player, "Storage: dieser Fruit-Typ ist schon gelagert (1 Slot/Typ).")
		return false
	end

	DataManager.Update(player, function(profile)
		if not (profile :: any).FruitStorage then
			(profile :: any).FruitStorage = {}
		end
		(profile :: any).FruitStorage[fruitId] = true
	end)
	tool:Destroy()
	Remotes.Event("Notify"):FireClient(player, ("Gelagert: %s"):format(fruitId))
	pushStorage(player)
	return true
end

function PhysicalFruitService.Retrieve(player: Player, fruitId: string): boolean
	if typeof(fruitId) ~= "string" or not FruitsConfig.Fruits[fruitId] then
		return false
	end
	local data = DataManager.Get(player)
	if not data then
		return false
	end
	local storage = (data :: any).FruitStorage or {}
	if storage[fruitId] ~= true then
		Remotes.Event("Notify"):FireClient(player, "Nicht im Storage.")
		return false
	end

	DataManager.Update(player, function(profile)
		if (profile :: any).FruitStorage then
			(profile :: any).FruitStorage[fruitId] = nil
		end
	end)

	if not PhysicalFruitService.GivePhysical(player, fruitId, false) then
		-- rollback
		DataManager.Update(player, function(profile)
			if not (profile :: any).FruitStorage then
				(profile :: any).FruitStorage = {}
			end
			(profile :: any).FruitStorage[fruitId] = true
		end)
		return false
	end
	pushStorage(player)
	Remotes.Event("Notify"):FireClient(player, ("Aus Storage: %s"):format(fruitId))
	return true
end

function PhysicalFruitService.Start()
	if started then
		return
	end
	started = true

	Remotes.Event("FruitEat").OnServerEvent:Connect(function(player)
		if not AntiCheat.Validate(player, "FruitEat", {
			cooldown = 1.0,
			maxPerSecond = 2,
			maxArgs = 0,
		}) then
			return
		end
		PhysicalFruitService.Eat(player)
	end)

	Remotes.Event("FruitStore").OnServerEvent:Connect(function(player)
		if not AntiCheat.Validate(player, "FruitStore", {
			cooldown = 0.5,
			maxPerSecond = 3,
			maxArgs = 0,
		}) then
			return
		end
		PhysicalFruitService.Store(player)
	end)

	Remotes.Event("FruitRetrieve").OnServerEvent:Connect(function(player, fruitId)
		if not AntiCheat.Validate(player, "FruitRetrieve", {
			cooldown = 0.5,
			maxPerSecond = 3,
			maxArgs = 1,
			argTypes = { "string" },
		}, fruitId) then
			return
		end
		PhysicalFruitService.Retrieve(player, fruitId)
	end)

	Players.PlayerAdded:Connect(function(player)
		task.defer(function()
			DataManager.WaitFor(player, 20)
			pushStorage(player)
		end)
	end)
	for _, player in Players:GetPlayers() do
		task.defer(function()
			DataManager.WaitFor(player, 20)
			pushStorage(player)
		end)
	end

	print("[SoulFruits.PhysicalFruit] Tool → Eat/Store online (BF-flow)")
end

return PhysicalFruitService
