--!strict
--[[
	PhysicalFruitService – Final MVP flow:
	Gacha/Stock → NUR Lager (nie auto-eat/equip)
	Lager → Ausrüsten → Tool Hotbar + Mesh rechte Hand
	E = Essen (Anim) → Kraft aktiv, Mesh weg
	B = ungegessene Frucht zurück ins Lager
	Nur 1 gegessene Fruit gleichzeitig
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Shared = ReplicatedStorage:WaitForChild("SoulFruits"):WaitForChild("Shared")
local FruitsConfig = require(Shared:WaitForChild("FruitsConfig"))
local Remotes = require(Shared:WaitForChild("Remotes"))

local DataManager = require(script.Parent.Parent.Data:WaitForChild("DataManager"))
local AntiCheat = require(script.Parent:WaitForChild("AntiCheat"))
local FruitService = require(script.Parent:WaitForChild("FruitService"))

local PhysicalFruitService = {}
local started = false

local TOOL_NAME_PREFIX = "SF_Fruit_"
local ATTR_FRUIT_ID = "SF_FruitId"
local ATTR_PHYSICAL = "SF_IsPhysicalFruit"
local ATTR_SPIN = "VFX_FruitSpin"
local ATTR_EAT = "SF_FruitEat"
local HAND_ATTACH_NAME = "SF_FruitHandMesh"

local ELEMENT_COLORS = {
	Dreck = Color3.fromRGB(110, 85, 55),
	Wind = Color3.fromRGB(180, 220, 255),
	Flame = Color3.fromRGB(255, 110, 40),
	Ice = Color3.fromRGB(140, 210, 255),
	Light = Color3.fromRGB(255, 245, 180),
	Magma = Color3.fromRGB(220, 60, 20),
	Blutaugespiegel = Color3.fromRGB(200, 25, 35),
}

local function normalizeFruitId(fruitId: string): string
	-- Legacy alias: Sharingan → Blutaugespiegel (eine Mythical Fruit)
	if fruitId == "Sharingan" then
		return "Blutaugespiegel"
	end
	return fruitId
end

local function pushStorage(player: Player)
	local data = DataManager.Get(player)
	if not data then
		return
	end
	Remotes.Event("StorageUpdated"):FireClient(player, (data :: any).FruitStorage or {})
end

local function findRightHand(character: Model): BasePart?
	local hand = character:FindFirstChild("RightHand")
		or character:FindFirstChild("Right Arm")
		or character:FindFirstChild("RightLowerArm")
	if hand and hand:IsA("BasePart") then
		return hand
	end
	return nil
end

local function clearHandMesh(character: Model?)
	if not character then
		return
	end
	local existing = character:FindFirstChild(HAND_ATTACH_NAME, true)
	if existing then
		existing:Destroy()
	end
end

local function makeHandlePart(fruitId: string): BasePart
	local templates = ReplicatedStorage:FindFirstChild("SoulFruits")
		and ReplicatedStorage.SoulFruits:FindFirstChild("FruitToolTemplates")
	if templates then
		local tmpl = templates:FindFirstChild(fruitId)
			or templates:FindFirstChild("Sharingan") -- legacy mesh name OK
		if tmpl and tmpl:IsA("BasePart") then
			local clone = tmpl:Clone()
			clone.Name = "Handle"
			clone.Massless = true
			clone.CanCollide = false
			return clone
		elseif tmpl and tmpl:IsA("Model") then
			local src = tmpl:FindFirstChild("Handle") or tmpl.PrimaryPart
			if src and src:IsA("BasePart") then
				local clone = src:Clone()
				clone.Name = "Handle"
				clone.Massless = true
				clone.CanCollide = false
				return clone
			end
			warn(("[SoulFruits.PhysicalFruit] Template %s has no Handle — fallback ball"):format(fruitId))
		elseif templates:FindFirstChild(fruitId) == nil then
			warn(("[SoulFruits.PhysicalFruit] Missing FruitToolTemplates.%s — fallback ball"):format(fruitId))
		end
	else
		warn("[SoulFruits.PhysicalFruit] FruitToolTemplates folder missing — fallback ball")
	end

	local handle = Instance.new("Part")
	handle.Name = "Handle"
	handle.Size = Vector3.new(1.0, 1.0, 1.0)
	handle.Shape = Enum.PartType.Ball
	handle.Color = ELEMENT_COLORS[fruitId] or Color3.fromRGB(200, 160, 80)
	handle.Material = Enum.Material.SmoothPlastic
	handle.Massless = true
	handle.CanCollide = false
	return handle
end

local function createFruitTool(fruitId: string): Tool?
	if not FruitsConfig.Fruits[fruitId] then
		return nil
	end
	local tool = Instance.new("Tool")
	tool.Name = TOOL_NAME_PREFIX .. fruitId
	tool.CanBeDropped = false
	tool.RequiresHandle = true
	tool:SetAttribute(ATTR_FRUIT_ID, fruitId)
	tool:SetAttribute(ATTR_PHYSICAL, true)

	local handle = makeHandlePart(fruitId)
	handle.Parent = tool

	tool.Equipped:Connect(function()
		local character = tool.Parent
		if not character or not character:IsA("Model") then
			return
		end
		clearHandMesh(character)
		local hand = findRightHand(character)
		if not hand then
			warn("[SoulFruits.PhysicalFruit] No RightHand — tool only in hotbar")
			return
		end
		local mesh = handle:Clone()
		mesh.Name = HAND_ATTACH_NAME
		mesh.Anchored = false
		mesh.CanCollide = false
		mesh.Massless = true
		mesh.CFrame = hand.CFrame * CFrame.new(0, -0.2, -0.6)
		mesh.Parent = character
		local weld = Instance.new("WeldConstraint")
		weld.Part0 = hand
		weld.Part1 = mesh
		weld.Parent = mesh
	end)

	tool.Unequipped:Connect(function()
		local plr = Players:GetPlayerFromCharacter(tool.Parent :: any)
			or (tool.Parent and tool.Parent:IsA("Player") and tool.Parent)
		-- Unequipped: tool goes to backpack; clear hand mesh from character
		for _, p in Players:GetPlayers() do
			if p:FindFirstChildOfClass("Backpack") == tool.Parent or (p.Character and tool.Parent == p.Character) then
				clearHandMesh(p.Character)
			end
		end
		-- Safer: scan all characters owning this fruit tool owner
		local owner: Player? = nil
		for _, p in Players:GetPlayers() do
			local bp = p:FindFirstChildOfClass("Backpack")
			if bp and tool.Parent == bp then
				owner = p
				break
			end
		end
		if owner then
			clearHandMesh(owner.Character)
		end
	end)

	return tool
end

local function findHeldPhysicalTool(player: Player): Tool?
	local function scan(container: Instance?): Tool?
		if not container then
			return nil
		end
		for _, child in container:GetChildren() do
			if child:IsA("Tool") and child:GetAttribute(ATTR_PHYSICAL) == true then
				return child
			end
		end
		return nil
	end
	local charTool = scan(player.Character)
	if charTool then
		return charTool
	end
	return scan(player:FindFirstChildOfClass("Backpack"))
end

local function destroyAllPhysicalTools(player: Player)
	local function wipe(container: Instance?)
		if not container then
			return
		end
		for _, child in container:GetChildren() do
			if child:IsA("Tool") and child:GetAttribute(ATTR_PHYSICAL) == true then
				child:Destroy()
			end
		end
	end
	wipe(player.Character)
	wipe(player:FindFirstChildOfClass("Backpack"))
	clearHandMesh(player.Character)
end

local function pulseSpin(player: Player, fruitId: string)
	local character = player.Character
	if character then
		character:SetAttribute(ATTR_SPIN, tick())
		character:SetAttribute("SF_SpinFruitId", fruitId)
	end
	player:SetAttribute(ATTR_SPIN, tick())
	player:SetAttribute("SF_SpinFruitId", fruitId)
	Remotes.Event("FruitSpin"):FireClient(player, fruitId)
end

--- Gacha/Stock: ONLY storage, never tool / never eat
function PhysicalFruitService.GrantToStorage(player: Player, fruitId: string, playSpin: boolean?): boolean
	fruitId = normalizeFruitId(fruitId)
	if not FruitsConfig.Fruits[fruitId] then
		warn(("[SoulFruits.PhysicalFruit] Unknown fruit %s"):format(tostring(fruitId)))
		return false
	end

	local data = DataManager.Get(player)
	if not data then
		return false
	end
	local storage = (data :: any).FruitStorage or {}
	if storage[fruitId] == true then
		Remotes.Event("Notify"):FireClient(player, ("Schon im Lager: %s"):format(fruitId))
		if playSpin ~= false then
			pulseSpin(player, fruitId)
		end
		return true
	end

	DataManager.Update(player, function(profile)
		if not (profile :: any).FruitStorage then
			(profile :: any).FruitStorage = {}
		end
		(profile :: any).FruitStorage[fruitId] = true
	end)

	if playSpin ~= false then
		pulseSpin(player, fruitId)
	end
	Remotes.Event("Notify"):FireClient(player, ("Lager: %s — Ausrüsten → Essen"):format(fruitId))
	pushStorage(player)
	return true
end

-- Back-compat name used by older callers
function PhysicalFruitService.GivePhysical(player: Player, fruitId: string, playSpin: boolean?): boolean
	return PhysicalFruitService.GrantToStorage(player, fruitId, playSpin)
end

--- Lager → Hotbar tool + hand mesh
function PhysicalFruitService.EquipFromStorage(player: Player, fruitId: string): boolean
	fruitId = normalizeFruitId(fruitId)
	if not FruitsConfig.Fruits[fruitId] then
		return false
	end
	local data = DataManager.Get(player)
	if not data then
		return false
	end
	local storage = (data :: any).FruitStorage or {}
	if storage[fruitId] ~= true then
		Remotes.Event("Notify"):FireClient(player, "Nicht im Lager.")
		return false
	end

	-- Only one physical tool at a time
	destroyAllPhysicalTools(player)

	DataManager.Update(player, function(profile)
		if (profile :: any).FruitStorage then
			(profile :: any).FruitStorage[fruitId] = nil
		end
	end)

	local tool = createFruitTool(fruitId)
	if not tool then
		-- rollback storage
		DataManager.Update(player, function(profile)
			if not (profile :: any).FruitStorage then
				(profile :: any).FruitStorage = {}
			end
			(profile :: any).FruitStorage[fruitId] = true
		end)
		return false
	end

	local backpack = player:FindFirstChildOfClass("Backpack")
	if not backpack then
		tool:Destroy()
		DataManager.Update(player, function(profile)
			if not (profile :: any).FruitStorage then
				(profile :: any).FruitStorage = {}
			end
			(profile :: any).FruitStorage[fruitId] = true
		end)
		return false
	end
	tool.Parent = backpack
	local character = player.Character
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	if humanoid and humanoid.Health > 0 then
		pcall(function()
			humanoid:EquipTool(tool)
		end)
	end
	Remotes.Event("Notify"):FireClient(player, ("Ausgerüstet: %s — E essen / B zurück Lager"):format(fruitId))
	pushStorage(player)
	return true
end

function PhysicalFruitService.Retrieve(player: Player, fruitId: string): boolean
	return PhysicalFruitService.EquipFromStorage(player, fruitId)
end

function PhysicalFruitService.Eat(player: Player): boolean
	local tool = findHeldPhysicalTool(player)
	if not tool then
		Remotes.Event("Notify"):FireClient(player, "Keine Frucht in Hand/Hotbar — erst aus Lager ausrüsten.")
		return false
	end
	local fruitId = tool:GetAttribute(ATTR_FRUIT_ID)
	if typeof(fruitId) ~= "string" then
		return false
	end
	fruitId = normalizeFruitId(fruitId)
	if not FruitsConfig.Fruits[fruitId] then
		return false
	end

	local data = DataManager.Get(player)
	if not data then
		return false
	end
	-- Only ONE eaten fruit at a time — second stays in lager (can't eat)
	if data.CurrentFruit ~= nil and data.CurrentFruit ~= "" then
		Remotes.Event("Notify"):FireClient(player, ("Schon aktiv: %s — nur 1 Fruit gleichzeitig"):format(tostring(data.CurrentFruit)))
		return false
	end

	local character = player.Character
	if character then
		character:SetAttribute(ATTR_EAT, tick())
		character:SetAttribute("SF_EatFruitId", fruitId)
	end
	player:SetAttribute(ATTR_EAT, tick())
	player:SetAttribute("SF_EatFruitId", fruitId)
	Remotes.Event("FruitEatFX"):FireClient(player, fruitId)

	clearHandMesh(character)
	tool:Destroy()

	DataManager.Update(player, function(profile)
		if not profile.OwnedFruits then
			profile.OwnedFruits = {}
		end
		profile.OwnedFruits[fruitId] = true
		if not profile.FruitMastery then
			profile.FruitMastery = {}
		end
		if typeof(profile.FruitMastery[fruitId]) ~= "number" then
			profile.FruitMastery[fruitId] = 0
		end
		profile.CurrentFruit = fruitId
		if fruitId == "Dreck" then
			profile.HatDreckFruit = true
		end
	end)

	FruitService.OnFruitEaten(player, fruitId)
	Remotes.Event("Notify"):FireClient(player, ("Gegessen: %s — Z/X/C/V aktiv"):format(fruitId))
	pushStorage(player)
	return true
end

--- B: uneaten tool → storage
function PhysicalFruitService.Store(player: Player): boolean
	local tool = findHeldPhysicalTool(player)
	if not tool then
		Remotes.Event("Notify"):FireClient(player, "Keine ungegessene Frucht in der Hotbar.")
		return false
	end
	local fruitId = tool:GetAttribute(ATTR_FRUIT_ID)
	if typeof(fruitId) ~= "string" then
		return false
	end
	fruitId = normalizeFruitId(fruitId)

	local data = DataManager.Get(player)
	if not data then
		return false
	end
	local storage = (data :: any).FruitStorage or {}
	if storage[fruitId] == true then
		Remotes.Event("Notify"):FireClient(player, "Lager-Slot für diesen Typ schon belegt.")
		return false
	end

	clearHandMesh(player.Character)
	tool:Destroy()

	DataManager.Update(player, function(profile)
		if not (profile :: any).FruitStorage then
			(profile :: any).FruitStorage = {}
		end
		(profile :: any).FruitStorage[fruitId] = true
	end)
	Remotes.Event("Notify"):FireClient(player, ("Zurück ins Lager: %s"):format(fruitId))
	pushStorage(player)
	return true
end

function PhysicalFruitService.Start()
	if started then
		return
	end
	started = true

	Remotes.Event("FruitEat").OnServerEvent:Connect(function(player)
		if not AntiCheat.Validate(player, "FruitEat", { cooldown = 1.0, maxPerSecond = 2, maxArgs = 0 }) then
			return
		end
		PhysicalFruitService.Eat(player)
	end)

	Remotes.Event("FruitStore").OnServerEvent:Connect(function(player)
		if not AntiCheat.Validate(player, "FruitStore", { cooldown = 0.5, maxPerSecond = 3, maxArgs = 0 }) then
			return
		end
		PhysicalFruitService.Store(player)
	end)

	Remotes.Event("FruitRetrieve").OnServerEvent:Connect(function(player, fruitId)
		if not AntiCheat.Validate(player, "FruitRetrieve", {
			cooldown = 0.5,
			maxPerSecond = 3,
			maxArgs = 1,
			argTypes = { "string" },
		}, fruitId) then
			return
		end
		if typeof(fruitId) ~= "string" then
			return
		end
		PhysicalFruitService.EquipFromStorage(player, fruitId)
	end)

	Players.PlayerAdded:Connect(function(player)
		task.defer(function()
			DataManager.WaitFor(player, 20)
			pushStorage(player)
		end)
		player.CharacterAdded:Connect(function()
			clearHandMesh(player.Character)
		end)
	end)
	for _, player in Players:GetPlayers() do
		task.defer(function()
			DataManager.WaitFor(player, 20)
			pushStorage(player)
		end)
	end

	print("[SoulFruits.PhysicalFruit] Lager→Ausrüsten→Essen online")
end

return PhysicalFruitService
