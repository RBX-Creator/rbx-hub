--!strict
--[[
	FruitService – Equip + fruit moves (Z/X/C/V) + Special R, server-validated.
	Supports Dreck, Wind, Flame, Ice, Light, Magma + Blutaugespiegel (Legendary)
	+ Sharingan (Mythical: Tomoe/Genjutsu/Copy/Amaterasu + Partial Susanoo).
	Studio: ServerScriptService/SoulFruits/Systems/FruitService (ModuleScript)
]]

local Players = game:GetService("Players")
local Workspace = game:GetService("Workspace")
local Debris = game:GetService("Debris")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Shared = ReplicatedStorage:WaitForChild("SoulFruits"):WaitForChild("Shared")
local Config = require(Shared:WaitForChild("Config"))
local FruitsConfig = require(Shared:WaitForChild("FruitsConfig"))
local Remotes = require(Shared:WaitForChild("Remotes"))

local DataManager = require(script.Parent.Parent.Data:WaitForChild("DataManager"))
local EnergyService = require(script.Parent:WaitForChild("EnergyService"))
local AntiCheat = require(script.Parent:WaitForChild("AntiCheat"))

type MoveDef = FruitsConfig.MoveDef
type CooldownMap = { [string]: number }

local FruitService = {}
local started = false
local moveCds: { [Player]: CooldownMap } = {}

local VFX_BY_KEY = {
	Z = Config.VFX.FruitZ,
	X = Config.VFX.FruitX,
	C = Config.VFX.FruitC,
	V = Config.VFX.FruitV,
}

local ATTR_STUN_MARK = "SF_StunMark"
local ATTR_PARRY_UNTIL = "SF_ParryUntil"
local ATTR_LAST_M1 = "SF_LastM1Damage"
local ATTR_CONFUSION = "SF_ConfusionUntil"
local ATTR_FREEZE = "SF_FreezeUntil"
local ATTR_BURN = "SF_BurnUntil"
local ATTR_IFRAMES = "SF_IFramesUntil"
local ATTR_SUSANOO_UNTIL = "SF_SusanooUntil"
local ATTR_SHARINGAN_SIGHT = "SF_SharinganSight"
local ATTR_GENJUTSU_LOCK = "SF_GenjutsuLock"
local ATTR_AMATERASU = "SF_AmaterasuUntil"
local ATTR_TOMOE_M1 = "SF_TomoeM1"
local PARRY_DURATION = 2.5
local SUSANOO_DURATION = 3.2
local SUSANOO_DURATION_AWAKENED = 4.0
local GENJUTSU_LOCK_DURATION = 2.4
local AMATERASU_TICKS = 5
local AMATERASU_INTERVAL = 0.5
local IFRAMES_DURATION = 0.55
local STUN_MARK_DURATION = 1.6
local SLOW_FACTOR = 0.45
local CONFUSION_DURATION = 2.2
local FREEZE_DURATION = 1.8
local BURN_TICKS = 3
local BURN_INTERVAL = 0.4
local DOT_TICKS = 4
local DOT_INTERVAL = 0.45
local MAGMA_POOL_TICKS = 5
local MAGMA_POOL_INTERVAL = 0.5
local LIGHT_BARRAGE_HITS = 4
local LIGHT_BARRAGE_GAP = 0.12
local ELEMENT_COLORS = {
	Dreck = Color3.fromRGB(110, 85, 55),
	Wind = Color3.fromRGB(180, 220, 255),
	Flame = Color3.fromRGB(255, 110, 40),
	Ice = Color3.fromRGB(140, 210, 255),
	Light = Color3.fromRGB(255, 245, 180),
	Magma = Color3.fromRGB(220, 60, 20),
	Blutaugespiegel = Color3.fromRGB(140, 20, 40),
	Sharingan = Color3.fromRGB(200, 25, 35),
}

local function getCds(player: Player): CooldownMap
	local map = moveCds[player]
	if not map then
		map = {}
		moveCds[player] = map
	end
	return map
end

local function getFaction(player: Player): string?
	local data = DataManager.Get(player)
	if data and data.Faction then
		return data.Faction
	end
	local attr = player:GetAttribute("SF_Faction")
	if typeof(attr) == "string" then
		return attr
	end
	return nil
end

--- Same Gut/Bose rules as CombatService.
local function canDamage(attacker: Player, targetHumanoid: Humanoid): boolean
	local targetChar = targetHumanoid.Parent
	if not targetChar or not targetChar:IsA("Model") then
		return false
	end
	local targetPlayer = Players:GetPlayerFromCharacter(targetChar)
	if not targetPlayer then
		return true
	end
	if targetPlayer == attacker then
		return false
	end
	local atkFaction = getFaction(attacker)
	local tgtFaction = getFaction(targetPlayer)
	if atkFaction == Config.FACTIONS.Gut and tgtFaction == Config.FACTIONS.Gut then
		return false
	end
	return true
end

local function getRoot(character: Model): BasePart?
	local hrp = character:FindFirstChild("HumanoidRootPart")
	if hrp and hrp:IsA("BasePart") then
		return hrp
	end
	return character.PrimaryPart
end

local function pulseVfx(character: Model, attrName: string)
	character:SetAttribute(attrName, tick())
	local be = character:FindFirstChild(attrName)
	if be and be:IsA("BindableEvent") then
		be:Fire()
	end
end

local function replicateFruitAttrs(player: Player)
	local data = DataManager.Get(player)
	if not data then
		return
	end
	player:SetAttribute("SF_CurrentFruit", data.CurrentFruit)
	player:SetAttribute("SF_HatDreckFruit", data.HatDreckFruit == true)
	player:SetAttribute("SF_DreckMastery", data.DreckMastery or 0)
	player:SetAttribute("SF_BlutaugespiegelMastery", data.BlutaugespiegelMastery or 0)
	local fm = data.FruitMastery or {}
	player:SetAttribute("SF_WindMastery", fm.Wind or 0)
	player:SetAttribute("SF_FlameMastery", fm.Flame or 0)
	player:SetAttribute("SF_IceMastery", fm.Ice or 0)
	player:SetAttribute("SF_LightMastery", fm.Light or 0)
	player:SetAttribute("SF_MagmaMastery", fm.Magma or 0)
	player:SetAttribute("SF_SharinganMastery", fm.Sharingan or 0)
	-- Mangekyo stub flag (profile); false until later content
	player:SetAttribute("SF_SharinganAwakened", data.SharinganAwakened == true)
	-- Passive: Sharingan Sight while Mythical fruit equipped
	local sightOn = data.CurrentFruit == "Sharingan"
	player:SetAttribute(ATTR_SHARINGAN_SIGHT, sightOn)
	local character = player.Character
	if character then
		character:SetAttribute("SF_CurrentFruit", data.CurrentFruit)
		character:SetAttribute(ATTR_SHARINGAN_SIGHT, sightOn)
	end
end

function FruitService.HasDreck(player: Player): boolean
	local data = DataManager.Get(player)
	if not data then
		return false
	end
	if data.HatDreckFruit then
		return true
	end
	if data.CurrentFruit == "Dreck" then
		return true
	end
	if data.OwnedFruits and data.OwnedFruits.Dreck then
		return true
	end
	return false
end

function FruitService.CanUseDreckMoves(player: Player): boolean
	local data = DataManager.Get(player)
	if not data then
		return false
	end
	if data.CurrentFruit == "Dreck" then
		return true
	end
	if data.HatDreckFruit and (data.CurrentFruit == nil or data.CurrentFruit == "" or data.CurrentFruit == "Dreck") then
		return true
	end
	return false
end

function FruitService.GetEquippedFruitId(player: Player): string?
	local data = DataManager.Get(player)
	if not data then
		return nil
	end
	local current = data.CurrentFruit
	if typeof(current) == "string" and current ~= "" then
		return current
	end
	if data.HatDreckFruit then
		return "Dreck"
	end
	return nil
end

function FruitService.CanUseFruitMoves(player: Player, fruitId: string): boolean
	if fruitId == "Dreck" then
		return FruitService.CanUseDreckMoves(player)
	end
	local data = DataManager.Get(player)
	if not data then
		return false
	end
	return data.CurrentFruit == fruitId
end

--- Called after Stock buy / Gacha grant.
function FruitService.OnFruitGranted(player: Player, fruitId: string)
	replicateFruitAttrs(player)
	if not FruitsConfig.Fruits[fruitId] then
		return
	end
	DataManager.Update(player, function(profile)
		if not profile.OwnedFruits then
			profile.OwnedFruits = {}
		end
		profile.OwnedFruits[fruitId] = true
		if not profile.FruitMastery then
			profile.FruitMastery = {}
		end
		if typeof(profile.FruitMastery[fruitId]) ~= "number" then
			profile.FruitMastery[fruitId] = 0
		end
		if fruitId == "Dreck" then
			profile.HatDreckFruit = true
			if typeof(profile.DreckMastery) ~= "number" then
				profile.DreckMastery = 0
			end
		elseif fruitId == "Blutaugespiegel" then
			if typeof(profile.BlutaugespiegelMastery) ~= "number" then
				profile.BlutaugespiegelMastery = 0
			end
		elseif fruitId == "Sharingan" then
			if typeof(profile.SharinganAwakened) ~= "boolean" then
				profile.SharinganAwakened = false -- Mangekyo stub; do not auto-awaken
			end
		end
		if profile.CurrentFruit == nil or profile.CurrentFruit == "" then
			profile.CurrentFruit = fruitId
		end
	end)
	replicateFruitAttrs(player)
end

local function applyDamageInBox(attacker: Player, character: Model, cf: CFrame, size: Vector3, damage: number): number
	local overlap = OverlapParams.new()
	overlap.FilterType = Enum.RaycastFilterType.Exclude
	overlap.FilterDescendantsInstances = { character }
	overlap.MaxParts = 40

	local parts = Workspace:GetPartBoundsInBox(cf, size, overlap)
	local seen: { [Humanoid]: boolean } = {}
	local hitCount = 0
	for _, part in parts do
		local model = part:FindFirstAncestorOfClass("Model")
		if not model then
			continue
		end
		local humanoid = model:FindFirstChildOfClass("Humanoid")
		if humanoid and humanoid.Health > 0 and not seen[humanoid] then
			seen[humanoid] = true
			if canDamage(attacker, humanoid) then
				-- Respect target parry window (same as CombatService)
				local tgtPlayer = Players:GetPlayerFromCharacter(model)
				local parryUntil = if tgtPlayer then tgtPlayer:GetAttribute(ATTR_PARRY_UNTIL) else model:GetAttribute(ATTR_PARRY_UNTIL)
				local iframesUntil = if tgtPlayer then tgtPlayer:GetAttribute(ATTR_IFRAMES) else model:GetAttribute(ATTR_IFRAMES)
				local susUntil = if tgtPlayer then tgtPlayer:GetAttribute(ATTR_SUSANOO_UNTIL) else model:GetAttribute(ATTR_SUSANOO_UNTIL)
				if typeof(parryUntil) == "number" and parryUntil > tick() then
					if tgtPlayer then
						tgtPlayer:SetAttribute(ATTR_PARRY_UNTIL, 0)
					end
					model:SetAttribute(ATTR_PARRY_UNTIL, 0)
					-- Negate this hit
				elseif typeof(iframesUntil) == "number" and iframesUntil > tick() then
					-- Light Flash i-frames: ignore without consuming early
				elseif damage > 0 then
					local applied = damage
					if typeof(susUntil) == "number" and susUntil > tick() then
						applied = damage * 0.45 -- Partial Susanoo DR (~55%)
					end
					humanoid:TakeDamage(applied)
					hitCount += 1
				else
					hitCount += 1
				end
			end
		end
	end
	return hitCount
end

local function spawnStubProjectile(character: Model, root: BasePart, move: any, key: string, fruitId: string?)
	local part = Instance.new("Part")
	part.Name = "SF_FruitStub_" .. key
	part.Size = move.HitboxSize
	part.Shape = Enum.PartType.Ball
	part.Material = Enum.Material.Neon
	local color = ELEMENT_COLORS[fruitId or "Dreck"] or ELEMENT_COLORS.Dreck
	part.Color = color
	part.CanCollide = false
	part.Anchored = true
	part.CastShadow = false
	part.CFrame = root.CFrame * CFrame.new(0, 1, -3)
	part.Parent = Workspace
	Debris:AddItem(part, 2)

	local look = root.CFrame.LookVector
	local speed = move.ProjectileSpeed
	local traveled = 0
	local step = 0.05
	task.spawn(function()
		while part.Parent and traveled < move.Range do
			local dist = speed * step
			traveled += dist
			part.CFrame = part.CFrame + look * dist
			task.wait(step)
		end
		if part.Parent then
			part:Destroy()
		end
	end)
	return part, look
end

local function spawnErdwallStub(root: BasePart)
	local wall = Instance.new("Part")
	wall.Name = "SF_Erdwall"
	wall.Size = Vector3.new(8, 10, 2)
	wall.Material = Enum.Material.Slate
	wall.Color = Color3.fromRGB(90, 70, 45)
	wall.Anchored = true
	wall.CanCollide = true
	wall.CFrame = root.CFrame * CFrame.new(0, 4, -6)
	wall.Parent = Workspace
	Debris:AddItem(wall, 6)
end

local function bumpMastery(player: Player, fruitId: string)
	DataManager.Update(player, function(profile)
		if fruitId == "Dreck" then
			profile.DreckMastery = (profile.DreckMastery or 0) + 1
		elseif fruitId == "Blutaugespiegel" then
			profile.BlutaugespiegelMastery = (profile.BlutaugespiegelMastery or 0) + 1
		end
		-- Optional open map for future fruits
		if not profile.FruitMastery then
			profile.FruitMastery = {}
		end
		profile.FruitMastery[fruitId] = (profile.FruitMastery[fruitId] or 0) + 1
	end)
	replicateFruitAttrs(player)
end

local function findNearestInCone(attacker: Player, character: Model, root: BasePart, range: number, halfAngleDeg: number): (Humanoid?, Model?)
	local look = root.CFrame.LookVector
	local bestHum: Humanoid? = nil
	local bestModel: Model? = nil
	local bestDist = range + 1
	local cosThresh = math.cos(math.rad(halfAngleDeg))

	for _, other in Players:GetPlayers() do
		if other == attacker then
			continue
		end
		local otherChar = other.Character
		if not otherChar then
			continue
		end
		local hum = otherChar:FindFirstChildOfClass("Humanoid")
		local otherRoot = getRoot(otherChar)
		if not hum or hum.Health <= 0 or not otherRoot then
			continue
		end
		if not canDamage(attacker, hum) then
			continue
		end
		local offset = otherRoot.Position - root.Position
		local dist = offset.Magnitude
		if dist > range or dist < 0.5 then
			continue
		end
		local dir = offset.Unit
		if look:Dot(dir) < cosThresh then
			continue
		end
		if dist < bestDist then
			bestDist = dist
			bestHum = hum
			bestModel = otherChar
		end
	end

	-- Also scan nearby models (NPCs) via overlap as fallback
	local overlap = OverlapParams.new()
	overlap.FilterType = Enum.RaycastFilterType.Exclude
	overlap.FilterDescendantsInstances = { character }
	overlap.MaxParts = 48
	local center = root.Position + look * (range * 0.5)
	local cf = CFrame.lookAt(center, center + look)
	local size = Vector3.new(range * 0.7, 10, range)
	local parts = Workspace:GetPartBoundsInBox(cf, size, overlap)
	for _, part in parts do
		local model = part:FindFirstAncestorOfClass("Model")
		if not model or model == character then
			continue
		end
		local hum = model:FindFirstChildOfClass("Humanoid")
		local otherRoot = getRoot(model)
		if not hum or hum.Health <= 0 or not otherRoot then
			continue
		end
		if not canDamage(attacker, hum) then
			continue
		end
		local offset = otherRoot.Position - root.Position
		local dist = offset.Magnitude
		if dist > range or dist < 0.5 then
			continue
		end
		local dir = offset.Unit
		if look:Dot(dir) < cosThresh then
			continue
		end
		if dist < bestDist then
			bestDist = dist
			bestHum = hum
			bestModel = model
		end
	end

	return bestHum, bestModel
end

local function applySlowBrief(humanoid: Humanoid, model: Model, duration: number)
	local original = humanoid.WalkSpeed
	model:SetAttribute(ATTR_STUN_MARK, tick() + duration)
	humanoid.WalkSpeed = math.max(4, original * SLOW_FACTOR)
	task.delay(duration, function()
		if humanoid.Parent then
			-- Restore only if still slowed by us (simple stub)
			if humanoid.WalkSpeed <= original * SLOW_FACTOR + 0.5 then
				humanoid.WalkSpeed = original
			end
		end
		if model.Parent then
			local untilT = model:GetAttribute(ATTR_STUN_MARK)
			if typeof(untilT) == "number" and untilT <= tick() + 0.05 then
				model:SetAttribute(ATTR_STUN_MARK, 0)
			end
		end
	end)
end

local function applyConfusionAndDot(attacker: Player, character: Model, root: BasePart, move: MoveDef)
	local look = root.CFrame.LookVector
	local center = root.Position
	local cf = CFrame.new(center)
	local size = move.HitboxSize

	local overlap = OverlapParams.new()
	overlap.FilterType = Enum.RaycastFilterType.Exclude
	overlap.FilterDescendantsInstances = { character }
	overlap.MaxParts = 48

	local parts = Workspace:GetPartBoundsInBox(cf, size, overlap)
	local seen: { [Humanoid]: boolean } = {}
	local targets: { { hum: Humanoid, model: Model } } = {}

	for _, part in parts do
		local model = part:FindFirstAncestorOfClass("Model")
		if not model then
			continue
		end
		local humanoid = model:FindFirstChildOfClass("Humanoid")
		if humanoid and humanoid.Health > 0 and not seen[humanoid] then
			seen[humanoid] = true
			if canDamage(attacker, humanoid) then
				table.insert(targets, { hum = humanoid, model = model })
			end
		end
	end

	for _, entry in targets do
		local hum = entry.hum
		local model = entry.model
		local original = hum.WalkSpeed
		model:SetAttribute(ATTR_CONFUSION, tick() + CONFUSION_DURATION)
		-- Slow + "invert feel": reduce speed hard (true invert needs client; server stub)
		hum.WalkSpeed = math.max(3, original * 0.35)
		local tgtPlayer = Players:GetPlayerFromCharacter(model)
		if tgtPlayer then
			tgtPlayer:SetAttribute(ATTR_CONFUSION, tick() + CONFUSION_DURATION)
		end

		task.delay(CONFUSION_DURATION, function()
			if hum.Parent and hum.WalkSpeed <= original * 0.4 + 0.5 then
				hum.WalkSpeed = original
			end
			if model.Parent then
				model:SetAttribute(ATTR_CONFUSION, 0)
			end
			if tgtPlayer then
				tgtPlayer:SetAttribute(ATTR_CONFUSION, 0)
			end
		end)

		-- Light DoT ticks
		task.spawn(function()
			for _ = 1, DOT_TICKS do
				task.wait(DOT_INTERVAL)
				if not hum.Parent or hum.Health <= 0 then
					break
				end
				if not canDamage(attacker, hum) then
					break
				end
				local dmg = move.Damage
				if dmg > 0 then
					hum:TakeDamage(dmg)
				end
			end
		end)
	end

	-- Visual stub ring
	local ring = Instance.new("Part")
	ring.Name = "SF_BlutspiegelWelt"
	ring.Shape = Enum.PartType.Cylinder
	ring.Size = Vector3.new(1.2, size.X, size.Z)
	ring.Material = Enum.Material.ForceField
	ring.Color = Color3.fromRGB(140, 20, 40)
	ring.Anchored = true
	ring.CanCollide = false
	ring.CastShadow = false
	ring.CFrame = CFrame.new(center) * CFrame.Angles(0, 0, math.rad(90))
	ring.Parent = Workspace
	Debris:AddItem(ring, 2.5)
	local _ = look -- keep look referenced for future facing VFX
end


local function applyKnockback(model: Model, direction: Vector3, strength: number)
	local root = getRoot(model)
	if not root then
		return
	end
	local flat = Vector3.new(direction.X, 0, direction.Z)
	if flat.Magnitude < 0.05 then
		return
	end
	flat = flat.Unit
	-- Prefer AssemblyLinearVelocity; fall back to BodyVelocity stub for anchored edge cases
	local ok = pcall(function()
		root.AssemblyLinearVelocity = flat * strength + Vector3.new(0, math.min(28, strength * 0.35), 0)
	end)
	if not ok then
		local bv = Instance.new("BodyVelocity")
		bv.MaxForce = Vector3.new(1e5, 1e5, 1e5)
		bv.Velocity = flat * strength + Vector3.new(0, 12, 0)
		bv.Parent = root
		Debris:AddItem(bv, 0.2)
	end
end

local function applyKnockbackInBox(attacker: Player, character: Model, cf: CFrame, size: Vector3, damage: number, pushDir: Vector3, strength: number): number
	local overlap = OverlapParams.new()
	overlap.FilterType = Enum.RaycastFilterType.Exclude
	overlap.FilterDescendantsInstances = { character }
	overlap.MaxParts = 40
	local parts = Workspace:GetPartBoundsInBox(cf, size, overlap)
	local seen: { [Humanoid]: boolean } = {}
	local hitCount = 0
	for _, part in parts do
		local model = part:FindFirstAncestorOfClass("Model")
		if not model then
			continue
		end
		local humanoid = model:FindFirstChildOfClass("Humanoid")
		if humanoid and humanoid.Health > 0 and not seen[humanoid] then
			seen[humanoid] = true
			if canDamage(attacker, humanoid) then
				if damage > 0 then
					humanoid:TakeDamage(damage)
				end
				applyKnockback(model, pushDir, strength)
				hitCount += 1
			end
		end
	end
	return hitCount
end

local function applyBurnDoT(attacker: Player, humanoid: Humanoid, model: Model, tickDamage: number)
	model:SetAttribute(ATTR_BURN, tick() + BURN_TICKS * BURN_INTERVAL)
	local tgtPlayer = Players:GetPlayerFromCharacter(model)
	if tgtPlayer then
		tgtPlayer:SetAttribute(ATTR_BURN, tick() + BURN_TICKS * BURN_INTERVAL)
	end
	task.spawn(function()
		for _ = 1, BURN_TICKS do
			task.wait(BURN_INTERVAL)
			if not humanoid.Parent or humanoid.Health <= 0 then
				break
			end
			if not canDamage(attacker, humanoid) then
				break
			end
			if tickDamage > 0 then
				humanoid:TakeDamage(tickDamage)
			end
		end
		if model.Parent then
			model:SetAttribute(ATTR_BURN, 0)
		end
		if tgtPlayer then
			tgtPlayer:SetAttribute(ATTR_BURN, 0)
		end
	end)
end

local function applyBurnInBox(attacker: Player, character: Model, cf: CFrame, size: Vector3, damage: number, burnTick: number): number
	local overlap = OverlapParams.new()
	overlap.FilterType = Enum.RaycastFilterType.Exclude
	overlap.FilterDescendantsInstances = { character }
	overlap.MaxParts = 40
	local parts = Workspace:GetPartBoundsInBox(cf, size, overlap)
	local seen: { [Humanoid]: boolean } = {}
	local hitCount = 0
	for _, part in parts do
		local model = part:FindFirstAncestorOfClass("Model")
		if not model then
			continue
		end
		local humanoid = model:FindFirstChildOfClass("Humanoid")
		if humanoid and humanoid.Health > 0 and not seen[humanoid] then
			seen[humanoid] = true
			if canDamage(attacker, humanoid) then
				if damage > 0 then
					humanoid:TakeDamage(damage)
				end
				applyBurnDoT(attacker, humanoid, model, burnTick)
				hitCount += 1
			end
		end
	end
	return hitCount
end

local function applyFreeze(humanoid: Humanoid, model: Model, duration: number)
	local original = humanoid.WalkSpeed
	local untilT = tick() + duration
	model:SetAttribute(ATTR_FREEZE, untilT)
	local tgtPlayer = Players:GetPlayerFromCharacter(model)
	if tgtPlayer then
		tgtPlayer:SetAttribute(ATTR_FREEZE, untilT)
	end
	humanoid.WalkSpeed = math.max(0, original * 0.15)
	task.delay(duration, function()
		if humanoid.Parent and humanoid.WalkSpeed <= original * 0.2 + 0.5 then
			humanoid.WalkSpeed = original
		end
		if model.Parent then
			local u = model:GetAttribute(ATTR_FREEZE)
			if typeof(u) == "number" and u <= tick() + 0.05 then
				model:SetAttribute(ATTR_FREEZE, 0)
			end
		end
		if tgtPlayer then
			tgtPlayer:SetAttribute(ATTR_FREEZE, 0)
		end
	end)
end

local function applyFreezeInBox(attacker: Player, character: Model, cf: CFrame, size: Vector3, damage: number, duration: number): number
	local overlap = OverlapParams.new()
	overlap.FilterType = Enum.RaycastFilterType.Exclude
	overlap.FilterDescendantsInstances = { character }
	overlap.MaxParts = 40
	local parts = Workspace:GetPartBoundsInBox(cf, size, overlap)
	local seen: { [Humanoid]: boolean } = {}
	local hitCount = 0
	for _, part in parts do
		local model = part:FindFirstAncestorOfClass("Model")
		if not model then
			continue
		end
		local humanoid = model:FindFirstChildOfClass("Humanoid")
		if humanoid and humanoid.Health > 0 and not seen[humanoid] then
			seen[humanoid] = true
			if canDamage(attacker, humanoid) then
				if damage > 0 then
					humanoid:TakeDamage(damage)
				end
				applyFreeze(humanoid, model, duration)
				hitCount += 1
			end
		end
	end
	return hitCount
end

local function spawnThemedStub(name: string, size: Vector3, color: Color3, cf: CFrame, lifetime: number, material: Enum.Material?)
	local part = Instance.new("Part")
	part.Name = name
	part.Size = size
	part.Material = material or Enum.Material.ForceField
	part.Color = color
	part.Anchored = true
	part.CanCollide = false
	part.CastShadow = false
	part.CFrame = cf
	part.Parent = Workspace
	Debris:AddItem(part, lifetime)
	return part
end


local function isSharinganAwakened(player: Player): boolean
	local data = DataManager.Get(player)
	if data and data.SharinganAwakened == true then
		return true
	end
	return player:GetAttribute("SF_SharinganAwakened") == true
end

local function applyAmaterasuDoT(attacker: Player, humanoid: Humanoid, model: Model, tickDamage: number, ticks: number?)
	local n = ticks or AMATERASU_TICKS
	local untilT = tick() + n * AMATERASU_INTERVAL
	model:SetAttribute(ATTR_AMATERASU, untilT)
	local tgtPlayer = Players:GetPlayerFromCharacter(model)
	if tgtPlayer then
		tgtPlayer:SetAttribute(ATTR_AMATERASU, untilT)
	end
	task.spawn(function()
		for _ = 1, n do
			task.wait(AMATERASU_INTERVAL)
			if not humanoid.Parent or humanoid.Health <= 0 then
				break
			end
			if not canDamage(attacker, humanoid) then
				break
			end
			if tickDamage > 0 then
				humanoid:TakeDamage(tickDamage)
			end
		end
		if model.Parent then
			model:SetAttribute(ATTR_AMATERASU, 0)
		end
		if tgtPlayer then
			tgtPlayer:SetAttribute(ATTR_AMATERASU, 0)
		end
	end)
end

local function applyAmaterasuInBox(attacker: Player, character: Model, cf: CFrame, size: Vector3, damage: number, tickDmg: number, ticks: number?): number
	local overlap = OverlapParams.new()
	overlap.FilterType = Enum.RaycastFilterType.Exclude
	overlap.FilterDescendantsInstances = { character }
	overlap.MaxParts = 48
	local parts = Workspace:GetPartBoundsInBox(cf, size, overlap)
	local seen: { [Humanoid]: boolean } = {}
	local hitCount = 0
	for _, part in parts do
		local model = part:FindFirstAncestorOfClass("Model")
		if not model then
			continue
		end
		local humanoid = model:FindFirstChildOfClass("Humanoid")
		if humanoid and humanoid.Health > 0 and not seen[humanoid] then
			seen[humanoid] = true
			if canDamage(attacker, humanoid) then
				if damage > 0 then
					humanoid:TakeDamage(damage)
				end
				applyAmaterasuDoT(attacker, humanoid, model, tickDmg, ticks)
				hitCount += 1
			end
		end
	end
	return hitCount
end

local function applyGenjutsuLock(humanoid: Humanoid, model: Model, duration: number)
	local original = humanoid.WalkSpeed
	local untilT = tick() + duration
	model:SetAttribute(ATTR_GENJUTSU_LOCK, untilT)
	model:SetAttribute(ATTR_STUN_MARK, untilT)
	local tgtPlayer = Players:GetPlayerFromCharacter(model)
	if tgtPlayer then
		tgtPlayer:SetAttribute(ATTR_GENJUTSU_LOCK, untilT)
		tgtPlayer:SetAttribute(ATTR_STUN_MARK, untilT)
	end
	humanoid.WalkSpeed = math.max(0, original * 0.08)
	task.delay(duration, function()
		if humanoid.Parent and humanoid.WalkSpeed <= original * 0.12 + 0.5 then
			humanoid.WalkSpeed = original
		end
		if model.Parent then
			model:SetAttribute(ATTR_GENJUTSU_LOCK, 0)
			model:SetAttribute(ATTR_STUN_MARK, 0)
		end
		if tgtPlayer then
			tgtPlayer:SetAttribute(ATTR_GENJUTSU_LOCK, 0)
			tgtPlayer:SetAttribute(ATTR_STUN_MARK, 0)
		end
	end)
end

local function handleWindMove(player: Player, character: Model, root: BasePart, key: string, move: MoveDef)
	local look = root.CFrame.LookVector
	if key == "Z" then
		-- Push: projectile + knockback
		spawnStubProjectile(character, root, move, key, "Wind")
		local center = root.Position + look * math.min(move.Range * 0.5, 22)
		local cf = CFrame.lookAt(center, center + look)
		applyKnockbackInBox(player, character, cf, move.HitboxSize * 1.3, move.Damage, look, 55)
	elseif key == "X" then
		-- Slash: frontal cut
		local center = root.Position + look * (move.Range * 0.45)
		local cf = CFrame.lookAt(center, center + look)
		applyDamageInBox(player, character, cf, move.HitboxSize, move.Damage)
		spawnThemedStub("SF_WindSlash", Vector3.new(10, 0.6, 2), ELEMENT_COLORS.Wind, cf, 0.35)
	elseif key == "C" then
		-- Gust: cone push
		local center = root.Position + look * (move.Range * 0.5)
		local cf = CFrame.lookAt(center, center + look)
		applyKnockbackInBox(player, character, cf, move.HitboxSize, move.Damage, look, 72)
		spawnThemedStub("SF_WindGust", Vector3.new(8, 6, 10), ELEMENT_COLORS.Wind, cf, 0.5)
	elseif key == "V" then
		-- Small Tornado AoE
		local center = root.Position + look * 6
		local cf = CFrame.new(center)
		applyKnockbackInBox(player, character, cf, move.HitboxSize, move.Damage, look, 40)
		task.delay(0.35, function()
			if character.Parent and root.Parent then
				applyDamageInBox(player, character, CFrame.new(root.Position + look * 6), move.HitboxSize * 0.9, move.Damage)
			end
		end)
		local col = spawnThemedStub("SF_WindTornado", Vector3.new(6, 12, 6), ELEMENT_COLORS.Wind, CFrame.new(center + Vector3.new(0, 6, 0)), 1.8, Enum.Material.ForceField)
		col.Shape = Enum.PartType.Cylinder
		col.CFrame = CFrame.new(center + Vector3.new(0, 6, 0)) * CFrame.Angles(0, 0, math.rad(90))
	end
end

local function handleFlameMove(player: Player, character: Model, root: BasePart, key: string, move: MoveDef)
	local look = root.CFrame.LookVector
	if key == "Z" then
		-- Ball: projectile + burn
		spawnStubProjectile(character, root, move, key, "Flame")
		local center = root.Position + look * math.min(move.Range * 0.55, 26)
		local cf = CFrame.lookAt(center, center + look)
		applyBurnInBox(player, character, cf, move.HitboxSize * 1.2, move.Damage, 3)
	elseif key == "X" then
		-- Wave
		local center = root.Position + look * (move.Range * 0.5)
		local cf = CFrame.lookAt(center, center + look)
		applyBurnInBox(player, character, cf, move.HitboxSize, move.Damage, 4)
		spawnThemedStub("SF_FlameWave", Vector3.new(10, 3, 12), ELEMENT_COLORS.Flame, cf, 0.45)
	elseif key == "C" then
		-- Burst around self
		local cf = CFrame.new(root.Position)
		applyBurnInBox(player, character, cf, move.HitboxSize, move.Damage, 5)
		spawnThemedStub("SF_FlameBurst", Vector3.new(12, 8, 12), ELEMENT_COLORS.Flame, cf, 0.5)
	elseif key == "V" then
		-- Eruption AoE DoT
		local center = root.Position + look * 4
		local cf = CFrame.new(center)
		applyBurnInBox(player, character, cf, move.HitboxSize, move.Damage, move.Damage)
		task.spawn(function()
			for _ = 1, 3 do
				task.wait(0.5)
				if not character.Parent or not root.Parent then
					break
				end
				applyDamageInBox(player, character, CFrame.new(root.Position + look * 4), move.HitboxSize * 0.85, move.Damage)
			end
		end)
		spawnThemedStub("SF_FlameEruption", Vector3.new(14, 2, 14), ELEMENT_COLORS.Flame, CFrame.new(center), 2.0)
	end
end

local function handleIceMove(player: Player, character: Model, root: BasePart, key: string, move: MoveDef)
	local look = root.CFrame.LookVector
	if key == "Z" then
		-- Spike projectile
		spawnStubProjectile(character, root, move, key, "Ice")
		local center = root.Position + look * math.min(move.Range * 0.55, 24)
		local cf = CFrame.lookAt(center, center + look)
		applyDamageInBox(player, character, cf, move.HitboxSize * 1.2, move.Damage)
	elseif key == "X" then
		-- Freeze mark / strong slow
		local center = root.Position + look * (move.Range * 0.45)
		local cf = CFrame.lookAt(center, center + look)
		applyFreezeInBox(player, character, cf, move.HitboxSize, move.Damage, FREEZE_DURATION)
		spawnThemedStub("SF_IceFreeze", Vector3.new(8, 6, 10), ELEMENT_COLORS.Ice, cf, 0.6)
	elseif key == "C" then
		-- Ice path frontal + slow
		local center = root.Position + look * (move.Range * 0.5)
		local cf = CFrame.lookAt(center, center + look)
		applyFreezeInBox(player, character, cf, move.HitboxSize, move.Damage, FREEZE_DURATION * 0.7)
		local path = spawnThemedStub("SF_IcePath", Vector3.new(6, 0.8, 18), ELEMENT_COLORS.Ice, root.CFrame * CFrame.new(0, -2.5, -10), 2.5, Enum.Material.Ice)
		path.CanCollide = false
	elseif key == "V" then
		-- Prison AoE freeze
		local center = root.Position + look * 5
		local cf = CFrame.new(center)
		applyFreezeInBox(player, character, cf, move.HitboxSize, move.Damage, FREEZE_DURATION + 0.6)
		spawnThemedStub("SF_IcePrison", Vector3.new(12, 10, 12), ELEMENT_COLORS.Ice, CFrame.new(center + Vector3.new(0, 4, 0)), 2.2, Enum.Material.Ice)
	end
end


local function applyIFrames(player: Player, character: Model, duration: number)
	local untilT = tick() + duration
	player:SetAttribute(ATTR_IFRAMES, untilT)
	character:SetAttribute(ATTR_IFRAMES, untilT)
	-- Soft visual: brief neon flash on HRP
	local root = getRoot(character)
	if root then
		spawnThemedStub("SF_LightFlash", Vector3.new(6, 6, 6), ELEMENT_COLORS.Light, root.CFrame, duration, Enum.Material.Neon)
	end
	task.delay(duration, function()
		if player.Parent then
			local u = player:GetAttribute(ATTR_IFRAMES)
			if typeof(u) == "number" and u <= tick() + 0.05 then
				player:SetAttribute(ATTR_IFRAMES, 0)
			end
		end
		if character.Parent then
			character:SetAttribute(ATTR_IFRAMES, 0)
		end
	end)
end

local function handleLightMove(player: Player, character: Model, root: BasePart, key: string, move: MoveDef)
	local look = root.CFrame.LookVector
	if key == "Z" then
		-- Beam: fast thin ray along look
		local center = root.Position + look * (move.Range * 0.5)
		local cf = CFrame.lookAt(center, center + look)
		applyDamageInBox(player, character, cf, move.HitboxSize, move.Damage)
		local beam = spawnThemedStub(
			"SF_LightBeam",
			Vector3.new(1.2, 1.2, math.min(move.Range, 40)),
			ELEMENT_COLORS.Light,
			root.CFrame * CFrame.new(0, 1, -math.min(move.Range, 40) * 0.5),
			0.28,
			Enum.Material.Neon
		)
		local _ = beam
		-- Fast secondary tip hit (ray feel)
		task.delay(0.08, function()
			if not character.Parent or not root.Parent then
				return
			end
			local tip = root.Position + look * math.min(move.Range * 0.85, 42)
			applyDamageInBox(player, character, CFrame.lookAt(tip, tip + look), Vector3.new(4, 4, 6), move.Damage * 0.45)
		end)
	elseif key == "X" then
		-- Flash: brief i-frames + small blinding burst (no friendly fire self)
		applyIFrames(player, character, IFRAMES_DURATION)
		local cf = CFrame.new(root.Position)
		applyDamageInBox(player, character, cf, move.HitboxSize, move.Damage)
		spawnThemedStub("SF_LightFlashBurst", Vector3.new(10, 10, 10), ELEMENT_COLORS.Light, cf, 0.35, Enum.Material.Neon)
	elseif key == "C" then
		-- Barrage: multi-hit frontal pulses
		local baseLook = look
		task.spawn(function()
			for i = 1, LIGHT_BARRAGE_HITS do
				if not character.Parent or not root.Parent then
					break
				end
				local center = root.Position + baseLook * (move.Range * (0.35 + 0.1 * i))
				local cf = CFrame.lookAt(center, center + baseLook)
				applyDamageInBox(player, character, cf, move.HitboxSize, move.Damage)
				spawnThemedStub("SF_LightBarrage", Vector3.new(3, 3, 3), ELEMENT_COLORS.Light, cf, 0.2, Enum.Material.Neon)
				task.wait(LIGHT_BARRAGE_GAP)
			end
		end)
	elseif key == "V" then
		-- Nova AoE around self
		local cf = CFrame.new(root.Position)
		applyDamageInBox(player, character, cf, move.HitboxSize, move.Damage)
		spawnThemedStub("SF_LightNova", Vector3.new(16, 2, 16), ELEMENT_COLORS.Light, cf, 0.7, Enum.Material.Neon)
		task.delay(0.2, function()
			if character.Parent and root.Parent then
				applyDamageInBox(player, character, CFrame.new(root.Position), move.HitboxSize * 0.85, move.Damage * 0.4)
			end
		end)
	end
end

local function handleMagmaMove(player: Player, character: Model, root: BasePart, key: string, move: MoveDef)
	local look = root.CFrame.LookVector
	if key == "Z" then
		-- Glob: heavy projectile + burn
		spawnStubProjectile(character, root, move, key, "Magma")
		local center = root.Position + look * math.min(move.Range * 0.5, 22)
		local cf = CFrame.lookAt(center, center + look)
		applyBurnInBox(player, character, cf, move.HitboxSize * 1.25, move.Damage, 4)
	elseif key == "X" then
		-- Pool: lingering ground DoT ahead
		local center = root.Position + look * math.min(move.Range * 0.55, 12)
		local poolCf = CFrame.new(center - Vector3.new(0, 2.2, 0))
		local pool = spawnThemedStub("SF_MagmaPool", Vector3.new(12, 1.2, 12), ELEMENT_COLORS.Magma, poolCf, MAGMA_POOL_TICKS * MAGMA_POOL_INTERVAL + 0.3, Enum.Material.Neon)
		pool.CanCollide = false
		task.spawn(function()
			for _ = 1, MAGMA_POOL_TICKS do
				if not character.Parent then
					break
				end
				applyBurnInBox(player, character, CFrame.new(center), move.HitboxSize, move.Damage, 3)
				task.wait(MAGMA_POOL_INTERVAL)
			end
		end)
	elseif key == "C" then
		-- Surge: cone of magma
		local center = root.Position + look * (move.Range * 0.5)
		local cf = CFrame.lookAt(center, center + look)
		applyBurnInBox(player, character, cf, move.HitboxSize, move.Damage, 5)
		spawnThemedStub("SF_MagmaSurge", Vector3.new(10, 5, 14), ELEMENT_COLORS.Magma, cf, 0.55)
	elseif key == "V" then
		-- Volcano AoE with repeating lava ticks
		local center = root.Position + look * 5
		local cf = CFrame.new(center)
		applyBurnInBox(player, character, cf, move.HitboxSize, move.Damage, move.Damage)
		spawnThemedStub("SF_MagmaVolcano", Vector3.new(10, 16, 10), ELEMENT_COLORS.Magma, CFrame.new(center + Vector3.new(0, 7, 0)), 2.4)
		task.spawn(function()
			for _ = 1, 4 do
				task.wait(0.45)
				if not character.Parent or not root.Parent then
					break
				end
				applyBurnInBox(player, character, CFrame.new(root.Position + look * 5), move.HitboxSize * 0.9, move.Damage, 4)
			end
		end)
	end
end

local function handleDreckMove(player: Player, character: Model, root: BasePart, key: string, move: MoveDef)
	local look = root.CFrame.LookVector
	if key == "Z" or key == "X" then
		spawnStubProjectile(character, root, move, key, "Dreck")
		local center = root.Position + look * math.min(move.Range * 0.55, 25)
		local cf = CFrame.lookAt(center, center + look)
		applyDamageInBox(player, character, cf, move.HitboxSize * 1.2, move.Damage)
		task.delay(0.35, function()
			if not character.Parent then
				return
			end
			local c2 = root.Position + look * math.min(move.Range * 0.9, 45)
			applyDamageInBox(player, character, CFrame.lookAt(c2, c2 + look), move.HitboxSize, move.Damage * 0.5)
		end)
	elseif key == "C" then
		local center = root.Position + look * (move.Range * 0.5)
		local cf = CFrame.lookAt(center, center + look)
		applyDamageInBox(player, character, cf, move.HitboxSize, move.Damage)
	elseif key == "V" then
		spawnErdwallStub(root)
		local center = root.Position + look * 5
		applyDamageInBox(player, character, CFrame.lookAt(center, center + look), move.HitboxSize, move.Damage)
	end
end

local function handleBlutaugespiegelMove(player: Player, character: Model, root: BasePart, key: string, move: MoveDef)
	local look = root.CFrame.LookVector

	if key == "Z" then
		-- Spiegelblick: mark nearest enemy in cone + brief slow
		local _hum, model = findNearestInCone(player, character, root, move.Range, 42)
		if model then
			local hum = model:FindFirstChildOfClass("Humanoid")
			if hum then
				applySlowBrief(hum, model, STUN_MARK_DURATION)
				local tgtPlayer = Players:GetPlayerFromCharacter(model)
				if tgtPlayer then
					tgtPlayer:SetAttribute(ATTR_STUN_MARK, tick() + STUN_MARK_DURATION)
				end
			end
		end
	elseif key == "X" then
		-- Echo-Schlag: burst from last M1 damage or fixed
		local last = player:GetAttribute(ATTR_LAST_M1)
		local burst = move.Damage
		if typeof(last) == "number" and last > 0 then
			burst = last * 1.35
		end
		local center = root.Position + look * (move.Range * 0.55)
		local cf = CFrame.lookAt(center, center + look)
		applyDamageInBox(player, character, cf, move.HitboxSize, burst)
	elseif key == "C" then
		-- Voraussicht: parry window
		local untilT = tick() + PARRY_DURATION
		player:SetAttribute(ATTR_PARRY_UNTIL, untilT)
		character:SetAttribute(ATTR_PARRY_UNTIL, untilT)
	elseif key == "V" then
		-- Blutspiegel-Welt: AoE confusion + light DoT
		applyConfusionAndDot(player, character, root, move)
	end
end


local function handleSharinganMove(player: Player, character: Model, root: BasePart, key: string, move: MoveDef)
	local look = root.CFrame.LookVector
	local awakened = isSharinganAwakened(player)
	local dmgMul = if awakened then 1.15 else 1.0

	if key == "Z" then
		-- Tomoe Burst: frontal burst
		local center = root.Position + look * (move.Range * 0.45)
		local cf = CFrame.lookAt(center, center + look)
		applyDamageInBox(player, character, cf, move.HitboxSize, move.Damage * dmgMul)
		spawnThemedStub("SF_TomoeBurst", Vector3.new(8, 6, 10), ELEMENT_COLORS.Sharingan, cf, 0.4, Enum.Material.Neon)
		-- Optional tomoe pulse for Animator
		character:SetAttribute(ATTR_TOMOE_M1, tick())
	elseif key == "X" then
		-- Genjutsu Lock: stun/lock mark on nearest in cone
		local _hum, model = findNearestInCone(player, character, root, move.Range, 40)
		if model then
			local hum = model:FindFirstChildOfClass("Humanoid")
			if hum then
				applyGenjutsuLock(hum, model, GENJUTSU_LOCK_DURATION)
				if move.Damage > 0 then
					hum:TakeDamage(move.Damage * dmgMul)
				end
			end
		end
		spawnThemedStub("SF_GenjutsuLock", Vector3.new(6, 6, 6), ELEMENT_COLORS.Sharingan, root.CFrame * CFrame.new(0, 2, -4), 0.55, Enum.Material.ForceField)
	elseif key == "C" then
		-- Copy Glance: Echo-like burst from last M1
		local last = player:GetAttribute(ATTR_LAST_M1)
		local burst = move.Damage * dmgMul
		if typeof(last) == "number" and last > 0 then
			burst = last * 1.45 * dmgMul
		end
		local center = root.Position + look * (move.Range * 0.55)
		local cf = CFrame.lookAt(center, center + look)
		applyDamageInBox(player, character, cf, move.HitboxSize, burst)
		spawnThemedStub("SF_CopyGlance", Vector3.new(7, 5, 8), ELEMENT_COLORS.Sharingan, cf, 0.35, Enum.Material.Neon)
	elseif key == "V" then
		-- Amaterasu: lingering black-flame DoT AoE
		local center = root.Position + look * 5
		local cf = CFrame.new(center)
		local tickDmg = move.Damage * dmgMul
		local ticks = if awakened then AMATERASU_TICKS + 2 else AMATERASU_TICKS
		applyAmaterasuInBox(player, character, cf, move.HitboxSize, tickDmg, tickDmg, ticks)
		-- Extra lingering ground ticks (black flame feel)
		local pool = spawnThemedStub(
			"SF_Amaterasu",
			Vector3.new(14, 1.4, 14),
			Color3.fromRGB(10, 5, 8),
			CFrame.new(center - Vector3.new(0, 2.1, 0)),
			ticks * AMATERASU_INTERVAL + 0.4,
			Enum.Material.Neon
		)
		pool.CanCollide = false
		task.spawn(function()
			for _ = 1, ticks do
				task.wait(AMATERASU_INTERVAL)
				if not character.Parent then
					break
				end
				-- Ground residual only (DoT already applied on first hit); light refresh damage
				applyDamageInBox(player, character, CFrame.new(center), move.HitboxSize * 0.9, tickDmg * 0.35)
			end
		end)
	end
end

local function handleFruitSpecial(player: Player, keyArg: any)
	if not AntiCheat.Validate(player, "FruitSpecial", {
		cooldown = 0.2,
		maxPerSecond = 6,
		maxArgs = 1,
		argTypes = { "string" },
	}, keyArg) then
		return
	end
	if typeof(keyArg) ~= "string" then
		return
	end
	local key = string.upper(keyArg)
	if table.find(FruitsConfig.VALID_SPECIAL_KEYS, key) == nil then
		return
	end

	local fruitId = FruitService.GetEquippedFruitId(player)
	if not fruitId then
		Remotes.Event("Notify"):FireClient(player, "Keine Fruit ausgerüstet.")
		return
	end
	local specials = FruitsConfig.GetSpecial(fruitId)
	if not specials then
		return
	end
	local move = specials[key]
	if not move then
		return
	end
	if not FruitService.CanUseFruitMoves(player, fruitId) then
		Remotes.Event("Notify"):FireClient(player, "Fruit nicht nutzbar.")
		return
	end

	local character = player.Character
	if not character then
		return
	end
	local humanoid = character:FindFirstChildOfClass("Humanoid")
	if not humanoid or humanoid.Health <= 0 then
		return
	end
	local root = getRoot(character)
	if not root then
		return
	end

	local now = os.clock()
	local cds = getCds(player)
	local cdKey = fruitId .. "_Special_" .. key
	local last = cds[cdKey] or 0
	if (now - last) < move.Cooldown then
		return
	end

	if not EnergyService.Spend(player, move.Cost) then
		Remotes.Event("Notify"):FireClient(player, "Nicht genug Chakra.")
		return
	end

	cds[cdKey] = now

	-- Susanoo VFX / Animator hook (do NOT hijack F — flight stays MovementService)
	local susanooVfx = Config.VFX.Susanoo
	if susanooVfx then
		pulseVfx(character, susanooVfx)
	end

	if fruitId == "Sharingan" and key == "R" then
		local awakened = isSharinganAwakened(player)
		local duration = if awakened then SUSANOO_DURATION_AWAKENED else SUSANOO_DURATION
		local untilT = tick() + duration
		player:SetAttribute(ATTR_SUSANOO_UNTIL, untilT)
		character:SetAttribute(ATTR_SUSANOO_UNTIL, untilT)

		local center = root.Position
		local cf = CFrame.new(center)
		local dmg = move.Damage * (if awakened then 1.2 else 1.0)
		applyDamageInBox(player, character, cf, move.HitboxSize, dmg)
		spawnThemedStub(
			"SF_PartialSusanoo",
			Vector3.new(10, 12, 10),
			Color3.fromRGB(120, 20, 40),
			CFrame.new(center + Vector3.new(0, 4, 0)),
			duration,
			Enum.Material.ForceField
		)
		-- Small follow-up pulse
		task.delay(0.25, function()
			if character.Parent and root.Parent then
				applyDamageInBox(player, character, CFrame.new(root.Position), move.HitboxSize * 0.85, dmg * 0.4)
			end
		end)
		task.delay(duration, function()
			if player.Parent then
				local u = player:GetAttribute(ATTR_SUSANOO_UNTIL)
				if typeof(u) == "number" and u <= tick() + 0.05 then
					player:SetAttribute(ATTR_SUSANOO_UNTIL, 0)
				end
			end
			if character.Parent then
				character:SetAttribute(ATTR_SUSANOO_UNTIL, 0)
			end
		end)
	end

	bumpMastery(player, fruitId)
end

local function handleMove(player: Player, keyArg: any)
	if not AntiCheat.Validate(player, "FruitMove", {
		cooldown = 0.15,
		maxPerSecond = 8,
		maxArgs = 1,
		argTypes = { "string" },
	}, keyArg) then
		return
	end
	if typeof(keyArg) ~= "string" then
		return
	end
	local key = string.upper(keyArg)
	if table.find(FruitsConfig.VALID_MOVE_KEYS, key) == nil then
		return
	end

	local fruitId = FruitService.GetEquippedFruitId(player)
	if not fruitId then
		Remotes.Event("Notify"):FireClient(player, "Keine Fruit ausgerüstet.")
		return
	end

	local moves = FruitsConfig.GetMoves(fruitId)
	if not moves then
		Remotes.Event("Notify"):FireClient(player, "Diese Fruit hat noch keine Moves.")
		return
	end
	local move = moves[key]
	if not move then
		return
	end

	if not FruitService.CanUseFruitMoves(player, fruitId) then
		Remotes.Event("Notify"):FireClient(player, "Fruit nicht nutzbar.")
		return
	end

	local character = player.Character
	if not character then
		return
	end
	local humanoid = character:FindFirstChildOfClass("Humanoid")
	if not humanoid or humanoid.Health <= 0 then
		return
	end
	local root = getRoot(character)
	if not root then
		return
	end

	local now = os.clock()
	local cds = getCds(player)
	local cdKey = fruitId .. "_" .. key
	local last = cds[cdKey] or 0
	if (now - last) < move.Cooldown then
		return
	end

	if not EnergyService.Spend(player, move.Cost) then
		Remotes.Event("Notify"):FireClient(player, "Nicht genug Chakra.")
		return
	end

	cds[cdKey] = now

	local vfxName = VFX_BY_KEY[key]
	if vfxName then
		pulseVfx(character, vfxName)
	end

	if fruitId == "Dreck" then
		handleDreckMove(player, character, root, key, move)
	elseif fruitId == "Wind" then
		handleWindMove(player, character, root, key, move)
	elseif fruitId == "Flame" then
		handleFlameMove(player, character, root, key, move)
	elseif fruitId == "Ice" then
		handleIceMove(player, character, root, key, move)
	elseif fruitId == "Light" then
		handleLightMove(player, character, root, key, move)
	elseif fruitId == "Magma" then
		handleMagmaMove(player, character, root, key, move)
	elseif fruitId == "Blutaugespiegel" then
		handleBlutaugespiegelMove(player, character, root, key, move)
	elseif fruitId == "Sharingan" then
		handleSharinganMove(player, character, root, key, move)
	end

	bumpMastery(player, fruitId)
end

function FruitService.Start()
	if started then
		return
	end
	started = true

	Remotes.Event("FruitMove").OnServerEvent:Connect(handleMove)
	Remotes.Event("FruitSpecial").OnServerEvent:Connect(handleFruitSpecial)

	local function hook(player: Player)
		task.defer(function()
			DataManager.WaitFor(player, 20)
			if player.Parent then
				replicateFruitAttrs(player)
			end
		end)
		player.CharacterAdded:Connect(function()
			task.defer(function()
				replicateFruitAttrs(player)
			end)
		end)
	end

	Players.PlayerAdded:Connect(hook)
	Players.PlayerRemoving:Connect(function(player)
		moveCds[player] = nil
	end)
	for _, player in Players:GetPlayers() do
		hook(player)
	end

	print("[SoulFruits.Fruit] Moves online (Dreck + Wind + Flame + Ice + Light + Magma + Blutaugespiegel + Sharingan Mythical)")
end

return FruitService
