--!strict
--[[
	MovementService – Q Dash + F Flug (kein Doppelsprung).
	Server-Authority: Energy via EnergyService, VFX_Dash / VFX_Fly Attributes.
	Studio: ServerScriptService/SoulFruits/Systems/MovementService (ModuleScript)
]]

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Shared = ReplicatedStorage:WaitForChild("SoulFruits"):WaitForChild("Shared")
local Config = require(Shared:WaitForChild("Config"))
local Remotes = require(Shared:WaitForChild("Remotes"))

local EnergyService = require(script.Parent:WaitForChild("EnergyService"))
local AntiCheat = require(script.Parent:WaitForChild("AntiCheat"))

type MoveState = {
	lastDashAt: number,
	flying: boolean,
	flyAccum: number, -- energy drain accumulator
	dashUntil: number,
	dashDir: Vector3,
}

local MovementService = {}
local states: { [Player]: MoveState } = {}
local started = false

local function getState(player: Player): MoveState
	local s = states[player]
	if not s then
		s = {
			lastDashAt = 0,
			flying = false,
			flyAccum = 0,
			dashUntil = 0,
			dashDir = Vector3.zAxis,
		}
		states[player] = s
	end
	return s
end

local function getRoot(character: Model): BasePart?
	local hrp = character:FindFirstChild("HumanoidRootPart")
	if hrp and hrp:IsA("BasePart") then
		return hrp
	end
	return nil
end

local function pulseVfx(character: Model, attrName: string, value: any)
	character:SetAttribute(attrName, value)
	local be = character:FindFirstChild(attrName)
	if be and be:IsA("BindableEvent") then
		be:Fire(value)
	end
end

local function stopFly(player: Player, character: Model?)
	local state = getState(player)
	if not state.flying then
		return
	end
	state.flying = false
	state.flyAccum = 0
	EnergyService.SetFlying(player, false)
	player:SetAttribute("IsFlying", false)
	if character then
		pulseVfx(character, Config.VFX.Fly, false)
		local humanoid = character:FindFirstChildOfClass("Humanoid")
		if humanoid then
			humanoid:SetStateEnabled(Enum.HumanoidStateType.Jumping, true)
			humanoid.PlatformStand = false
		end
		local root = getRoot(character)
		if root then
			local lv = root:FindFirstChild("SF_FlightVelocity")
			if lv then
				lv:Destroy()
			end
			local att = root:FindFirstChild("SF_FlightAttachment")
			if att then
				att:Destroy()
			end
		end
	end
end

local function startFly(player: Player, character: Model)
	local state = getState(player)
	if state.flying then
		return
	end
	if not EnergyService.CanSpend(player, 1) then
		return
	end

	local root = getRoot(character)
	local humanoid = character:FindFirstChildOfClass("Humanoid")
	if not root or not humanoid or humanoid.Health <= 0 then
		return
	end

	state.flying = true
	state.flyAccum = 0
	EnergyService.SetFlying(player, true)
	player:SetAttribute("IsFlying", true)
	pulseVfx(character, Config.VFX.Fly, true)

	-- Mild float: LinearVelocity on attachment
	local att = Instance.new("Attachment")
	att.Name = "SF_FlightAttachment"
	att.Parent = root

	local lv = Instance.new("LinearVelocity")
	lv.Name = "SF_FlightVelocity"
	lv.Attachment0 = att
	lv.MaxForce = 1e5
	lv.VectorVelocity = Vector3.zero
	lv.RelativeTo = Enum.ActuatorRelativeTo.World
	lv.Parent = root

	-- Prevent jump spam while flying (no double-jump path)
	humanoid:SetStateEnabled(Enum.HumanoidStateType.Jumping, false)
end

local function handleDash(player: Player)
	local stunUntil = player:GetAttribute("SF_StunUntil")
	if typeof(stunUntil) == "number" and stunUntil > tick() then
		return
	end
	if not AntiCheat.Validate(player, "MovementDash", {
		cooldown = Config.DASH_COOLDOWN * 0.85,
		maxPerSecond = 3,
		maxArgs = 0,
	}) then
		return
	end

	local character = player.Character
	if not character then
		return
	end
	local humanoid = character:FindFirstChildOfClass("Humanoid")
	local root = getRoot(character)
	if not humanoid or not root or humanoid.Health <= 0 then
		return
	end

	local state = getState(player)
	local now = os.clock()
	if (now - state.lastDashAt) < Config.DASH_COOLDOWN then
		return
	end

	if not EnergyService.Spend(player, Config.DASH_COST) then
		return
	end

	-- Stop flight briefly for dash clarity
	if state.flying then
		stopFly(player, character)
	end

	local look = root.CFrame.LookVector
	local flat = Vector3.new(look.X, 0, look.Z)
	if flat.Magnitude < 0.05 then
		flat = Vector3.new(0, 0, -1)
	else
		flat = flat.Unit
	end

	state.lastDashAt = now
	state.dashUntil = now + Config.DASH_DURATION
	state.dashDir = flat

	pulseVfx(character, Config.VFX.Dash, tick())
	character:SetAttribute("SF_Dash", tick())

	-- Impulse
	root.AssemblyLinearVelocity = flat * Config.DASH_SPEED + Vector3.new(0, 8, 0)
end

local function handleFly(player: Player, holding: any)
	local stunUntil = player:GetAttribute("SF_StunUntil")
	if typeof(stunUntil) == "number" and stunUntil > tick() and holding == true then
		return
	end
	if not AntiCheat.Validate(player, "MovementFly", {
		cooldown = 0.05,
		maxPerSecond = 20,
		maxArgs = 1,
		argTypes = { "boolean" },
	}, holding) then
		return
	end
	if typeof(holding) ~= "boolean" then
		return
	end

	local character = player.Character
	if not character then
		return
	end

	if holding then
		startFly(player, character)
	else
		stopFly(player, character)
	end
end

function MovementService.Start()
	if started then
		return
	end
	started = true

	Remotes.Event("MovementDash").OnServerEvent:Connect(function(player)
		handleDash(player)
	end)
	Remotes.Event("MovementFly").OnServerEvent:Connect(function(player, holding)
		handleFly(player, holding)
	end)

	Players.PlayerRemoving:Connect(function(player)
		stopFly(player, player.Character)
		states[player] = nil
	end)

	local function resetMovement(player: Player, character: Model?)
		local state = getState(player)
		state.lastDashAt = 0
		state.dashUntil = 0
		state.flyAccum = 0
		stopFly(player, character or player.Character)
		player:SetAttribute("IsFlying", false)
	end
	MovementService.ResetMovement = resetMovement

	local function hookPlayer(player: Player)
		player.CharacterAdded:Connect(function(character)
			resetMovement(player, character)
			local humanoid = character:FindFirstChildOfClass("Humanoid")
			if humanoid then
				humanoid.Died:Connect(function()
					resetMovement(player, character)
				end)
			end
		end)
	end
	Players.PlayerAdded:Connect(hookPlayer)
	for _, player in Players:GetPlayers() do
		hookPlayer(player)
	end

	-- Flight drain + velocity update
	RunService.Heartbeat:Connect(function(dt)
		for player, state in states do
			local character = player.Character
			if not character then
				continue
			end
			local root = getRoot(character)
			local humanoid = character:FindFirstChildOfClass("Humanoid")
			if not root or not humanoid then
				continue
			end

			-- Maintain dash velocity briefly
			if os.clock() < state.dashUntil then
				local v = root.AssemblyLinearVelocity
				root.AssemblyLinearVelocity = Vector3.new(
					state.dashDir.X * Config.DASH_SPEED,
					v.Y,
					state.dashDir.Z * Config.DASH_SPEED
				)
			end

			if not state.flying then
				continue
			end

			-- Energy drain 10/s
			state.flyAccum += dt * Config.FLIGHT_COST_PER_SEC
			while state.flyAccum >= 1 do
				state.flyAccum -= 1
				if not EnergyService.Spend(player, 1) then
					stopFly(player, character)
					break
				end
			end
			if not state.flying then
				continue
			end

			local lv = root:FindFirstChild("SF_FlightVelocity")
			if not lv or not lv:IsA("LinearVelocity") then
				local att = root:FindFirstChild("SF_FlightAttachment")
				if not att then
					att = Instance.new("Attachment")
					att.Name = "SF_FlightAttachment"
					att.Parent = root
				end
				lv = Instance.new("LinearVelocity")
				lv.Name = "SF_FlightVelocity"
				lv.Attachment0 = att
				lv.MaxForce = 1e5
				lv.RelativeTo = Enum.ActuatorRelativeTo.World
				lv.Parent = root
			end
			if lv and lv:IsA("LinearVelocity") then
				local move = humanoid.MoveDirection
				local look = root.CFrame.LookVector
				local wish = move
				if wish.Magnitude < 0.05 then
					-- hover: slight upward bias so we don't fall
					wish = Vector3.new(0, 0.15, 0)
				else
					-- blend vertical from look when moving forward
					local flat = Vector3.new(wish.X, 0, wish.Z)
					local y = look.Y * Config.FLIGHT_VERTICAL_FACTOR
					if flat.Magnitude > 0.05 then
						flat = flat.Unit
					end
					wish = (flat + Vector3.new(0, y, 0))
					if wish.Magnitude > 0 then
						wish = wish.Unit
					end
				end
				lv.VectorVelocity = wish * Config.FLIGHT_SPEED
			end
		end
	end)

	print("[SoulFruits.Movement] Dash (Q) + Flug (F) online")
end

return MovementService
