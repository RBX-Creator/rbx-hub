--!strict
--[[
	Soul Fruits – DataManager
	Echte Session-Locks via UpdateAsync (kein reines Get/Set).
	Studio: ServerScriptService/SoulFruits/Data/DataManager (ModuleScript)
]]

local Players = game:GetService("Players")
local DataStoreService = game:GetService("DataStoreService")
local RunService = game:GetService("RunService")

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Shared = ReplicatedStorage:WaitForChild("SoulFruits"):WaitForChild("Shared")
local Config = require(Shared:WaitForChild("Config"))
local Remotes = require(Shared:WaitForChild("Remotes"))
local Types = require(Shared:WaitForChild("Types"))

local ProfileTemplate = require(script.Parent:WaitForChild("ProfileTemplate"))

local AUTOSAVE_INTERVAL = 60
local MAX_RETRIES = 5
local RETRY_BASE = 0.4
local SESSION_STALE_SEC = 1800 -- 30 min: assume dead server if lock older
local LOCK_ACQUIRE_TRIES = 8

type SessionMeta = {
	JobId: string,
	UserId: number,
	UpdatedAt: number,
}

type Session = {
	Data: Types.PlayerProfile,
	UserId: number,
	DataKey: string,
	SessionKey: string,
	Dirty: boolean,
}

local DataManager = {}
local sessions: { [Player]: Session } = {}
local dataStore: DataStore? = nil
local sessionStore: DataStore? = nil
local started = false

local function getDataStore(): DataStore
	if not dataStore then
		dataStore = DataStoreService:GetDataStore(Config.DATASTORE_NAME, Config.DATASTORE_SCOPE)
	end
	return dataStore
end

local function getSessionStore(): DataStore
	if not sessionStore then
		sessionStore = DataStoreService:GetDataStore(Config.DATASTORE_NAME .. "_Sessions", Config.DATASTORE_SCOPE)
	end
	return sessionStore
end

local function dataKeyFor(userId: number): string
	return ("Player_%d"):format(userId)
end

local function sessionKeyFor(userId: number): string
	return ("Session_%d"):format(userId)
end

local function retryAsync(fn: () -> any): (boolean, any)
	local lastErr
	for attempt = 1, MAX_RETRIES do
		local ok, result = pcall(fn)
		if ok then
			return true, result
		end
		lastErr = result
		task.wait(RETRY_BASE * (2 ^ (attempt - 1)))
	end
	return false, lastErr
end

local function pushSnapshot(player: Player, data: Types.PlayerProfile)
	Remotes.Event("DataUpdated"):FireClient(player, data)
end

function DataManager.Get(player: Player): Types.PlayerProfile?
	local session = sessions[player]
	return if session then session.Data else nil
end

function DataManager.IsLoaded(player: Player): boolean
	return sessions[player] ~= nil
end

--- Wait until profile is loaded (or timeout). For Character-before-Data races.
function DataManager.WaitFor(player: Player, timeoutSec: number?): Types.PlayerProfile?
	local deadline = os.clock() + (timeoutSec or 15)
	while os.clock() < deadline do
		local data = DataManager.Get(player)
		if data then
			return data
		end
		if player.Parent == nil then
			return nil
		end
		task.wait(0.1)
	end
	return DataManager.Get(player)
end

function DataManager.MarkDirty(player: Player)
	local session = sessions[player]
	if session then
		session.Dirty = true
		pushSnapshot(player, session.Data)
	end
end

function DataManager.Update(player: Player, mutator: (Types.PlayerProfile) -> ()): boolean
	local session = sessions[player]
	if not session then
		return false
	end
	mutator(session.Data)
	session.Dirty = true
	pushSnapshot(player, session.Data)
	return true
end

--- Acquire exclusive session lock with UpdateAsync. Returns false if another live session holds it.
local function acquireSessionLock(userId: number): boolean
	local key = sessionKeyFor(userId)
	local jobId = game.JobId
	if jobId == "" then
		jobId = "Studio"
	end

	for _ = 1, LOCK_ACQUIRE_TRIES do
		local ok, acquired = retryAsync(function()
			return getSessionStore():UpdateAsync(key, function(old: any)
				local now = os.time()
				if typeof(old) == "table" then
					local meta = old :: SessionMeta
					local sameJob = meta.JobId == jobId
					local stale = typeof(meta.UpdatedAt) == "number" and (now - meta.UpdatedAt) > SESSION_STALE_SEC
					if not sameJob and not stale then
						-- another server holds a fresh lock
						return old
					end
				end
				local meta: SessionMeta = {
					JobId = jobId,
					UserId = userId,
					UpdatedAt = now,
				}
				return meta
			end)
		end)

		if ok and typeof(acquired) == "table" and (acquired :: SessionMeta).JobId == jobId then
			return true
		end
		task.wait(0.5)
	end
	return false
end

local function refreshSessionLock(userId: number)
	local key = sessionKeyFor(userId)
	local jobId = if game.JobId ~= "" then game.JobId else "Studio"
	pcall(function()
		getSessionStore():UpdateAsync(key, function(old: any)
			if typeof(old) == "table" and (old :: SessionMeta).JobId == jobId then
				return {
					JobId = jobId,
					UserId = userId,
					UpdatedAt = os.time(),
				}
			end
			return old
		end)
	end)
end

local function releaseSessionLock(userId: number)
	local key = sessionKeyFor(userId)
	local jobId = if game.JobId ~= "" then game.JobId else "Studio"
	pcall(function()
		getSessionStore():UpdateAsync(key, function(old: any)
			if typeof(old) == "table" and (old :: SessionMeta).JobId == jobId then
				return nil -- clear lock
			end
			return old
		end)
	end)
end

--- Persist profile with UpdateAsync (atomic write, no blind SetAsync overwrite races).
local function saveSession(session: Session): boolean
	local snapshot = session.Data
	local ok, err = retryAsync(function()
		return getDataStore():UpdateAsync(session.DataKey, function(_old: any)
			-- This server owns the session lock; write authoritative in-memory profile.
			return snapshot
		end)
	end)
	if ok then
		session.Dirty = false
		refreshSessionLock(session.UserId)
		return true
	end
	warn(("[SoulFruits.Data] Save failed %s: %s"):format(session.DataKey, tostring(err)))
	return false
end

local function loadProfile(dataKey: string): Types.PlayerProfile
	local ok, result = retryAsync(function()
		return getDataStore():UpdateAsync(dataKey, function(old: any)
			-- Touch via UpdateAsync so first create is atomic; return existing or template.
			if typeof(old) == "table" then
				return old
			end
			return ProfileTemplate.Get()
		end)
	end)

	if ok and typeof(result) == "table" then
		return ProfileTemplate.Reconcile(result)
	end
	warn(("[SoulFruits.Data] Load failed %s: %s — using template"):format(dataKey, tostring(result)))
	return ProfileTemplate.Get()
end

local function loadPlayer(player: Player)
	local userId = player.UserId
	local dKey = dataKeyFor(userId)
	local sKey = sessionKeyFor(userId)

	if not acquireSessionLock(userId) then
		warn(("[SoulFruits.Data] Session lock busy for %d — kick"):format(userId))
		player:Kick("Dein Account ist noch auf einem anderen Server geladen. Bitte kurz warten und erneut joinen.")
		return
	end

	if player.Parent == nil then
		releaseSessionLock(userId)
		return
	end

	local data = loadProfile(dKey)

	sessions[player] = {
		Data = data,
		UserId = userId,
		DataKey = dKey,
		SessionKey = sKey,
		Dirty = false,
	}

	pushSnapshot(player, data)
	player:SetAttribute("SF_DataLoaded", true)
	if data.Faction then
		player:SetAttribute("SF_Faction", data.Faction)
	end
	player:SetAttribute("SF_Level", data.Level)
	player:SetAttribute("SF_FreeStatPoints", data.FreeStatPoints)

	if data.Faction == nil then
		Remotes.Event("FactionPrompt"):FireClient(player)
	end
end

local function releasePlayer(player: Player)
	local session = sessions[player]
	if not session then
		return
	end
	saveSession(session)
	releaseSessionLock(session.UserId)
	sessions[player] = nil
	pcall(function()
		player:SetAttribute("SF_DataLoaded", false)
	end)
end

function DataManager.Start()
	if started then
		return
	end
	started = true
	Remotes.Init()

	Players.PlayerAdded:Connect(function(player)
		task.spawn(loadPlayer, player)
	end)
	Players.PlayerRemoving:Connect(function(player)
		releasePlayer(player)
	end)

	for _, player in Players:GetPlayers() do
		task.spawn(loadPlayer, player)
	end

	task.spawn(function()
		while true do
			task.wait(AUTOSAVE_INTERVAL)
			for player, session in sessions do
				if session.Dirty then
					saveSession(session)
				else
					refreshSessionLock(session.UserId)
				end
			end
		end
	end)

	game:BindToClose(function()
		local threads = {}
		for player, _ in sessions do
			table.insert(threads, task.spawn(releasePlayer, player))
		end
		if not RunService:IsStudio() then
			task.wait(3)
		end
	end)
end

return DataManager
