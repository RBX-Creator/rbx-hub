--!strict
--[[
	Default player profile for Soul Fruits DataStore.
	Studio: ServerScriptService/SoulFruits/Data/ProfileTemplate (ModuleScript)
]]

local Types = require(game:GetService("ReplicatedStorage"):WaitForChild("SoulFruits"):WaitForChild("Shared"):WaitForChild("Types"))

local function deepCopy(t: { [any]: any }): { [any]: any }
	local out = {}
	for k, v in t do
		if typeof(v) == "table" then
			out[k] = deepCopy(v)
		else
			out[k] = v
		end
	end
	return out
end

local Template: Types.PlayerProfile = {
	Level = 1,
	XP = 0,
	Coins = 5000, -- TEST start for Stock/Dreck
	Splitz = 200, -- TEST start for Gacha
	DiceParts = 0,
	Faction = nil,
	Stats = {
		Melee = 0,
		Leben = 0,
		Chakra = 0,
		Schwer = 0,
	},
	FreeStatPoints = 0,
	HatDreckFruit = false,
	CurrentFruit = nil,
	DreckMastery = 0,
	BlutaugespiegelMastery = 0,
	FruitMastery = {},
	OwnedFruits = {},
	-- legacy stub field (unused; Susanoo later) — kept so old saves reconcile cleanly
	SharinganAwakened = false,
	HomePoint = nil,
	ActiveQuestId = nil,
	QuestProgress = 0,
	CompletedQuests = {},
	FruitStorage = {},
}

local ProfileTemplate = {}

function ProfileTemplate.Get(): Types.PlayerProfile
	return deepCopy(Template) :: Types.PlayerProfile
end

--- Merge saved data onto template so new fields appear after updates.
--- Open maps (e.g. OwnedFruits / FruitMastery) copy all saved sub-keys; known tables keep template defaults for missing keys.
function ProfileTemplate.Reconcile(data: { [string]: any }): Types.PlayerProfile
	local profile = ProfileTemplate.Get()
	for key, defaultValue in profile :: any do
		if data[key] == nil then
			continue
		end
		if typeof(defaultValue) == "table" and typeof(data[key]) == "table" then
			for subKey, subVal in data[key] do
				(profile :: any)[key][subKey] = subVal
			end
		else
			(profile :: any)[key] = data[key]
		end
	end

	-- Migrate legacy Sharingan → Blutaugespiegel (one Mythical eye fruit)
	local function migrateMap(map: any)
		if typeof(map) ~= "table" then
			return
		end
		if map.Sharingan then
			map.Blutaugespiegel = map.Blutaugespiegel or map.Sharingan
			map.Sharingan = nil
		end
	end
	migrateMap(profile.OwnedFruits)
	migrateMap(profile.FruitMastery)
	migrateMap((profile :: any).FruitStorage)
	if profile.CurrentFruit == "Sharingan" then
		profile.CurrentFruit = "Blutaugespiegel"
	end

	return profile
end

return ProfileTemplate
