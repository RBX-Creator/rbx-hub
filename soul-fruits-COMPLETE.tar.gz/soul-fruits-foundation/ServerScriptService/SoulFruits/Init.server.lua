--!strict
--[[
	Soul Fruits – Server bootstrap
	Studio: ServerScriptService/SoulFruits/Init (Script, not ModuleScript)
	Rename to Init or keep as Script named Init.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

-- Ensure shared tree exists before requires (when pasting manually, folders must exist)
local root = ReplicatedStorage:WaitForChild("SoulFruits")
local Shared = root:WaitForChild("Shared")
local Remotes = require(Shared:WaitForChild("Remotes"))
Remotes.Init()

local Data = script.Parent:WaitForChild("Data")
local Systems = script.Parent:WaitForChild("Systems")

local DataManager = require(Data:WaitForChild("DataManager"))
local FactionService = require(Systems:WaitForChild("FactionService"))
local LevelService = require(Systems:WaitForChild("LevelService"))
local StatService = require(Systems:WaitForChild("StatService"))
local EnergyService = require(Systems:WaitForChild("EnergyService"))
local DayNightService = require(Systems:WaitForChild("DayNightService"))
local AntiCheat = require(Systems:WaitForChild("AntiCheat"))
local CombatService = require(Systems:WaitForChild("CombatService"))
local MovementService = require(Systems:WaitForChild("MovementService"))
local FruitService = require(Systems:WaitForChild("FruitService"))
local PhysicalFruitService = require(Systems:WaitForChild("PhysicalFruitService"))
local StockService = require(Systems:WaitForChild("StockService"))
local GachaService = require(Systems:WaitForChild("GachaService"))
local WorldBootstrap = require(Systems:WaitForChild("WorldBootstrap"))
local QuestService = require(Systems:WaitForChild("QuestService"))
local EnemyService = require(Systems:WaitForChild("EnemyService"))

DataManager.Start()
FactionService.Start()
LevelService.Start()
StatService.Start()
EnergyService.Start()
DayNightService.Start()
AntiCheat.Start()
CombatService.Start()
MovementService.Start()
FruitService.Start()
PhysicalFruitService.Start()
StockService.Start()
GachaService.Start()
WorldBootstrap.Start()
QuestService.Start()
EnemyService.Start()

print("[SoulFruits] Fundament online: DataStore, Fraktion, Level/Stats, Energy, Tag/Nacht, AntiCheat, Combat M1, Movement, Gacha/Stock, Fruits, Quests, Enemies")
