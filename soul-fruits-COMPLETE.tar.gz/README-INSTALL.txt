Soul Fruits – COMPLETE Package
==============================

1) soul-fruits-foundation/  → Code in Roblox Studio (Rojo: default.project.json ODER Ordner 1:1 spiegeln)
2) soul-fruits-assets/      → Fruit/Tool/Prop FBXs einbauen (siehe READMEs)
3) soul-fruits-animations/fbx/ → Publish in Studio → IDs in AnimConfig.Ids
4) soul-fruits-vfx/         → meist schon in Foundation; Extra-Referenz

Wichtig: BF-Inseln aus Toolbox = nur Map/Meshes behalten, fremde Scripts löschen.
Pads unter Workspace/SoulFruitsWorld auf deine Inseln schieben.
