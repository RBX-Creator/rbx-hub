Soul Fruits – alles in einem Package

1. Entpacken
2. soul-fruits-foundation = Code (Rojo oder Ordner spiegeln)
3. soul-fruits-assets = Meshes/Tools/Props
4. soul-fruits-animations/fbx = Publish → AnimConfig.Ids
5. VFX steckt schon in foundation (soul-fruits-vfx optional)

Studio: README in foundation lesen. BF-Inseln: fremde Scripts strippen, Pads verschieben.
